# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 01  LIVE DEMO: FROM RAW DATA TO CLEAN DATA          (Session 5, block 5.2)
#
# Study: FLUID-ICU - SIMULATED cohort of 620 adults with sepsis in 4 ICUs.
#        Not real patients.
#
# Input : fluid_icu_raw.csv   (as the four ICUs sent it; 623 rows)
# Output: output/fluid_icu_clean_from_raw.csv  + a check that it is IDENTICAL
#         to the reference file fluid_icu_clean.csv
#
# HOW TO USE: open the Course/Data folder (FLUID-ICU.Rproj), then run this
# script one block at a time (Ctrl+Enter). Each block fixes ONE problem.
# Every problem is written down in cleaning_log.md - the "audit trail".
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

suppressPackageStartupMessages({
  library(tidyverse)   # read_csv, dplyr, stringr
  library(janitor)     # clean_names(), get_dupes(), tabyl()
})
dir.create("output", showWarnings = FALSE)

# ----------------------------------------------------------------------------
# STEP 0. Read the raw file - EVERYTHING as text
# ----------------------------------------------------------------------------
# Why text? If R guesses the type, "999", "Y" or "07-Dec-2023" may be silently
# turned into something else. We read text, look, and then convert ourselves.
raw <- read_csv("fluid_icu_raw.csv", col_types = cols(.default = col_character()))
dim(raw)          # 623 rows - but the study enrolled 620 patients. Why? (Step 2)
glimpse(raw)

# ----------------------------------------------------------------------------
# STEP 1. Column names: make them short, lower case, no spaces or brackets
# ----------------------------------------------------------------------------
dat <- raw |>
  clean_names() |>
  rename(map_mmhg          = map_mm_hg,
         aki_stage         = aki_stage_kdigo,
         vent_free_days_28 = vfd_28,
         time_to_event_28d = time_to_event_28d_days)
names(dat)

# ----------------------------------------------------------------------------
# STEP 2. Duplicate records: the same patient entered twice
# ----------------------------------------------------------------------------
dat |> get_dupes(study_id) |> select(study_id, site, admission_date, age, sex)
# The duplicated rows are identical in every column -> keep one copy.
dat <- dat |> distinct()
nrow(dat)                      # 620
stopifnot(!any(duplicated(dat$study_id)))

# ----------------------------------------------------------------------------
# STEP 3. Site names typed in different ways ("icu a", "ICU-A", "ICUA ")
# ----------------------------------------------------------------------------
dat |> count(site)
dat <- dat |>
  mutate(site = str_to_upper(str_squish(site)),
         site = paste("ICU", str_sub(site, -1)),       # last letter = the unit
         site = factor(site, levels = c("ICU A", "ICU B", "ICU C", "ICU D")))
dat |> count(site)

# ----------------------------------------------------------------------------
# STEP 4. Admission dates in three formats
# ----------------------------------------------------------------------------
# 2023-03-14  |  14/03/2023  |  14-Mar-2023   -> one real Date
dat |> select(admission_date) |> slice(1:8)
parse_mixed_date <- function(x) {
  iso <- as.Date(x, format = "%Y-%m-%d")
  dmy <- as.Date(x, format = "%d/%m/%Y")
  # day-Mon-year: translate the English month abbreviation ourselves, so it
  # works on any computer language setting
  p   <- str_match(x, "^(\\d{2})-([A-Za-z]{3})-(\\d{4})$")
  mon <- as.Date(sprintf("%s-%02d-%s", p[, 4], match(p[, 3], month.abb), p[, 2]),
                 format = "%Y-%m-%d")
  coalesce(iso, dmy, mon)
}
dat <- dat |> mutate(admission_date = parse_mixed_date(admission_date))
sum(is.na(dat$admission_date))                         # 0 - every date understood
range(dat$admission_date)                              # 2023-01-01 to 2024-12-31

# ----------------------------------------------------------------------------
# STEP 5. Sex coded 9 different ways (M, m, male, F, f, " Female", ...)
# ----------------------------------------------------------------------------
dat |> tabyl(sex)
dat <- dat |>
  mutate(sex = str_to_lower(str_trim(sex)),
         sex = case_when(sex %in% c("m", "male")   ~ "Male",
                         sex %in% c("f", "female") ~ "Female"),
         sex = factor(sex, levels = c("Female", "Male")))
dat |> tabyl(sex)

# ----------------------------------------------------------------------------
# STEP 6. Yes/No variables mix Yes / No / Y / N / yes / 1 / 0
# ----------------------------------------------------------------------------
dat |> tabyl(vasopressor)            # ICU B sends 1/0; others Yes/No, Y/N
to_yes_no <- function(x) {
  x <- str_to_lower(str_trim(x))
  out <- case_when(x %in% c("yes", "y", "1") ~ "Yes",
                   x %in% c("no",  "n", "0") ~ "No")
  factor(out, levels = c("No", "Yes"))
}
yn_vars <- c("diabetes", "ckd", "heart_failure", "hypertension",
             "vasopressor", "mech_vent", "rrt", "died_28d")
dat <- dat |> mutate(across(all_of(yn_vars), to_yes_no))
dat |> tabyl(vasopressor)
sapply(dat[yn_vars], function(v) sum(is.na(v)))      # all 0: nothing lost

# ----------------------------------------------------------------------------
# STEP 7. Text -> numbers
# ----------------------------------------------------------------------------
int_vars <- c("age", "sofa", "apache_ii", "map_mmhg",
              "fluid_in_d1_ml", "fluid_out_d1_ml", "fluid_in_d2_ml",
              "fluid_out_d2_ml", "fluid_in_d3_ml", "fluid_out_d3_ml",
              "aki_stage", "vent_free_days_28", "time_to_event_28d")
dbl_vars <- c("weight_kg", "lactate_mmol_l", "icu_los_days")
dat <- dat |>
  mutate(across(all_of(int_vars), ~ as.integer(.x)),
         across(all_of(dbl_vars), ~ as.numeric(.x)))
summary(dat[c("age", "weight_kg", "lactate_mmol_l", "apache_ii", "map_mmhg")])
# Look at the maximum and minimum of each: age 210? lactate 999? MAP 999?

# ----------------------------------------------------------------------------
# STEP 8. Missing-value codes (999 and -99) are NOT numbers
# ----------------------------------------------------------------------------
# If we leave them in, the mean lactate would be wildly wrong.
mean(dat$lactate_mmol_l, na.rm = TRUE)                 # misleading
dat |> summarise(lactate_999 = sum(lactate_mmol_l == 999, na.rm = TRUE),
                 lactate_m99 = sum(lactate_mmol_l == -99, na.rm = TRUE),
                 apache_m99  = sum(apache_ii == -99, na.rm = TRUE),
                 map_999     = sum(map_mmhg == 999, na.rm = TRUE))
dat <- dat |>
  mutate(lactate_mmol_l = if_else(lactate_mmol_l %in% c(999, -99), NA_real_, lactate_mmol_l),
         apache_ii      = if_else(apache_ii %in% c(999L, -99L), NA_integer_, apache_ii),
         map_mmhg       = if_else(map_mmhg  %in% c(999L, -99L), NA_integer_, map_mmhg))

# ----------------------------------------------------------------------------
# STEP 9. Units: ICU C reported lactate in mg/dL, not mmol/L
# ----------------------------------------------------------------------------
# A picture shows it at once: ICU C values are about 9 times larger.
dat |> group_by(site) |>
  summarise(n = sum(!is.na(lactate_mmol_l)),
            median_lactate = median(lactate_mmol_l, na.rm = TRUE))
# 1 mmol/L lactate = 9.01 mg/dL  ->  divide ICU C values by 9.01
dat <- dat |>
  mutate(lactate_mmol_l = if_else(site == "ICU C",
                                  round(lactate_mmol_l / 9.01, 1), lactate_mmol_l))
dat |> group_by(site) |> summarise(median_lactate = median(lactate_mmol_l, na.rm = TRUE))

# ----------------------------------------------------------------------------
# STEP 10. Impossible values (range checks from the data dictionary)
# ----------------------------------------------------------------------------
# We cannot guess the true value, so we set it to missing and send a
# query to the site. We do NOT delete the patient.
dat |> filter(age > 110 | weight_kg < 30 | if_any(starts_with("fluid_"), ~ .x < 0)) |>
  select(study_id, site, age, weight_kg, fluid_out_d2_ml)
dat <- dat |>
  mutate(age       = if_else(age < 18 | age > 110, NA_integer_, age),
         weight_kg = if_else(weight_kg < 30 | weight_kg > 250, NA_real_, weight_kg),
         across(starts_with("fluid_"), ~ if_else(.x < 0, NA_integer_, .x)))

# Check every other variable against its allowed range (all should be TRUE)
with(dat, c(
  sofa      = all(between(sofa, 0, 24)),
  apache    = all(between(apache_ii, 0, 71), na.rm = TRUE),
  lactate   = all(between(lactate_mmol_l, 0.1, 30), na.rm = TRUE),
  map       = all(between(map_mmhg, 20, 200), na.rm = TRUE),
  aki       = all(aki_stage %in% 0:3),
  vfd       = all(between(vent_free_days_28, 0, 28)),
  los       = all(icu_los_days > 0),
  time      = all(between(time_to_event_28d, 1, 28)),
  died_time = all(time_to_event_28d[died_28d == "No"] == 28)   # survivors followed to 28
))

# ----------------------------------------------------------------------------
# STEP 11. Factor for infection source (fixed order for tables)
# ----------------------------------------------------------------------------
dat |> tabyl(infection_source)
dat <- dat |>
  mutate(infection_source = factor(infection_source,
                                   levels = c("Respiratory", "Urinary", "Abdominal",
                                              "Skin/soft tissue", "Other")))

# ----------------------------------------------------------------------------
# STEP 12. Derived variables - computed by the analyst, never typed by hand
# ----------------------------------------------------------------------------
# Cumulative fluid balance day 3 (ml/kg) = (all fluid in - all fluid out) / weight
dat <- dat |>
  mutate(
    cum_fluid_balance_d3_ml_kg = round((fluid_in_d1_ml + fluid_in_d2_ml + fluid_in_d3_ml -
                                        fluid_out_d1_ml - fluid_out_d2_ml - fluid_out_d3_ml) /
                                       weight_kg, 1),
    positive_balance_d3 = factor(if_else(cum_fluid_balance_d3_ml_kg > 0, "Yes", "No"),
                                 levels = c("No", "Yes")),
    aki_any = factor(if_else(aki_stage >= 1, "Yes", "No"), levels = c("No", "Yes"))
  ) |>
  relocate(cum_fluid_balance_d3_ml_kg, positive_balance_d3, .after = fluid_out_d3_ml) |>
  relocate(aki_any, .after = aki_stage) |>
  arrange(study_id)

summary(dat$cum_fluid_balance_d3_ml_kg)
dat |> tabyl(positive_balance_d3)

# ----------------------------------------------------------------------------
# STEP 13. Final check: missing values per variable (what is left is REAL missing)
# ----------------------------------------------------------------------------
colSums(is.na(dat))[colSums(is.na(dat)) > 0]

# ----------------------------------------------------------------------------
# STEP 14. Save, and prove that the cleaning reproduces the reference file
# ----------------------------------------------------------------------------
write_csv(dat, "output/fluid_icu_clean_from_raw.csv", na = "")
reference <- readRDS("fluid_icu_clean.rds")
same_data <- isTRUE(all.equal(as.data.frame(dat), as.data.frame(reference), tolerance = 0))
same_file <- unname(tools::md5sum("output/fluid_icu_clean_from_raw.csv") ==
                    tools::md5sum("fluid_icu_clean.csv"))
cat("\nCleaned data identical to the reference clean file:", same_data,
    "\nCSV file byte-for-byte identical:                  ", same_file, "\n")
stopifnot(same_data, same_file)
