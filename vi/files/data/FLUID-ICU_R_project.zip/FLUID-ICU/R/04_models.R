# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 04  LIVE DEMO: MODELS - CONFOUNDING, SURVIVAL, INTERACTION (Session 6, block 6.4)
#
# Study: FLUID-ICU - SIMULATED cohort, 620 adults with sepsis, 4 ICUs.
#        Not real patients.
# Question (group 1 / primary): is a positive cumulative fluid balance by day 3
#   associated with 28-day mortality?
# Input : fluid_icu_clean.rds
# Output: output/tables/logistic_crude_vs_adjusted.(docx|csv), cox_models.csv,
#         interaction_hf.csv
#         output/figures/fig_forest_adjusted.png, fig_km_balance.png,
#         fig_crude_vs_adjusted.png
#
# The model plan (which confounders) was fixed in SAP_FLUID-ICU.md BEFORE the
# analysis: age, SOFA, lactate, vasopressor, mechanical ventilation, CKD.
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

if (!interactive()) pdf(NULL)   # when run with Rscript: no stray Rplots.pdf
suppressPackageStartupMessages({
  library(tidyverse)
  library(gtsummary)
  library(flextable)
  library(broom)
  library(survival)
  library(survminer)
})
dir.create("output/tables",  recursive = TRUE, showWarnings = FALSE)
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
pal <- c(teal = "#0D7377", blue = "#0B376C", lteal = "#5FA39B", sky = "#0070C0",
         grey = "#8A99A3", red = "#B23B2E")
theme_set(theme_minimal(base_size = 14) + theme(panel.grid.minor = element_blank()))

icu <- readRDS("fluid_icu_clean.rds") |> filter(!is.na(positive_balance_d3))
nrow(icu)   # 618 with a fluid balance

# ----------------------------------------------------------------------------
# 1. CRUDE logistic regression: balance only
# ----------------------------------------------------------------------------
m_crude <- glm(died_28d ~ positive_balance_d3, family = binomial, data = icu)
tidy(m_crude, exponentiate = TRUE, conf.int = TRUE)
# OR about 2.5: patients with a positive balance had 2.5 times the ODDS of death.
# But they were also sicker (Table 1). Is it the fluid, or the illness?

# ----------------------------------------------------------------------------
# 2. ADJUSTED logistic regression: the pre-specified confounders
# ----------------------------------------------------------------------------
m_adj <- glm(died_28d ~ positive_balance_d3 + age + sofa + lactate_mmol_l +
               vasopressor + mech_vent + ckd, family = binomial, data = icu)
nobs(m_adj)        # fewer patients: those with missing lactate (or age) are dropped!
tidy(m_adj, exponentiate = TRUE, conf.int = TRUE)

# A FAIR comparison of crude vs adjusted uses the SAME patients:
cc <- icu |> filter(complete.cases(age, sofa, lactate_mmol_l, vasopressor, mech_vent, ckd))
m_crude_cc <- glm(died_28d ~ positive_balance_d3, family = binomial, data = cc)
crude_vs_adj <- bind_rows(
  tidy(m_crude,    exponentiate = TRUE, conf.int = TRUE)[2, ] |> mutate(model = "Crude, all patients", n = nobs(m_crude)),
  tidy(m_crude_cc, exponentiate = TRUE, conf.int = TRUE)[2, ] |> mutate(model = "Crude, complete cases", n = nobs(m_crude_cc)),
  tidy(m_adj,      exponentiate = TRUE, conf.int = TRUE)[2, ] |> mutate(model = "Adjusted, complete cases", n = nobs(m_adj))
) |> select(model, n, OR = estimate, lower = conf.low, upper = conf.high, p = p.value)
crude_vs_adj
# TEACHING POINT: the OR shrinks from ~2.5 to ~1.6 once severity is taken into
# account = CONFOUNDING BY INDICATION. The remaining association is smaller,
# its CI is wide and only just excludes 1, and unmeasured severity may explain part of it.
write_csv(crude_vs_adj, "output/tables/crude_vs_adjusted_or.csv")

p_cva <- crude_vs_adj |>
  mutate(model = fct_inorder(model)) |>
  ggplot(aes(OR, fct_rev(model))) +
  geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = lower, xmax = upper), width = .15, orientation = "y", linewidth = 1, colour = pal[["blue"]]) +
  geom_point(size = 4, colour = pal[["teal"]]) +
  geom_text(aes(label = sprintf("%.2f (%.2f-%.2f)", OR, lower, upper)), vjust = -1.1, size = 4.2) +
  scale_x_log10(breaks = c(0.5, 1, 1.5, 2, 3, 4)) +
  labs(x = "Odds ratio for 28-day death, positive vs negative balance (log scale)", y = NULL)
p_cva
ggsave("output/figures/fig_crude_vs_adjusted.png", p_cva, width = 8, height = 3.8, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 3. The publication table: crude (one at a time) and adjusted ORs side by side
# ----------------------------------------------------------------------------
labs_list <- list(positive_balance_d3 ~ "Positive fluid balance day 3", age ~ "Age (per year)",
                  sofa ~ "SOFA score (per point)", lactate_mmol_l ~ "Lactate (per mmol/L)",
                  vasopressor ~ "Vasopressor", mech_vent ~ "Mechanical ventilation",
                  ckd ~ "Chronic kidney disease")
t_uni <- icu |>
  select(died_28d, positive_balance_d3, age, sofa, lactate_mmol_l, vasopressor, mech_vent, ckd) |>
  tbl_uvregression(method = glm, y = died_28d, method.args = list(family = binomial),
                   exponentiate = TRUE, label = labs_list)
t_multi <- tbl_regression(m_adj, exponentiate = TRUE, label = labs_list)
t_both <- tbl_merge(list(t_uni, t_multi), tab_spanner = c("**Crude**", "**Adjusted**")) |>
  modify_caption("**Table 2. Logistic regression for 28-day death (FLUID-ICU, simulated)**")
t_both
t_both |> as_flex_table() |> save_as_docx(path = "output/tables/logistic_crude_vs_adjusted.docx")
t_both_csv <- as_tibble(t_both)
names(t_both_csv) <- c("Characteristic", "N", "Crude OR", "Crude 95% CI", "Crude p",
                       "Adjusted OR", "Adjusted 95% CI", "Adjusted p")
write_csv(t_both_csv, "output/tables/logistic_crude_vs_adjusted.csv", na = "")

# ----------------------------------------------------------------------------
# 4. FOREST PLOT of the adjusted ORs
# ----------------------------------------------------------------------------
nice <- c(positive_balance_d3Yes = "Positive fluid balance", age = "Age (per year)",
          sofa = "SOFA (per point)", lactate_mmol_l = "Lactate (per mmol/L)",
          vasopressorYes = "Vasopressor", mech_ventYes = "Mechanical ventilation",
          ckdYes = "Chronic kidney disease")
forest <- tidy(m_adj, exponentiate = TRUE, conf.int = TRUE) |>
  filter(term != "(Intercept)") |>
  mutate(label = factor(nice[term], levels = rev(nice)),
         main = term == "positive_balance_d3Yes")
p_forest <- ggplot(forest, aes(estimate, label)) +
  geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = conf.low, xmax = conf.high), width = .2, orientation = "y", linewidth = .9, colour = pal[["blue"]]) +
  geom_point(aes(colour = main), size = 3.5, show.legend = FALSE) +
  scale_colour_manual(values = c(`FALSE` = pal[["blue"]], `TRUE` = pal[["teal"]])) +
  geom_text(aes(x = 6.5, label = sprintf("%.2f (%.2f-%.2f)", estimate, conf.low, conf.high)),
            hjust = 1, size = 4) +
  scale_x_log10(limits = c(0.4, 6.5), breaks = c(0.5, 1, 2, 4)) +
  labs(x = "Adjusted odds ratio for 28-day death (log scale)", y = NULL)
p_forest
ggsave("output/figures/fig_forest_adjusted.png", p_forest, width = 8, height = 4.5, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 5. KAPLAN-MEIER: survival to day 28 by balance group, with numbers at risk
# ----------------------------------------------------------------------------
km <- survfit(Surv(time_to_event_28d, died_28d == "Yes") ~ positive_balance_d3, data = icu)
km                                   # n, events, median survival (NA = more than half alive)
summary(km, times = c(7, 14, 28))    # survival % at day 7, 14 and 28
lr <- survdiff(Surv(time_to_event_28d, died_28d == "Yes") ~ positive_balance_d3, data = icu)
lr
p_logrank <- 1 - pchisq(lr$chisq, df = 1)

g_km <- ggsurvplot(km, data = icu, risk.table = TRUE, pval = TRUE, conf.int = TRUE,
                   palette = c(pal[["lteal"]], pal[["blue"]]),
                   legend.labs = c("Negative balance", "Positive balance"), legend.title = "",
                   xlab = "Days since ICU admission", ylab = "Survival probability",
                   break.time.by = 7, xlim = c(0, 28), ylim = c(0.5, 1),
                   pval.coord = c(1, 0.56), risk.table.height = 0.25,
                   ggtheme = theme_minimal(base_size = 14))
g_km
png("output/figures/fig_km_balance.png", width = 8, height = 6, units = "in", res = 300)
print(g_km)
invisible(dev.off())

# ----------------------------------------------------------------------------
# 6. COX REGRESSION: hazard ratio (crude and adjusted)
# ----------------------------------------------------------------------------
cox_crude <- coxph(Surv(time_to_event_28d, died_28d == "Yes") ~ positive_balance_d3, data = icu)
cox_adj   <- coxph(Surv(time_to_event_28d, died_28d == "Yes") ~ positive_balance_d3 + age + sofa +
                     lactate_mmol_l + vasopressor + mech_vent + ckd, data = icu)
summary(cox_adj)
cox.zph(cox_adj)       # proportional hazards check: p > 0.05 = no strong evidence against
cox_tab <- bind_rows(
  tidy(cox_crude, exponentiate = TRUE, conf.int = TRUE) |> mutate(model = "Crude", n = cox_crude$n),
  tidy(cox_adj,   exponentiate = TRUE, conf.int = TRUE) |> mutate(model = "Adjusted", n = cox_adj$n)
) |> filter(term == "positive_balance_d3Yes") |>
  select(model, n, HR = estimate, lower = conf.low, upper = conf.high, p = p.value) |>
  mutate(logrank_p = p_logrank)
cox_tab
write_csv(cox_tab, "output/tables/cox_models.csv")

# ----------------------------------------------------------------------------
# 7. INTERACTION (effect modification): is the fluid association stronger in
#    patients with heart failure? (pre-specified in the SAP)
# ----------------------------------------------------------------------------
m_int <- glm(died_28d ~ positive_balance_d3 * heart_failure + age + sofa + lactate_mmol_l +
               vasopressor + mech_vent + ckd, family = binomial, data = icu)
summary(m_int)$coefficients["positive_balance_d3Yes:heart_failureYes", ]   # interaction term
# Likelihood-ratio test: does adding the interaction improve the model?
m_noint <- update(m_int, . ~ . - positive_balance_d3:heart_failure)
anova(m_noint, m_int, test = "LRT")

# The OR for positive balance WITHIN each heart-failure group (same model,
# written so that R prints one OR per group)
m_strat <- glm(died_28d ~ heart_failure / positive_balance_d3 + age + sofa + lactate_mmol_l +
                 vasopressor + mech_vent + ckd, family = binomial, data = icu)
int_tab <- tidy(m_strat, exponentiate = TRUE, conf.int = TRUE) |>
  filter(grepl(":positive_balance_d3Yes", term)) |>
  mutate(subgroup = if_else(grepl("heart_failureYes", term), "Heart failure", "No heart failure"),
         n = as.vector(table(model.frame(m_strat)$heart_failure)),
         p_interaction = summary(m_int)$coefficients["positive_balance_d3Yes:heart_failureYes", 4]) |>
  select(subgroup, n, OR = estimate, lower = conf.low, upper = conf.high, p = p.value, p_interaction)
int_tab
write_csv(int_tab, "output/tables/interaction_hf.csv")
# TEACHING POINT: compare the two ORs and look at the INTERACTION p-value -
# not at whether each subgroup is "significant". One pre-specified subgroup,
# p for interaction about 0.03: worth reporting, but needs confirmation.

cat("\n04_models.R finished: tables and figures saved in output/\n")
