# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 05  LIVE DEMO: MISSING DATA - COMPLETE CASE vs MULTIPLE IMPUTATION
#                                                          (Session 6, block 6.4)
# Study: FLUID-ICU - SIMULATED cohort, 620 adults with sepsis, 4 ICUs.
#        Not real patients.
# Question (group 4): is admission lactate associated with 28-day mortality,
#   and does the answer change when we handle missing lactate properly?
# Input : fluid_icu_clean.rds
# Output: output/tables/missing_summary.csv, missing_lactate_by_status.(docx|csv),
#         cc_vs_mi.(docx|csv);  output/figures/fig_missing_lactate.png,
#         fig_cc_vs_mi.png, fig_imputed_lactate.png
#
# Three words to remember:
#   MCAR - missing completely at random (just bad luck): complete case is unbiased
#   MAR  - missingness depends on things we OBSERVED (e.g. SOFA): use imputation
#   MNAR - missingness depends on the missing value itself: nothing fixes it fully
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

if (!interactive()) pdf(NULL)   # when run with Rscript: no stray Rplots.pdf
suppressPackageStartupMessages({
  library(tidyverse)
  library(gtsummary)
  library(flextable)
  library(broom)
  library(mice)
})
dir.create("output/tables",  recursive = TRUE, showWarnings = FALSE)
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)
pal <- c(teal = "#0D7377", blue = "#0B376C", lteal = "#5FA39B", sky = "#0070C0", grey = "#8A99A3")
theme_set(theme_minimal(base_size = 14) + theme(panel.grid.minor = element_blank()))

icu <- readRDS("fluid_icu_clean.rds")

# ----------------------------------------------------------------------------
# 1. HOW MUCH is missing? (always report n and % missing per variable)
# ----------------------------------------------------------------------------
miss <- tibble(variable = names(icu),
               n_missing = colSums(is.na(icu)),
               pct_missing = round(100 * colMeans(is.na(icu)), 1)) |>
  filter(n_missing > 0) |> arrange(desc(n_missing))
miss
write_csv(miss, "output/tables/missing_summary.csv")
# Lactate is the only variable with a lot missing (about 15%).

# ----------------------------------------------------------------------------
# 2. WHO is missing lactate? Compare patients with and without a lactate value
# ----------------------------------------------------------------------------
icu <- icu |> mutate(lactate_status = factor(if_else(is.na(lactate_mmol_l), "Lactate missing",
                                                     "Lactate measured"),
                                             levels = c("Lactate measured", "Lactate missing")))
t_miss <- icu |>
  select(lactate_status, age, sofa, apache_ii, map_mmhg, vasopressor, mech_vent, site, died_28d) |>
  tbl_summary(by = lactate_status,
              label = list(age ~ "Age, years", sofa ~ "SOFA score", apache_ii ~ "APACHE II score",
                           map_mmhg ~ "MAP, mmHg", vasopressor ~ "Vasopressor",
                           mech_vent ~ "Mechanical ventilation", site ~ "ICU",
                           died_28d ~ "Died by day 28"),
              type = list(c(vasopressor, mech_vent, died_28d) ~ "dichotomous"),
              value = list(c(vasopressor, mech_vent, died_28d) ~ "Yes"),
              missing = "no") |>
  add_p() |>
  modify_caption("**Patients with and without an admission lactate (FLUID-ICU, simulated)**")
t_miss
t_miss |> as_flex_table() |> save_as_docx(path = "output/tables/missing_lactate_by_status.docx")
t_miss_csv <- as_tibble(t_miss)
names(t_miss_csv) <- c("Characteristic", "Lactate measured", "Lactate missing", "p-value")
write_csv(t_miss_csv, "output/tables/missing_lactate_by_status.csv", na = "")
# READ: patients with missing lactate were LESS sick (lower SOFA, higher MAP,
# fewer on vasopressors) and died less often. So lactate is NOT missing
# completely at random. Missingness is explained by things we observed -> MAR
# is plausible -> multiple imputation is the sensible main approach.

# Missingness by SOFA band - the picture used on the slide
p_miss <- icu |>
  mutate(sofa_band = cut(sofa, c(-Inf, 4, 7, 10, Inf), labels = c("0-4", "5-7", "8-10", "11+"))) |>
  group_by(sofa_band) |>
  summarise(n = n(), pct_missing = 100 * mean(is.na(lactate_mmol_l))) |>
  ggplot(aes(sofa_band, pct_missing)) +
  geom_col(fill = pal[["teal"]], width = .6) +
  geom_text(aes(label = sprintf("%.0f%%\n(n = %d)", pct_missing, n)), vjust = -.2, size = 4.3) +
  scale_y_continuous(limits = c(0, 45), expand = expansion(mult = c(0, .02))) +
  labs(x = "SOFA score on admission", y = "Lactate missing (%)")
p_miss
ggsave("output/figures/fig_missing_lactate.png", p_miss, width = 7, height = 4.5, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 3. COMPLETE-CASE analysis (what R does by default: drops rows with NA)
# ----------------------------------------------------------------------------
f_q4  <- died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure
f_q4s <- died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure + sofa
f_q1  <- died_28d ~ positive_balance_d3 + age + sofa + lactate_mmol_l + vasopressor + mech_vent + ckd

cc_q4  <- glm(f_q4,  family = binomial, data = icu)
cc_q4s <- glm(f_q4s, family = binomial, data = icu)
cc_q1  <- glm(f_q1,  family = binomial, data = icu)
nobs(cc_q4)     # 527 of 620 patients used: the 93 without lactate are dropped

# ----------------------------------------------------------------------------
# 4. MULTIPLE IMPUTATION with mice (m = 20 imputed data sets)
# ----------------------------------------------------------------------------
# The imputation model includes the OUTCOME (died_28d) and the variables that
# predict missingness (SOFA, MAP, vasopressor, site) - otherwise MI is biased.
imp_vars <- icu |>
  select(died_28d, lactate_mmol_l, age, sex, sofa, apache_ii, map_mmhg, vasopressor,
         mech_vent, ckd, diabetes, heart_failure, site, positive_balance_d3, infection_source)
md.pattern(imp_vars, plot = FALSE)[, c("lactate_mmol_l", "apache_ii", "map_mmhg")] |> tail(1)

imp <- mice(imp_vars, m = 20, seed = 2024, printFlag = FALSE)
imp$method            # pmm for numbers, logreg for yes/no

# Check: do imputed lactates (red) look like plausible observed ones (blue)?
png("output/figures/fig_imputed_lactate.png", width = 7, height = 4.5, units = "in", res = 300)
print(densityplot(imp, ~ lactate_mmol_l))
invisible(dev.off())

# Fit the same model in each of the 20 data sets, then POOL (Rubin's rules)
mi_q4  <- pool(with(imp, glm(died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure,
                             family = binomial)))
mi_q4s <- pool(with(imp, glm(died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure + sofa,
                             family = binomial)))
mi_q1  <- pool(with(imp, glm(died_28d ~ positive_balance_d3 + age + sofa + lactate_mmol_l +
                               vasopressor + mech_vent + ckd, family = binomial)))

# ----------------------------------------------------------------------------
# 5. COMPARE complete case vs multiple imputation
# ----------------------------------------------------------------------------
row_cc <- function(fit, term, label) {
  tidy(fit, exponentiate = TRUE, conf.int = TRUE) |> filter(term == !!term) |>
    transmute(analysis = label, method = "Complete case", n = nobs(fit),
              OR = estimate, lower = conf.low, upper = conf.high, p = p.value)
}
row_mi <- function(pooled, term, label) {
  summary(pooled, conf.int = TRUE, exponentiate = TRUE) |> filter(term == !!term) |>
    transmute(analysis = label, method = "Multiple imputation (m = 20)", n = nrow(icu),
              OR = estimate, lower = `2.5 %`, upper = `97.5 %`, p = p.value)
}
cc_vs_mi <- bind_rows(
  row_cc(cc_q4,  "lactate_mmol_l", "Q4: lactate (per mmol/L), adj. age, sex, comorbidities"),
  row_mi(mi_q4,  "lactate_mmol_l", "Q4: lactate (per mmol/L), adj. age, sex, comorbidities"),
  row_cc(cc_q4s, "lactate_mmol_l", "Q4: lactate (per mmol/L), + SOFA"),
  row_mi(mi_q4s, "lactate_mmol_l", "Q4: lactate (per mmol/L), + SOFA"),
  row_cc(cc_q1,  "positive_balance_d3Yes", "Q1: positive balance, fully adjusted"),
  row_mi(mi_q1,  "positive_balance_d3Yes", "Q1: positive balance, fully adjusted")
)
cc_vs_mi |> mutate(across(c(OR, lower, upper), ~ round(.x, 2)), p = signif(p, 2))
write_csv(cc_vs_mi, "output/tables/cc_vs_mi.csv")
cc_vs_mi |>
  mutate(`OR (95% CI)` = sprintf("%.2f (%.2f to %.2f)", OR, lower, upper),
         p = if_else(p < 0.001, "<0.001", sprintf("%.3f", p))) |>
  select(Analysis = analysis, Method = method, n, `OR (95% CI)`, p) |>
  flextable() |> merge_v(j = "Analysis") |> autofit() |> theme_vanilla() |>
  save_as_docx(path = "output/tables/cc_vs_mi.docx")

p_ccmi <- cc_vs_mi |>
  filter(grepl("^Q4", analysis)) |>
  mutate(analysis = sub("^Q4: lactate \\(per mmol/L\\), ", "", analysis),
         analysis = factor(analysis, levels = unique(analysis))) |>
  ggplot(aes(OR, method, colour = method)) +
  geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = lower, xmax = upper), width = .2, orientation = "y", linewidth = 1) +
  geom_point(size = 4) +
  geom_text(aes(label = sprintf("%.2f (%.2f-%.2f), n = %d", OR, lower, upper, n)),
            vjust = -1.1, size = 4, colour = "black") +
  facet_wrap(~ analysis, ncol = 1) +
  scale_colour_manual(values = c(pal[["grey"]], pal[["teal"]]), guide = "none") +
  scale_x_continuous(limits = c(0.9, 1.8)) +
  labs(x = "Odds ratio for 28-day death per 1 mmol/L lactate", y = NULL)
p_ccmi
ggsave("output/figures/fig_cc_vs_mi.png", p_ccmi, width = 8, height = 5, dpi = 300, bg = "white")

# TEACHING POINT: complete case used ~85% of patients, and those were the
# SICKER ones. MI uses all 620 and gives a somewhat larger OR (1.45 vs 1.39); CIs are similar.
# The direction is the same; the difference is modest. Report MI as the main
# analysis (as the SAP said) and complete case as a sensitivity analysis.
cat("\n05_missing.R finished: tables and figures saved in output/\n")
