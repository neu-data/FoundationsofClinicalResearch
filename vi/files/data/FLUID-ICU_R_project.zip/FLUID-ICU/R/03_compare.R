# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 03  LIVE DEMO: COMPARE TWO GROUPS                         (Session 6, block 6.2)
#
# Study: FLUID-ICU - SIMULATED cohort, 620 adults with sepsis, 4 ICUs.
#        Not real patients.
# Input : fluid_icu_clean.rds
# Output: output/tables/compare_two_groups.csv
#
# The question for every test: "Which type of outcome do I have?"
#   number, roughly symmetric   -> t-test           (difference in means)
#   number, skewed / scores     -> Mann-Whitney     (compare medians/ranks)
#   yes/no                      -> chi-square test  (difference in %, RR, OR)
# A p-value alone is never the answer: always report the effect with its 95% CI.
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

if (!interactive()) pdf(NULL)   # when run with Rscript: no stray Rplots.pdf
suppressPackageStartupMessages(library(tidyverse))
dir.create("output/tables", recursive = TRUE, showWarnings = FALSE)

icu <- readRDS("fluid_icu_clean.rds") |>
  filter(!is.na(positive_balance_d3)) |>
  mutate(group = factor(positive_balance_d3, levels = c("Yes", "No"),
                        labels = c("Positive", "Negative")))
# "Positive" is the first level, so every difference below is Positive minus Negative
icu |> count(group)

results <- list()   # we collect each result in one table at the end

# ----------------------------------------------------------------------------
# 1. AGE (number, roughly symmetric) -> t-test
# ----------------------------------------------------------------------------
# Check the shape first: a histogram per group
hist(icu$age, main = "Age", xlab = "years", col = "#5FA39B")
icu |> group_by(group) |> summarise(n = sum(!is.na(age)), mean = mean(age, na.rm = TRUE),
                                    sd = sd(age, na.rm = TRUE))
tt <- t.test(age ~ group, data = icu)   # Welch t-test (does not assume equal SDs)
tt
# Read: the difference in means (Positive - Negative) and its 95% CI.
results$age <- tibble(variable = "Age, years", test = "Welch t-test",
                      summary = "mean (SD)",
                      effect = sprintf("Difference in means %.1f (95%% CI %.1f to %.1f)",
                                       tt$estimate[1] - tt$estimate[2], tt$conf.int[1], tt$conf.int[2]),
                      p = tt$p.value)

# ----------------------------------------------------------------------------
# 2. SOFA SCORE (a score, not symmetric) -> Mann-Whitney (Wilcoxon rank-sum)
# ----------------------------------------------------------------------------
icu |> group_by(group) |> summarise(median = median(sofa), q1 = quantile(sofa, .25),
                                    q3 = quantile(sofa, .75))
mw_sofa <- wilcox.test(sofa ~ group, data = icu, conf.int = TRUE, exact = FALSE)
mw_sofa
# The "difference in location" is the Hodges-Lehmann estimate: the typical
# difference between a patient from each group.
results$sofa <- tibble(variable = "SOFA score", test = "Mann-Whitney",
                       summary = "median (IQR)",
                       effect = sprintf("Hodges-Lehmann difference %.1f (95%% CI %.1f to %.1f)",
                                        mw_sofa$estimate, mw_sofa$conf.int[1], mw_sofa$conf.int[2]),
                       p = mw_sofa$p.value)

# ----------------------------------------------------------------------------
# 3. LACTATE (skewed) -> Mann-Whitney. Note: 91 patients have no lactate.
# ----------------------------------------------------------------------------
icu |> group_by(group) |>
  summarise(n_measured = sum(!is.na(lactate_mmol_l)),
            median = median(lactate_mmol_l, na.rm = TRUE),
            q1 = quantile(lactate_mmol_l, .25, na.rm = TRUE),
            q3 = quantile(lactate_mmol_l, .75, na.rm = TRUE))
mw_lac <- wilcox.test(lactate_mmol_l ~ group, data = icu, conf.int = TRUE, exact = FALSE)
mw_lac
results$lactate <- tibble(variable = "Lactate, mmol/L", test = "Mann-Whitney",
                          summary = "median (IQR)",
                          effect = sprintf("Hodges-Lehmann difference %.1f (95%% CI %.1f to %.1f)",
                                           mw_lac$estimate, mw_lac$conf.int[1], mw_lac$conf.int[2]),
                          p = mw_lac$p.value)

# ----------------------------------------------------------------------------
# 4. 28-DAY DEATH (yes/no) -> 2x2 table and chi-square test
# ----------------------------------------------------------------------------
tab <- table(icu$group, icu$died_28d)
tab
prop.table(tab, 1) * 100                     # % who died in each group
chi <- chisq.test(tab)
chi
chi$expected                                 # all expected counts >= 5 -> chi-square is fine
# Risk difference with 95% CI (prop.test gives it directly)
pt <- prop.test(x = tab[, "Yes"], n = rowSums(tab), correct = FALSE)
pt
risk <- tab[, "Yes"] / rowSums(tab)
rr <- risk[["Positive"]] / risk[["Negative"]]
cat(sprintf("Risk: positive %.1f%% vs negative %.1f%%  |  RR = %.2f\n",
            100 * risk[["Positive"]], 100 * risk[["Negative"]], rr))
results$died <- tibble(variable = "28-day death", test = "Chi-square",
                       summary = "n (%)",
                       effect = sprintf("Risk difference %.1f%% (95%% CI %.1f to %.1f); RR %.2f",
                                        100 * (pt$estimate[1] - pt$estimate[2]), 100 * pt$conf.int[1],
                                        100 * pt$conf.int[2], rr),
                       p = chi$p.value)
# TEACHING POINT: this crude comparison mixes the effect of fluid with the
# effect of being sicker. Session 6.4 adjusts for severity (04_models.R).

# ----------------------------------------------------------------------------
# 5. AKI (yes/no) -> chi-square
# ----------------------------------------------------------------------------
tab_aki <- table(icu$group, icu$aki_any)
prop.table(tab_aki, 1) * 100
chi_aki <- chisq.test(tab_aki)
pt_aki <- prop.test(x = tab_aki[, "Yes"], n = rowSums(tab_aki), correct = FALSE)
results$aki <- tibble(variable = "Acute kidney injury (KDIGO >= 1)", test = "Chi-square",
                      summary = "n (%)",
                      effect = sprintf("Risk difference %.1f%% (95%% CI %.1f to %.1f)",
                                       100 * (pt_aki$estimate[1] - pt_aki$estimate[2]),
                                       100 * pt_aki$conf.int[1], 100 * pt_aki$conf.int[2]),
                      p = chi_aki$p.value)

# ----------------------------------------------------------------------------
# 6. VENTILATOR-FREE DAYS (0-28, piled up at 0 and 28) -> Mann-Whitney
# ----------------------------------------------------------------------------
hist(icu$vent_free_days_28, breaks = 0:28, main = "Ventilator-free days", col = "#0D7377")
mw_vfd <- wilcox.test(vent_free_days_28 ~ group, data = icu, conf.int = TRUE, exact = FALSE)
icu |> group_by(group) |> summarise(median = median(vent_free_days_28),
                                    q1 = quantile(vent_free_days_28, .25),
                                    q3 = quantile(vent_free_days_28, .75))
results$vfd <- tibble(variable = "Ventilator-free days to day 28", test = "Mann-Whitney",
                      summary = "median (IQR)",
                      effect = sprintf("Hodges-Lehmann difference %.1f (95%% CI %.1f to %.1f)",
                                       mw_vfd$estimate, mw_vfd$conf.int[1], mw_vfd$conf.int[2]),
                      p = mw_vfd$p.value)

# ----------------------------------------------------------------------------
# 7. A COMMON MISTAKE: t-test on a skewed outcome (ICU stay, survivors)
# ----------------------------------------------------------------------------
surv <- icu |> filter(died_28d == "No")
hist(surv$icu_los_days, breaks = 30, main = "ICU stay, survivors", col = "#0B376C")
t.test(icu_los_days ~ group, data = surv)$estimate          # means pulled by long stays
wilcox.test(icu_los_days ~ group, data = surv, exact = FALSE)$p.value
surv |> group_by(group) |> summarise(median = median(icu_los_days),
                                     q1 = quantile(icu_los_days, .25),
                                     q3 = quantile(icu_los_days, .75))

# ----------------------------------------------------------------------------
# 8. One table of all comparisons
# ----------------------------------------------------------------------------
# Description of each group (median/IQR or n/%) is in Table 1 and the results packs.
compare <- bind_rows(results) |>
  mutate(effect = gsub("-0\\.0([^0-9])", "0.0\\1", effect),     # tidy "-0.0"
         p = if_else(p < 0.001, "<0.001", sprintf("%.3f", p)),
         note = "Positive minus negative balance group, unadjusted")
compare
write_csv(compare, "output/tables/compare_two_groups.csv")
# TEACHING POINT: we ran 6 tests. With many tests, some "significant" results
# appear by chance. Our SAP named ONE primary outcome (28-day death).
cat("\n03_compare.R finished: output/tables/compare_two_groups.csv\n")
