# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 00  GENERATE THE COURSE DATASET  "FLUID-ICU"  (SIMULATED - NOT REAL PATIENTS)
#
# FLUID-ICU is an invented multicentre prospective cohort: adults with sepsis
# admitted to 4 ICUs ("ICU A" to "ICU D") over 2 years (2023-2024).
# Every value below comes from a random-number generator with a fixed seed.
# No real patient, hospital or country is represented.
#
# This script is for the INSTRUCTOR / course team. Participants never need it.
# It writes:
#   fluid_icu_clean.csv / .rds  - the analysis-ready file (reference)
#   fluid_icu_raw.csv / .xlsx   - the same data as a site would send it, with
#                                 realistic data-quality problems (cleaning demo)
#
# Run from the Course/Data folder:   Rscript R/00_generate_fluid_icu.R
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

suppressPackageStartupMessages({
  library(dplyr)
  library(readr)
  library(writexl)
  library(survival)
})

SEED      <- 2757   # chosen after checking that the teaching features appear (see end)
MISS_SEED <- 10     # separate random stream for which lactate values are missing
N    <- 620

clip <- function(x, lo, hi) pmin(pmax(x, lo), hi)

# ----------------------------------------------------------------------------
# 1. THE "TRUE" COHORT
# ----------------------------------------------------------------------------
# A hidden severity score S (mean 0, SD 1) drives SOFA, APACHE II, lactate,
# MAP, vasopressors, ventilation, the amount of fluid given AND death.
# This is CONFOUNDING BY INDICATION: sicker patients get more fluid and die more.
# The true extra risk from a positive balance is modest and mainly seen in
# patients with heart failure (the built-in effect modification).
set.seed(SEED)
n <- N
site <- sample(c("ICU A", "ICU B", "ICU C", "ICU D"), n, TRUE, prob = c(.30, .27, .23, .20))
adm  <- as.Date("2023-01-01") + sort(sample(0:730, n, TRUE))      # 2 years of enrolment
age  <- round(clip(rnorm(n, 63, 15), 18, 94))
sex  <- ifelse(runif(n) < .58, "Male", "Female")
wt   <- round(clip(ifelse(sex == "Male", rnorm(n, 68, 12), rnorm(n, 59, 11)), 38, 140), 1)
diab <- rbinom(n, 1, plogis(-1.2 + 0.03 * (age - 63)))
ckd  <- rbinom(n, 1, plogis(-2.0 + 0.04 * (age - 63)))
hf   <- rbinom(n, 1, plogis(-1.9 + 0.05 * (age - 63)))
htn  <- rbinom(n, 1, plogis(-0.2 + 0.05 * (age - 63)))
src  <- sample(c("Respiratory", "Urinary", "Abdominal", "Skin/soft tissue", "Other"), n, TRUE,
               prob = c(.42, .22, .20, .08, .08))
S    <- rnorm(n) + 0.2 * (src == "Abdominal") - 0.2 * (src == "Urinary")   # hidden severity

sofa   <- round(clip(7.2 + 2.4 * S + rnorm(n, 0, 1.6), 1, 20))
apache <- round(clip(19 + 5 * S + 0.12 * (age - 63) + rnorm(n, 0, 3.5), 3, 50))
lac    <- round(clip(exp(log(2.3) + 0.38 * S + rnorm(n, 0, .42)), 0.5, 18), 1)
map    <- round(clip(74 - 6 * S + rnorm(n, 0, 8), 40, 120))
vaso   <- rbinom(n, 1, plogis(-0.3 + 1.5 * S))
mv     <- rbinom(n, 1, plogis(-0.2 + 1.1 * S + 0.9 * (src == "Respiratory")))

# Fluid: sicker patients and patients on vasopressors receive more; clinicians
# give less to patients with CKD or heart failure; ICUs differ in practice.
site_eff  <- c("ICU A" = 0, "ICU B" = 5, "ICU C" = -4, "ICU D" = 8)[site]
fb_target <- 6 + 11 * S + 8 * vaso + site_eff - 7 * ckd - 9 * hf + rnorm(n, 0, 22)  # ml/kg
fr  <- matrix(rgamma(3 * n, shape = c(11, 6, 4)), ncol = 3, byrow = TRUE)  # day 1 > day 2 > day 3
fr  <- fr / rowSums(fr)
bal_ml <- fb_target * wt * fr
out <- sapply(1:3, function(k) exp(log(c(1650, 1850, 2050)[k]) - 0.18 * S + rnorm(n, 0, .35)))
inn <- out + bal_ml
low <- inn < 500
inn[low] <- 500 + runif(sum(low), 0, 400)          # nobody receives < 500 ml in a day
out <- round(out / 10) * 10
inn <- round(inn / 10) * 10
cfb <- round(rowSums(inn - out) / wt, 1)            # cumulative balance day 3, ml/kg
pos <- as.integer(cfb > 0)

# 28-day death (logistic). Fluid effect: none on its own, extra risk with heart failure.
lp <- -1.6 + 0.03 * (age - 63) + 0.95 * S + 0.35 * vaso + 0.30 * mv + 0.45 * ckd +
      0 * pos + 1.0 * pos * hf + 0.004 * cfb
died   <- rbinom(n, 1, plogis(lp))
tdeath <- pmin(27, ceiling(rweibull(n, 0.85, 7 * exp(-0.2 * S))))   # most deaths early
time   <- ifelse(died == 1, tdeath, 28)                              # survivors censored at 28

# AKI (KDIGO maximum stage, ICU days 1-7): severity, CKD, vasopressors and fluid balance
ak  <- 0.9 * S + 0.8 * ckd + 0.020 * cfb + 0.3 * vaso + rlogis(n)
aki <- cut(ak, c(-Inf, 0.35, 1.3, 2.2, Inf), labels = FALSE) - 1
rrt <- rbinom(n, 1, ifelse(aki == 3, .55, ifelse(aki == 2, .08, 0)))

# Ventilator-free days to day 28 (0 if dead; 28 if never ventilated)
vdays <- pmax(1, round(exp(log(5) + 0.25 * S + 0.009 * cfb + rnorm(n, 0, .55))))
vfd   <- ifelse(died == 1, 0, ifelse(mv == 1, pmax(0, 28 - vdays), 28))

# ICU length of stay (right-skewed; deaths stay until death)
los_s <- round(exp(log(5.5) + 0.22 * S + 0.006 * cfb + 0.25 * mv + rnorm(n, 0, .5)), 1)
los   <- ifelse(died == 1, pmax(0.5, round(time - runif(n, 0, .9), 1)), pmax(1, los_s))

# Lactate missing at random: less often measured in less severe patients
# (lower SOFA, higher MAP, no vasopressor) and in ICU D (no point-of-care
# analyser). Missingness depends only on OBSERVED variables = MAR.
pm      <- plogis(-1.95 - 0.30 * (sofa - 7) - 0.7 * vaso + 0.04 * (map - 74) +
                  0.7 * (site == "ICU D"))
set.seed(MISS_SEED)
lac_obs <- ifelse(rbinom(n, 1, pm) == 1, NA, lac)

yn <- function(x) factor(ifelse(x == 1, "Yes", "No"), levels = c("No", "Yes"))

truth <- tibble(
  study_id = sprintf("FLU-%03d", 1:n),
  site = factor(site, levels = c("ICU A", "ICU B", "ICU C", "ICU D")),
  admission_date = adm, age = as.integer(age),
  sex = factor(sex, levels = c("Female", "Male")), weight_kg = wt,
  diabetes = yn(diab), ckd = yn(ckd), heart_failure = yn(hf), hypertension = yn(htn),
  infection_source = factor(src, levels = c("Respiratory", "Urinary", "Abdominal",
                                            "Skin/soft tissue", "Other")),
  sofa = as.integer(sofa), apache_ii = as.integer(apache), lactate_mmol_l = lac_obs,
  map_mmhg = as.integer(map), vasopressor = yn(vaso), mech_vent = yn(mv),
  fluid_in_d1_ml = as.integer(inn[, 1]), fluid_out_d1_ml = as.integer(out[, 1]),
  fluid_in_d2_ml = as.integer(inn[, 2]), fluid_out_d2_ml = as.integer(out[, 2]),
  fluid_in_d3_ml = as.integer(inn[, 3]), fluid_out_d3_ml = as.integer(out[, 3]),
  aki_stage = as.integer(aki), rrt = yn(rrt), vent_free_days_28 = as.integer(vfd),
  icu_los_days = los, died_28d = yn(died), time_to_event_28d = as.integer(time)
)

# ----------------------------------------------------------------------------
# 2. THE CLEAN FILE = truth + the values that cleaning cannot recover
# ----------------------------------------------------------------------------
# The raw file will contain three impossible values (age 210, weight 7 kg, a
# negative day-2 output). Cleaning sets them to missing (a query goes to the
# site), so the clean file has NA there. A few APACHE II and MAP values were
# never recorded. Victims are drawn with a second seed so the cohort above
# never changes.
set.seed(SEED + 1)
no_lac   <- which(is.na(truth$lactate_mmol_l))
victims  <- sample(no_lac, 3)                        # age / weight / output errors
na_apache <- sample(setdiff(1:n, victims), 6)
na_map    <- sample(setdiff(1:n, c(victims, na_apache)), 4)

clean <- truth
clean$age[victims[1]]             <- NA_integer_
clean$weight_kg[victims[2]]       <- NA_real_
clean$fluid_out_d2_ml[victims[3]] <- NA_integer_
clean$apache_ii[na_apache]        <- NA_integer_
clean$map_mmhg[na_map]            <- NA_integer_

# Derived variables (01_clean.R derives them the same way)
clean <- clean |>
  mutate(
    cum_fluid_balance_d3_ml_kg = round((fluid_in_d1_ml + fluid_in_d2_ml + fluid_in_d3_ml -
                                        fluid_out_d1_ml - fluid_out_d2_ml - fluid_out_d3_ml) /
                                       weight_kg, 1),
    positive_balance_d3 = factor(ifelse(cum_fluid_balance_d3_ml_kg > 0, "Yes", "No"),
                                 levels = c("No", "Yes")),
    aki_any = factor(ifelse(aki_stage >= 1, "Yes", "No"), levels = c("No", "Yes"))
  ) |>
  relocate(cum_fluid_balance_d3_ml_kg, positive_balance_d3, .after = fluid_out_d3_ml) |>
  relocate(aki_any, .after = aki_stage)

saveRDS(clean, "fluid_icu_clean.rds")
write_csv(clean, "fluid_icu_clean.csv", na = "")

# ----------------------------------------------------------------------------
# 3. THE RAW FILE - as the four sites sent it
# ----------------------------------------------------------------------------
set.seed(SEED + 2)
raw <- clean |> select(-cum_fluid_balance_d3_ml_kg, -positive_balance_d3, -aki_any) |>
  mutate(across(everything(), as.character))

# (a) site names typed in different ways
i <- sample(1:n, 14)
raw$site[i] <- sapply(raw$site[i], function(s) {
  L <- substr(s, 5, 5)
  sample(c(paste0("icu ", tolower(L)), paste0("ICU-", L), paste0(s, " "), paste0("ICU", L)), 1)
})

# (b) mixed date formats: ISO, DD/MM/YYYY and DD-Mon-YYYY
d <- clean$admission_date
fmt <- sample(c("iso", "dmy", "mon"), n, TRUE, prob = c(.6, .25, .15))
raw$admission_date <- ifelse(fmt == "iso", format(d, "%Y-%m-%d"),
                      ifelse(fmt == "dmy", format(d, "%d/%m/%Y"),
                             paste0(format(d, "%d"), "-", month.abb[as.integer(format(d, "%m"))],
                                    "-", format(d, "%Y"))))

# (c) inconsistent sex codes
male_codes <- c("Male", "M", "m", "male"); fem_codes <- c("Female", "F", "f", "female", " Female")
raw$sex <- ifelse(raw$sex == "Male", sample(male_codes, n, TRUE, prob = c(.7, .15, .05, .1)),
                  sample(fem_codes, n, TRUE, prob = c(.68, .14, .05, .1, .03)))

# (d) Yes/No/Y/N/1/0 mixtures: ICU B sends 1/0; others mostly Yes/No with some Y/N/yes
yn_vars <- c("diabetes", "ckd", "heart_failure", "hypertension", "vasopressor", "mech_vent",
             "rrt", "died_28d")
for (v in yn_vars) {
  x <- raw[[v]]
  b <- clean$site == "ICU B"
  other <- sample(c("std", "short", "lower"), n, TRUE, prob = c(.85, .1, .05))
  raw[[v]] <- ifelse(b, ifelse(x == "Yes", "1", "0"),
              ifelse(other == "short", substr(x, 1, 1),
              ifelse(other == "lower", tolower(x), x)))
}

# (e) lactate: ICU C reports in mg/dL (1 mmol/L = 9.01 mg/dL)
cc <- which(clean$site == "ICU C" & !is.na(clean$lactate_mmol_l))
raw$lactate_mmol_l[cc] <- format(round(clean$lactate_mmol_l[cc] * 9.01, 1), nsmall = 1, trim = TRUE)

# (f) missing-value sentinels: lactate 999 / -99 / blank, APACHE II -99, MAP 999
lac_na <- which(is.na(clean$lactate_mmol_l))
s999 <- sample(lac_na, 12); s99 <- sample(setdiff(lac_na, s999), 9)
raw$lactate_mmol_l[s999] <- "999"
raw$lactate_mmol_l[s99]  <- "-99"
raw$apache_ii[na_apache] <- "-99"
raw$map_mmhg[na_map]     <- "999"

# (g) impossible values (cleaning sets them to missing and raises a query)
raw$age[victims[1]]             <- "210"
raw$weight_kg[victims[2]]       <- "7"
raw$fluid_out_d2_ml[victims[3]] <- as.character(-truth$fluid_out_d2_ml[victims[3]])

# (h) messy column names, as typed in a spreadsheet
names(raw) <- c("Study ID", "Site", "Admission Date", "Age", "Sex", "Weight (kg)", "Diabetes",
                "CKD", "Heart failure", "Hypertension", "Infection source", "SOFA", "APACHE II",
                "Lactate (mmol/L)", "MAP (mmHg)", "Vasopressor", "Mech vent",
                "Fluid in D1 (ml)", "Fluid out D1 (ml)", "Fluid in D2 (ml)", "Fluid out D2 (ml)",
                "Fluid in D3 (ml)", "Fluid out D3 (ml)", "AKI stage (KDIGO)", "RRT", "VFD 28",
                "ICU LOS (days)", "Died 28d", "Time to event 28d (days)")

# (i) three records entered twice (exact duplicates), mixed into the file
dup_rows <- sample(1:n, 3)
raw <- bind_rows(raw, raw[dup_rows, ])
raw <- raw[order(c(1:n, sample(1:n, 3) + 0.5)), ]   # placed elsewhere in the file

raw[is.na(raw)] <- ""
write_csv(raw, "fluid_icu_raw.csv", na = "")
write_xlsx(raw, "fluid_icu_raw.xlsx")

# ----------------------------------------------------------------------------
# 4. CHECK THE TEACHING FEATURES (printed for the instructor)
# ----------------------------------------------------------------------------
cat("\nFLUID-ICU (SIMULATED) written: clean n =", nrow(clean), "; raw rows =", nrow(raw), "\n")
cat("28-day mortality:", round(100 * mean(clean$died_28d == "Yes"), 1), "%\n")
cat("Positive balance by day 3:", round(100 * mean(clean$positive_balance_d3 == "Yes", na.rm = TRUE), 1), "%\n")
cat("Lactate missing:", round(100 * mean(is.na(clean$lactate_mmol_l)), 1), "%\n")
or <- function(m, term = "positive_balance_d3Yes") {
  b <- summary(m)$coef[term, ]
  sprintf("%.2f (%.2f to %.2f), p = %.3f", exp(b[1]), exp(b[1] - 1.96 * b[2]),
          exp(b[1] + 1.96 * b[2]), b[4])
}
m_crude <- glm(died_28d ~ positive_balance_d3, binomial, clean)
m_adj   <- glm(died_28d ~ positive_balance_d3 + age + sofa + lactate_mmol_l + vasopressor +
                 mech_vent + ckd, binomial, clean)
m_int   <- glm(died_28d ~ positive_balance_d3 * heart_failure + age + sofa + lactate_mmol_l +
                 vasopressor + mech_vent + ckd, binomial, clean)
cat("Crude OR   :", or(m_crude), "\n")
cat("Adjusted OR:", or(m_adj), "\n")
cat("Interaction p (balance x heart failure):",
    round(summary(m_int)$coef["positive_balance_d3Yes:heart_failureYes", 4], 3), "\n")
