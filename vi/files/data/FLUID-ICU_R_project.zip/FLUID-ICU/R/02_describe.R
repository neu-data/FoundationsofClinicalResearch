# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 02  LIVE DEMO: DESCRIBE THE DATA - TABLE 1 AND FIGURES   (Session 5, block 5.4)
#
# Study: FLUID-ICU - SIMULATED cohort, 620 adults with sepsis, 4 ICUs.
#        Not real patients.
# Input : fluid_icu_clean.rds
# Output: output/tables/table1_by_balance.(docx|csv)
#         output/figures/fig_shape_age_lactate.png, fig_fluid_balance_hist.png,
#         fig_sofa_by_group.png, fig_infection_source.png, fig_los_survivors.png
# The figures are the ones on the Session 5 slides (5.3 and 5.4).
#
# Run from the Course/Data folder. Run block by block and talk about each output.
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

if (!interactive()) pdf(NULL)   # when run with Rscript: no stray Rplots.pdf
suppressPackageStartupMessages({
  library(tidyverse)
  library(gtsummary)
  library(flextable)
})
dir.create("output/tables",  recursive = TRUE, showWarnings = FALSE)
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)

# Neudata colours: teal and blue for the two groups; red only for harm
pal <- c(teal = "#0D7377", blue = "#0B376C", lteal = "#5FA39B", sky = "#0070C0", grey = "#8A99A3")
theme_set(theme_minimal(base_size = 14) +
            theme(panel.grid.minor = element_blank(), plot.title.position = "plot"))

# ----------------------------------------------------------------------------
# 1. Load the clean data and look at it
# ----------------------------------------------------------------------------
icu <- readRDS("fluid_icu_clean.rds")
dim(icu)              # 620 patients, 32 variables
glimpse(icu)

# The exposure: cumulative fluid balance by day 3 (ml/kg), and the yes/no version
summary(icu$cum_fluid_balance_d3_ml_kg)
icu |> count(positive_balance_d3)       # 2 patients have no balance (weight / output missing)

# ----------------------------------------------------------------------------
# 2. Which summary? Look at the SHAPE first
# ----------------------------------------------------------------------------
# Symmetric -> mean (SD). Skewed -> median (IQR).
# 2a. Draw each variable before choosing its summary
p_shape <- icu |>
  select(`Age, years` = age, `Lactate, mmol/L` = lactate_mmol_l) |>
  pivot_longer(everything(), names_to = "variable", values_to = "value") |>
  filter(!is.na(value)) |>
  ggplot(aes(value)) +
  geom_histogram(bins = 30, fill = pal[["teal"]], colour = "white") +
  facet_wrap(~ variable, scales = "free") +
  labs(x = NULL, y = "Number of patients")
p_shape
ggsave("output/figures/fig_shape_age_lactate.png", p_shape, width = 9, height = 4, dpi = 300, bg = "white")

# 2b. A number to back up the picture: in a symmetric variable the mean is close to the median
icu |> summarise(across(c(age, lactate_mmol_l),
                        list(mean = ~ mean(.x, na.rm = TRUE), median = ~ median(.x, na.rm = TRUE))))
# Age: mean 62.6, median 62, a bell shape -> mean (SD).
# Lactate: mean 2.9, median 2.6, a long right tail -> median (IQR).

# 2c. Now the summary that fits each shape
icu |> summarise(mean_age = mean(age, na.rm = TRUE), sd_age = sd(age, na.rm = TRUE),
                 median_lactate = median(lactate_mmol_l, na.rm = TRUE),
                 q1 = quantile(lactate_mmol_l, .25, na.rm = TRUE),
                 q3 = quantile(lactate_mmol_l, .75, na.rm = TRUE))

# ----------------------------------------------------------------------------
# 3. TABLE 1 - baseline characteristics by fluid-balance group
# ----------------------------------------------------------------------------
# Table 1 describes WHO was studied. In an observational study it shows how the
# groups differ at baseline (here: the positive-balance group is sicker).
# We do not add p-values to Table 1: it describes, it does not test.
t1_data <- icu |>
  filter(!is.na(positive_balance_d3)) |>
  mutate(balance_group = factor(positive_balance_d3, levels = c("No", "Yes"),
                                labels = c("Negative balance", "Positive balance")))

table1 <- t1_data |>
  select(balance_group, age, sex, weight_kg, diabetes, ckd, heart_failure, hypertension,
         infection_source, sofa, apache_ii, lactate_mmol_l, map_mmhg, vasopressor, mech_vent) |>
  tbl_summary(
    by = balance_group,
    label = list(age ~ "Age, years", sex ~ "Sex", weight_kg ~ "Weight, kg",
                 diabetes ~ "Diabetes", ckd ~ "Chronic kidney disease",
                 heart_failure ~ "Heart failure", hypertension ~ "Hypertension",
                 infection_source ~ "Source of infection", sofa ~ "SOFA score",
                 apache_ii ~ "APACHE II score", lactate_mmol_l ~ "Lactate, mmol/L",
                 map_mmhg ~ "Mean arterial pressure, mmHg",
                 vasopressor ~ "Vasopressor on admission",
                 mech_vent ~ "Mechanical ventilation"),
    type = list(c(diabetes, ckd, heart_failure, hypertension, vasopressor, mech_vent) ~ "dichotomous"),
    value = list(c(diabetes, ckd, heart_failure, hypertension, vasopressor, mech_vent) ~ "Yes"),
    statistic = list(c(age, weight_kg) ~ "{mean} ({sd})",
                     c(sofa, apache_ii, lactate_mmol_l, map_mmhg) ~ "{median} ({p25}, {p75})"),
    digits = list(c(age, weight_kg) ~ 1, lactate_mmol_l ~ 1),
    missing_text = "Missing"
  ) |>
  add_overall(last = FALSE) |>
  modify_caption("**Table 1. Baseline characteristics by cumulative fluid balance at day 3 (FLUID-ICU, simulated)**") |>
  bold_labels()
table1

# Save: Word for the manuscript, CSV for anyone
table1 |> as_flex_table() |> save_as_docx(path = "output/tables/table1_by_balance.docx")
table1 |> as_tibble() |>
  rename_with(~ gsub("\\*\\*|\n", "", .x)) |>
  mutate(across(everything(), ~ gsub("__", "", .x))) |>
  write_csv("output/tables/table1_by_balance.csv", na = "")

# ----------------------------------------------------------------------------
# 4. FIGURE: histogram of the cumulative fluid balance (continuous -> histogram)
# ----------------------------------------------------------------------------
fb <- icu |> filter(!is.na(cum_fluid_balance_d3_ml_kg))
fb_q <- quantile(fb$cum_fluid_balance_d3_ml_kg, c(.25, .5, .75))
fb_q                                    # median 8.8, IQR -10.3 to 26.2 ml/kg
p_hist <- ggplot(fb, aes(cum_fluid_balance_d3_ml_kg, fill = positive_balance_d3)) +
  annotate("rect", xmin = fb_q[[1]], xmax = fb_q[[3]], ymin = -Inf, ymax = Inf, fill = "grey85", alpha = .5) +
  geom_histogram(binwidth = 5, boundary = 0, colour = "white") +
  geom_vline(xintercept = 0, linetype = 2) +
  geom_vline(xintercept = fb_q[[2]], colour = "black", linewidth = 1) +
  annotate("text", x = fb_q[[3]] + 3, y = 50, hjust = 0, size = 4.5,
           label = sprintf("median %.1f ml/kg\ngrey band: IQR %.1f to %.1f", fb_q[[2]], fb_q[[1]], fb_q[[3]])) +
  scale_fill_manual(values = c(No = pal[["lteal"]], Yes = pal[["blue"]]),
                    labels = c("Negative balance", "Positive balance"), name = NULL) +
  labs(x = "Cumulative fluid balance at day 3 (ml/kg)", y = "Number of patients") +
  theme(legend.position = "top")
p_hist
ggsave("output/figures/fig_fluid_balance_hist.png", p_hist, width = 8, height = 4.5, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 5. FIGURE: SOFA score by group (number by group -> boxplot)
# ----------------------------------------------------------------------------
# The positive-balance group is sicker: the first sign of confounding by indication.
# One dot per patient, side by side for the same score (up to 22 per row)
sofa_dots <- t1_data |>
  filter(!is.na(sofa)) |>
  group_by(balance_group, sofa) |>
  mutate(j = row_number() - 1, n_score = n(), row = j %/% 22, n_rows = (n_score - 1) %/% 22 + 1,
         in_row = pmin(22, n_score - row * 22),
         x = as.numeric(balance_group) + (j %% 22 - (in_row - 1) / 2) * 0.024,
         y = sofa + (row - (n_rows - 1) / 2) * 0.15) |>
  ungroup()
sofa_med <- t1_data |> group_by(balance_group) |>
  summarise(med = median(sofa, na.rm = TRUE), n = n(), .groups = "drop")
sofa_med                                # medians 6 and 8
p_box <- ggplot(t1_data, aes(balance_group, sofa)) +
  geom_boxplot(aes(fill = balance_group), width = .5, outlier.shape = NA, colour = "grey40") +
  geom_point(data = sofa_dots, aes(x, y), inherit.aes = FALSE, size = .8, alpha = .35) +
  geom_text(data = sofa_med, aes(as.numeric(balance_group) + .3, med, label = paste("median", med)),
            hjust = 0, fontface = "bold", size = 4.5) +
  scale_fill_manual(values = c(pal[["lteal"]], pal[["blue"]]), guide = "none") +
  scale_x_discrete(labels = paste0(levels(t1_data$balance_group), "\n(n = ", sofa_med$n, ")")) +
  coord_cartesian(clip = "off") +
  theme(plot.margin = margin(10, 90, 10, 10)) +
  labs(x = NULL, y = "SOFA score on admission")
p_box
ggsave("output/figures/fig_sofa_by_group.png", p_box, width = 6, height = 4.5, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 6. FIGURE: source of infection (categories -> bar chart, sorted)
# ----------------------------------------------------------------------------
p_bar <- icu |>
  count(infection_source) |>
  mutate(pct = 100 * n / sum(n)) |>
  ggplot(aes(x = fct_reorder(infection_source, n), y = n)) +
  geom_col(fill = pal[["teal"]], width = .7) +
  geom_text(aes(label = sprintf("%d (%.0f%%)", n, pct)), hjust = -.1, size = 4.5) +
  coord_flip() +
  scale_y_continuous(expand = expansion(mult = c(0, .2))) +
  labs(x = NULL, y = "Number of patients")
p_bar
ggsave("output/figures/fig_infection_source.png", p_bar, width = 7, height = 4, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 7. FIGURE: ICU stay in 28-day survivors (a skewed outcome, Q5)
# ----------------------------------------------------------------------------
los <- t1_data |> filter(died_28d == "No")
los_sum <- los |> summarise(n = n(), median = median(icu_los_days), mean = mean(icu_los_days))
los_sum                                 # 439 survivors, median 6.2, mean 7.5 days
p_los <- ggplot(los, aes(icu_los_days)) +
  geom_histogram(binwidth = 1, boundary = 0, closed = "left", fill = pal[["teal"]], colour = "white") +
  geom_vline(xintercept = los_sum$median, colour = pal[["blue"]], linewidth = 1) +
  geom_vline(xintercept = los_sum$mean, colour = "#E07B00", linewidth = 1, linetype = 2) +
  annotate("text", x = los_sum$median - .5, y = 60, hjust = 1, colour = pal[["blue"]], fontface = "bold",
           size = 4.5, label = sprintf("median %.1f", los_sum$median)) +
  annotate("text", x = los_sum$mean + .5, y = 60, hjust = 0, colour = "#E07B00", fontface = "bold",
           size = 4.5, label = sprintf("mean %.1f", los_sum$mean)) +
  annotate("text", x = 27, y = 25, size = 4.5, label = "a few very long stays\npull the mean up") +
  labs(x = sprintf("ICU length of stay, 28-day survivors (days), n = %d", los_sum$n), y = "Number of patients")
p_los
ggsave("output/figures/fig_los_survivors.png", p_los, width = 8, height = 4.5, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 8. Outcomes at a glance (described, not yet compared)
# ----------------------------------------------------------------------------
icu |> summarise(
  died_28d_pct   = 100 * mean(died_28d == "Yes"),
  aki_any_pct    = 100 * mean(aki_any == "Yes"),
  rrt_pct        = 100 * mean(rrt == "Yes"),
  vfd_median     = median(vent_free_days_28),
  los_median     = median(icu_los_days),
  los_mean       = mean(icu_los_days))      # mean > median: right-skewed

# TEACHING POINT: ICU length of stay has a long right tail - the mean is pulled
# up by a few long stays. Report the median (IQR).
cat("\n02_describe.R finished: Table 1 and 5 figures saved in output/\n")
