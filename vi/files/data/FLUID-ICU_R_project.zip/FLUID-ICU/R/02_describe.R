# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 02  LIVE DEMO: DESCRIBE THE DATA - TABLE 1 AND FIGURES   (Session 5, block 5.4)
#
# Study: FLUID-ICU - SIMULATED cohort, 620 adults with sepsis, 4 ICUs.
#        Not real patients.
# Input : fluid_icu_clean.rds
# Output: output/tables/table1_by_balance.(docx|csv)
#         output/figures/fig_fluid_balance_hist.png, fig_sofa_by_group.png,
#         fig_infection_source.png
#
# Run from the Course/Data folder. Run block by block and talk about each output.
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

if (!interactive()) pdf(NULL)   # when run with Rscript: no stray Rplots.pdf
suppressPackageStartupMessages({
  library(tidyverse)
  library(gtsummary)
  library(flextable)
})
dir.create("output/tables",  recursive = TRUE, showWarnings = FALSE)
dir.create("output/figures", recursive = TRUE, showWarnings = FALSE)

# Neudata colours: teal and blue for the two groups; red only for harm
pal <- c(teal = "#0D7377", blue = "#0B376C", lteal = "#5FA39B", sky = "#0070C0", grey = "#8A99A3")
theme_set(theme_minimal(base_size = 14) +
            theme(panel.grid.minor = element_blank(), plot.title.position = "plot"))

# ----------------------------------------------------------------------------
# 1. Load the clean data and look at it
# ----------------------------------------------------------------------------
icu <- readRDS("fluid_icu_clean.rds")
dim(icu)              # 620 patients, 32 variables
glimpse(icu)

# The exposure: cumulative fluid balance by day 3 (ml/kg), and the yes/no version
summary(icu$cum_fluid_balance_d3_ml_kg)
icu |> count(positive_balance_d3)       # 2 patients have no balance (weight / output missing)

# ----------------------------------------------------------------------------
# 2. Which summary? Look at the SHAPE first
# ----------------------------------------------------------------------------
# Symmetric -> mean (SD). Skewed -> median (IQR).
icu |> summarise(mean_age = mean(age, na.rm = TRUE), sd_age = sd(age, na.rm = TRUE),
                 median_lactate = median(lactate_mmol_l, na.rm = TRUE),
                 q1 = quantile(lactate_mmol_l, .25, na.rm = TRUE),
                 q3 = quantile(lactate_mmol_l, .75, na.rm = TRUE))

# ----------------------------------------------------------------------------
# 3. TABLE 1 - baseline characteristics by fluid-balance group
# ----------------------------------------------------------------------------
# Table 1 describes WHO was studied. In an observational study it shows how the
# groups differ at baseline (here: the positive-balance group is sicker).
# We do not add p-values to Table 1: it describes, it does not test.
t1_data <- icu |>
  filter(!is.na(positive_balance_d3)) |>
  mutate(balance_group = factor(positive_balance_d3, levels = c("No", "Yes"),
                                labels = c("Negative balance", "Positive balance")))

table1 <- t1_data |>
  select(balance_group, age, sex, weight_kg, diabetes, ckd, heart_failure, hypertension,
         infection_source, sofa, apache_ii, lactate_mmol_l, map_mmhg, vasopressor, mech_vent) |>
  tbl_summary(
    by = balance_group,
    label = list(age ~ "Age, years", sex ~ "Sex", weight_kg ~ "Weight, kg",
                 diabetes ~ "Diabetes", ckd ~ "Chronic kidney disease",
                 heart_failure ~ "Heart failure", hypertension ~ "Hypertension",
                 infection_source ~ "Source of infection", sofa ~ "SOFA score",
                 apache_ii ~ "APACHE II score", lactate_mmol_l ~ "Lactate, mmol/L",
                 map_mmhg ~ "Mean arterial pressure, mmHg",
                 vasopressor ~ "Vasopressor on admission",
                 mech_vent ~ "Mechanical ventilation"),
    type = list(c(diabetes, ckd, heart_failure, hypertension, vasopressor, mech_vent) ~ "dichotomous"),
    value = list(c(diabetes, ckd, heart_failure, hypertension, vasopressor, mech_vent) ~ "Yes"),
    statistic = list(c(age, weight_kg) ~ "{mean} ({sd})",
                     c(sofa, apache_ii, lactate_mmol_l, map_mmhg) ~ "{median} ({p25}, {p75})"),
    digits = list(c(age, weight_kg) ~ 1, lactate_mmol_l ~ 1),
    missing_text = "Missing"
  ) |>
  add_overall(last = FALSE) |>
  modify_caption("**Table 1. Baseline characteristics by cumulative fluid balance at day 3 (FLUID-ICU, simulated)**") |>
  bold_labels()
table1

# Save: Word for the manuscript, CSV for anyone
table1 |> as_flex_table() |> save_as_docx(path = "output/tables/table1_by_balance.docx")
table1 |> as_tibble() |>
  rename_with(~ gsub("\\*\\*|\n", "", .x)) |>
  mutate(across(everything(), ~ gsub("__", "", .x))) |>
  write_csv("output/tables/table1_by_balance.csv", na = "")

# ----------------------------------------------------------------------------
# 4. FIGURE: histogram of the cumulative fluid balance (continuous -> histogram)
# ----------------------------------------------------------------------------
p_hist <- ggplot(icu |> filter(!is.na(cum_fluid_balance_d3_ml_kg)),
                 aes(cum_fluid_balance_d3_ml_kg, fill = positive_balance_d3)) +
  geom_histogram(binwidth = 5, boundary = 0, colour = "white") +
  geom_vline(xintercept = 0, linetype = 2) +
  scale_fill_manual(values = c(No = pal[["lteal"]], Yes = pal[["blue"]]),
                    labels = c("Negative balance", "Positive balance"), name = NULL) +
  labs(x = "Cumulative fluid balance at day 3 (ml/kg)", y = "Number of patients") +
  theme(legend.position = "top")
p_hist
ggsave("output/figures/fig_fluid_balance_hist.png", p_hist, width = 8, height = 4.5, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 5. FIGURE: SOFA score by group (number by group -> boxplot)
# ----------------------------------------------------------------------------
# The positive-balance group is sicker: the first sign of confounding by indication.
p_box <- ggplot(t1_data, aes(balance_group, sofa, fill = balance_group)) +
  geom_boxplot(width = .5, outlier.shape = NA, alpha = .9) +
  geom_jitter(width = .15, height = .2, alpha = .25, size = 1) +
  scale_fill_manual(values = c(pal[["lteal"]], pal[["blue"]]), guide = "none") +
  labs(x = NULL, y = "SOFA score on admission")
p_box
ggsave("output/figures/fig_sofa_by_group.png", p_box, width = 6, height = 4.5, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 6. FIGURE: source of infection (categories -> bar chart, sorted)
# ----------------------------------------------------------------------------
p_bar <- icu |>
  count(infection_source) |>
  mutate(pct = 100 * n / sum(n)) |>
  ggplot(aes(x = fct_reorder(infection_source, n), y = n)) +
  geom_col(fill = pal[["teal"]], width = .7) +
  geom_text(aes(label = sprintf("%d (%.0f%%)", n, pct)), hjust = -.1, size = 4.5) +
  coord_flip() +
  scale_y_continuous(expand = expansion(mult = c(0, .2))) +
  labs(x = NULL, y = "Number of patients")
p_bar
ggsave("output/figures/fig_infection_source.png", p_bar, width = 7, height = 4, dpi = 300, bg = "white")

# ----------------------------------------------------------------------------
# 7. Outcomes at a glance (described, not yet compared)
# ----------------------------------------------------------------------------
icu |> summarise(
  died_28d_pct   = 100 * mean(died_28d == "Yes"),
  aki_any_pct    = 100 * mean(aki_any == "Yes"),
  rrt_pct        = 100 * mean(rrt == "Yes"),
  vfd_median     = median(vent_free_days_28),
  los_median     = median(icu_los_days),
  los_mean       = mean(icu_los_days))      # mean > median: right-skewed

# TEACHING POINT: ICU length of stay has a long right tail - the mean is pulled
# up by a few long stays. Report the median (IQR).
cat("\n02_describe.R finished: Table 1 and 3 figures saved in output/\n")
