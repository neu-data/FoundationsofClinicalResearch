# ============================================================================
# Foundations of Clinical Research - Level 2 (From Data to Publication)
# 06  BUILD THE FIVE GROUP RESULTS PACKS + key_results.md + slide data
#
# Study: FLUID-ICU - SIMULATED cohort, 620 adults with sepsis, 4 ICUs.
#        Not real patients.
# Input : fluid_icu_clean.rds
# Output: results_packs/Q1 ... Q5/  (results_pack_QN.md, tables/*.csv|docx,
#                                    figures/*.png)
#         results_packs/Results_Pack_QN.docx   (printable)
#         key_results.md                       (every number the slides quote)
#         output/slide_data/*.csv              (data for the slide figures)
#         Vietnamese versions from the same numbers (last section of this script):
#         results_packs/QN/results_pack_QN_VN.md, tables/*_VN.csv|docx, figures/*_VN.png,
#         results_packs/Results_Pack_QN_VN.docx, key_results_VN.md
#
# PDFs of the packs are made from the .docx with Microsoft Word (site/build.py does this for EN;
# for VN run from Course/Data:  python results_packs/make_vn_pdfs.py).
#
# This is a course-team script (not a live demo). It repeats the models of
# scripts 03-05 with exactly the same specifications, so all numbers agree.
# Run from the Course/Data folder:  Rscript R/06_results_packs.R  (~1 minute)
# Author: Neudata | #ClearDataClearImpact
# ============================================================================

if (!interactive()) pdf(NULL)   # when run with Rscript: no stray Rplots.pdf
suppressPackageStartupMessages({
  library(tidyverse)
  library(gtsummary)
  library(flextable)
  library(officer)
  library(broom)
  library(survival)
  library(survminer)
  library(mice)
})

icu_all <- readRDS("fluid_icu_clean.rds")
icu     <- icu_all |> filter(!is.na(positive_balance_d3))       # 618 with an exposure
dir.create("output/slide_data", recursive = TRUE, showWarnings = FALSE)
for (q in paste0("Q", 1:5)) {
  dir.create(file.path("results_packs", q, "tables"),  recursive = TRUE, showWarnings = FALSE)
  dir.create(file.path("results_packs", q, "figures"), recursive = TRUE, showWarnings = FALSE)
}

pal <- c(teal = "#0D7377", blue = "#0B376C", lteal = "#5FA39B", sky = "#0070C0",
         grey = "#8A99A3", red = "#B23B2E")
grp_cols <- c("Negative balance" = pal[["lteal"]], "Positive balance" = pal[["blue"]])
theme_set(theme_minimal(base_size = 13) + theme(panel.grid.minor = element_blank()))

# ---------------------------------------------------------------- formatting
f1 <- function(x) sprintf("%.1f", round(x, 1) + 0)
f2 <- function(x) sprintf("%.2f", round(x, 2) + 0)
pf <- function(p) ifelse(p < 0.001, "<0.001", sprintf("%.3f", p))
est_ci <- function(e, l, u, f = f2) paste0(f(e), " (95% CI ", f(l), " to ", f(u), ")")
npct <- function(x) sprintf("%d/%d (%.1f%%)", sum(x), length(x), 100 * mean(x))
med_iqr <- function(x, f = f1) {
  q <- quantile(x, c(.5, .25, .75), na.rm = TRUE)
  paste0(f(q[1]), " (", f(q[2]), " to ", f(q[3]), ")")
}
or_row <- function(fit, term) {
  tidy(fit, exponentiate = TRUE, conf.int = TRUE) |> filter(term == !!term)
}

# Pre-specified confounders (SAP section 7) - the same set for every question
CONF <- "age + sofa + lactate_mmol_l + vasopressor + mech_vent + ckd"
KR <- list()   # key results, collected as we go

# ---------------------------------------------------------------- pack builder
# A pack is a list of blocks; the same blocks are written to Markdown and Word.
new_pack <- function() list()
H  <- function(pk, text, level = 2) c(pk, list(list(type = "h", text = text, level = level)))
P  <- function(pk, text) c(pk, list(list(type = "p", text = text)))
B  <- function(pk, items) c(pk, list(list(type = "b", items = items)))
TB <- function(pk, df, caption, file, ft = NULL, note = NULL) {
  c(pk, list(list(type = "t", df = df, caption = caption, file = file, ft = ft, note = note)))
}
FG <- function(pk, file, caption, w, h) {
  c(pk, list(list(type = "f", file = file, caption = caption, w = w, h = h)))
}

save_table <- function(df, q, name, ft = NULL) {
  write_csv(df, file.path("results_packs", q, "tables", paste0(name, ".csv")), na = "")
  if (is.null(ft)) ft <- df |> flextable() |> theme_vanilla()
  ft <- ft |> fontsize(size = 9, part = "all") |> flextable::font(fontname = "Arial", part = "all") |>
    autofit() |> set_table_properties(layout = "autofit", width = 1)
  ft_file <- if (startsWith(name, "table1")) add_footer_lines(ft, t1_note) else ft   # the docx alone also says what Table 1 is
  save_as_docx(ft_file, path = file.path("results_packs", q, "tables", paste0(name, ".docx")))
  invisible(ft)
}
save_fig <- function(p, q, name, w = 7, h = 4.5) {
  f <- file.path("results_packs", q, "figures", paste0(name, ".png"))
  ggsave(f, p, width = w, height = h, dpi = 300, bg = "white")
  f
}

md_escape <- function(x) sub("^   ", "&emsp;", gsub("\\|", "/", x))   # indent Table 1 levels
render_md <- function(pk, file, q, files_txt = c("Files", "and")) {
  out <- character()
  for (b in pk) {
    out <- c(out, switch(b$type,
      h = c(paste(strrep("#", b$level), b$text), ""),
      p = c(b$text, ""),
      b = c(paste("-", b$items), ""),
      t = c(paste0("**", b$caption, "**"), "",
            knitr::kable(b$df |> mutate(across(everything(), ~ md_escape(as.character(.x)))),
                         format = "pipe", align = "l"),
            "", if (!is.null(b$note)) c(paste0("*", b$note, "*"), "") else NULL,
            paste0(files_txt[1], ": `tables/", b$file, ".csv` ", files_txt[2], " `tables/", b$file, ".docx`"), ""),
      f = c(paste0("![", b$caption, "](figures/", basename(b$file), ")"), "",
            paste0("*", b$caption, "* (`figures/", basename(b$file), "`)"), "")))
  }
  writeLines(out, file, useBytes = TRUE)
}
md_fpar <- function(text, size = 10.5) {
  parts <- strsplit(text, "\\*\\*")[[1]]
  runs <- lapply(seq_along(parts), function(i) {
    ftext(gsub("`", "", parts[i]),
          fp_text(font.size = size, bold = i %% 2 == 0, font.family = "Arial"))
  })
  do.call(fpar, runs)
}
render_docx <- function(pk, file, title,
                        note = "FLUID-ICU is a SIMULATED dataset made for teaching. No real patients. Neudata | Foundations of Clinical Research, Level 1") {
  doc <- read_docx()
  doc <- body_add_fpar(doc, fpar(ftext(title, fp_text(font.size = 18, bold = TRUE,
                                                      color = pal[["teal"]], font.family = "Arial"))))
  doc <- body_add_fpar(doc, fpar(ftext(
    note,
    fp_text(font.size = 9, italic = TRUE, color = pal[["grey"]], font.family = "Arial"))))
  for (b in pk) {
    if (b$type == "h") {
      doc <- body_add_fpar(doc, fpar(ftext(b$text, fp_text(font.size = if (b$level <= 2) 14 else 12,
                                                           bold = TRUE, color = pal[["blue"]],
                                                           font.family = "Arial")),
                                     fp_p = fp_par(padding.top = 10, padding.bottom = 4)))
    } else if (b$type == "p") {
      doc <- body_add_fpar(doc, md_fpar(sub("^> ", "", b$text)))
    } else if (b$type == "b") {
      for (it in b$items) doc <- body_add_fpar(doc, md_fpar(paste0("•  ", it)))
    } else if (b$type == "t") {
      doc <- body_add_fpar(doc, fpar(ftext(b$caption, fp_text(font.size = 10, bold = TRUE, font.family = "Arial")),
                                     fp_p = fp_par(padding.top = 8)))
      ft <- if (!is.null(b$ft)) b$ft else b$df |> flextable() |> theme_vanilla() |>
        fontsize(size = 9, part = "all") |> flextable::font(fontname = "Arial", part = "all") |>
        autofit() |> set_table_properties(layout = "autofit", width = 1)
      doc <- body_add_flextable(doc, ft)
      if (!is.null(b$note)) doc <- body_add_fpar(doc, fpar(ftext(b$note, fp_text(font.size = 8.5, italic = TRUE, font.family = "Arial"))))
    } else if (b$type == "f") {
      w <- 6.3; h <- w * b$h / b$w
      doc <- body_add_img(doc, src = b$file, width = w, height = h)
      doc <- body_add_fpar(doc, fpar(ftext(b$caption, fp_text(font.size = 9, italic = TRUE, font.family = "Arial"))))
    }
  }
  print(doc, target = file)
}

# ---------------------------------------------------------------- Table 1 helper
t1_vars <- c("age", "sex", "weight_kg", "diabetes", "ckd", "heart_failure", "hypertension",
             "infection_source", "sofa", "apache_ii", "lactate_mmol_l", "map_mmhg",
             "vasopressor", "mech_vent")
t1_labels <- list(age ~ "Age, years", sex ~ "Sex", weight_kg ~ "Weight, kg",
                  diabetes ~ "Diabetes", ckd ~ "Chronic kidney disease",
                  heart_failure ~ "Heart failure", hypertension ~ "Hypertension",
                  infection_source ~ "Source of infection", sofa ~ "SOFA score",
                  apache_ii ~ "APACHE II score", lactate_mmol_l ~ "Lactate, mmol/L",
                  map_mmhg ~ "Mean arterial pressure, mmHg",
                  vasopressor ~ "Vasopressor on admission", mech_vent ~ "Mechanical ventilation",
                  cum_fluid_balance_d3_ml_kg ~ "Cumulative fluid balance day 3, ml/kg")
make_t1 <- function(data, by, vars = t1_vars) {
  yn <- intersect(c("diabetes", "ckd", "heart_failure", "hypertension", "vasopressor", "mech_vent"), vars)
  data |> select(all_of(c(by, vars))) |>
    tbl_summary(by = all_of(by), label = t1_labels[sapply(t1_labels, function(f) all.vars(f)[1] %in% vars)],
                type = list(all_of(yn) ~ "dichotomous"), value = list(all_of(yn) ~ "Yes"),
                statistic = list(any_of(c("age", "weight_kg")) ~ "{mean} ({sd})",
                                 any_of(c("sofa", "apache_ii", "lactate_mmol_l", "map_mmhg",
                                          "cum_fluid_balance_d3_ml_kg")) ~ "{median} ({p25}, {p75})"),
                digits = list(any_of(c("age", "weight_kg", "lactate_mmol_l", "cum_fluid_balance_d3_ml_kg")) ~ 1),
                missing_text = "Missing") |>
    add_overall(last = FALSE) |> bold_labels()
}
t1_df <- function(t1) {
  df <- as_tibble(t1)
  names(df) <- gsub("\\*\\*", "", gsub("\n", " ", names(df)))
  names(df)[1] <- "Characteristic"
  df |> mutate(Characteristic = if_else(grepl("^__", Characteristic),
                                        gsub("__", "", Characteristic),
                                        paste0("   ", Characteristic)),
               across(everything(), ~ replace_na(.x, "")))
}
t1_note <- paste("Mean (SD); n (%); median (Q1, Q3). Missing = number of patients without that value.",
                 "Table 1 describes the patients at ICU admission only. The outcomes, such as 28-day death, are in the main results.")

# Common pack sections -----------------------------------------------------
std_header <- function(pk, q, question, design, outcome, exposure, sample) {
  pk |>
    P(paste0("> **SIMULATED DATA: NOT REAL PATIENTS.** FLUID-ICU was generated by computer for this course. ",
             "Write your manuscript as a training exercise and state clearly that the data are simulated.")) |>
    H("1. The question") |> P(paste0("**", question, "**")) |>
    H("2. Design and data") |>
    B(c(design,
        "Setting: 4 ICUs (ICU A-D), consecutive adults with sepsis, enrolment January 2023 to December 2024.",
        paste0("Exposure: ", exposure), paste0("Outcome: ", outcome),
        paste0("Analysis sample: ", sample),
        "Pre-specified confounders (SAP): age, SOFA score, lactate, vasopressor, mechanical ventilation, chronic kidney disease.",
        "Software: R 4.6 (packages gtsummary, survival, mice). Scripts: Course/Data/R/."))
}
strobe_block <- function(pk, items) {
  pk |> H("Which STROBE items this pack helps you write") |> B(items)
}

# Participant flow (shared) -------------------------------------------------
n_all <- nrow(icu_all); n_exp <- nrow(icu)
n_cc  <- sum(complete.cases(icu[, c("age", "sofa", "lactate_mmol_l", "vasopressor", "mech_vent", "ckd")]))
flow_text <- paste0("Participant flow: ", n_all, " patients enrolled -> ", n_all - n_exp,
                    " without a day-3 fluid balance (weight or output missing after cleaning) -> ",
                    n_exp, " in the exposure analysis -> ", n_exp - n_cc,
                    " without lactate (or age) -> ", n_cc, " in the complete-case adjusted model.")
KR$flow <- flow_text

# ===========================================================================
# MULTIPLE IMPUTATION (identical to 05_missing.R)
# ===========================================================================
imp_vars <- icu_all |>
  select(died_28d, lactate_mmol_l, age, sex, sofa, apache_ii, map_mmhg, vasopressor,
         mech_vent, ckd, diabetes, heart_failure, site, positive_balance_d3, infection_source)
imp <- mice(imp_vars, m = 20, seed = 2024, printFlag = FALSE)
pool_row <- function(pooled, term) {
  summary(pooled, conf.int = TRUE, exponentiate = TRUE) |> filter(term == !!term)
}

# Shared descriptive numbers ------------------------------------------------
KR$n <- n_all
KR$sites <- table(icu_all$site)
KR$mort <- npct(icu_all$died_28d == "Yes")
KR$pos  <- npct(icu$positive_balance_d3 == "Yes")
KR$cfb  <- med_iqr(icu$cum_fluid_balance_d3_ml_kg)
KR$sofa <- med_iqr(icu_all$sofa, f = function(x) sprintf("%.0f", x))
KR$lac_missing <- npct(is.na(icu_all$lactate_mmol_l))
KR$age <- sprintf("%.1f (SD %.1f)", mean(icu_all$age, na.rm = TRUE), sd(icu_all$age, na.rm = TRUE))
KR$male <- npct(icu_all$sex == "Male")

t1_bal <- make_t1(icu |> mutate(Group = factor(positive_balance_d3, c("No", "Yes"),
                                               c("Negative balance", "Positive balance"))), "Group")
t1_bal_df <- t1_df(t1_bal)
t1_bal_ft <- as_flex_table(t1_bal)
by_grp <- icu |> group_by(positive_balance_d3) |>
  summarise(sofa = med_iqr(sofa, function(x) sprintf("%.0f", x)),
            vaso = npct(vasopressor == "Yes"), mv = npct(mech_vent == "Yes"),
            lac = med_iqr(lactate_mmol_l), hf = npct(heart_failure == "Yes"), age = sprintf("%.1f", mean(age, na.rm = TRUE)))
KR$t1 <- by_grp

# ===========================================================================
# Q1  Positive fluid balance and 28-day mortality
# ===========================================================================
q <- "Q1"
icu <- icu |> mutate(Group = factor(positive_balance_d3, c("No", "Yes"), c("Negative balance", "Positive balance")))
tab <- table(icu$Group, icu$died_28d)
risk <- tab[, "Yes"] / rowSums(tab)
pt <- prop.test(tab[2:1, "Yes"], rowSums(tab)[2:1], correct = FALSE)
m_crude    <- glm(died_28d ~ positive_balance_d3, binomial, icu)
m_adj      <- glm(as.formula(paste("died_28d ~ positive_balance_d3 +", CONF)), binomial, icu)
cc_dat     <- model.frame(m_adj) |> as_tibble()
m_crude_cc <- glm(died_28d ~ positive_balance_d3, binomial, icu |> filter(complete.cases(age, sofa, lactate_mmol_l)))
o_cr <- or_row(m_crude, "positive_balance_d3Yes"); o_cc <- or_row(m_crude_cc, "positive_balance_d3Yes")
o_ad <- or_row(m_adj, "positive_balance_d3Yes")
mi_q1 <- pool(with(imp, glm(died_28d ~ positive_balance_d3 + age + sofa + lactate_mmol_l + vasopressor +
                              mech_vent + ckd, family = binomial)))
o_mi <- pool_row(mi_q1, "positive_balance_d3Yes")

km <- survfit(Surv(time_to_event_28d, died_28d == "Yes") ~ Group, data = icu)
km28 <- summary(km, times = 28)
lr <- survdiff(Surv(time_to_event_28d, died_28d == "Yes") ~ Group, data = icu)
p_lr <- 1 - pchisq(lr$chisq, 1)
cox_cr <- coxph(Surv(time_to_event_28d, died_28d == "Yes") ~ positive_balance_d3, data = icu)
cox_ad <- coxph(as.formula(paste("Surv(time_to_event_28d, died_28d == 'Yes') ~ positive_balance_d3 +", CONF)), data = icu)
h_cr <- tidy(cox_cr, exponentiate = TRUE, conf.int = TRUE)[1, ]
h_ad <- tidy(cox_ad, exponentiate = TRUE, conf.int = TRUE)[1, ]
zph <- cox.zph(cox_ad)$table["GLOBAL", "p"]

m_int   <- glm(as.formula(paste("died_28d ~ positive_balance_d3 * heart_failure +", CONF)), binomial, icu)
p_int   <- summary(m_int)$coefficients["positive_balance_d3Yes:heart_failureYes", 4]
p_int_lr <- anova(update(m_int, . ~ . - positive_balance_d3:heart_failure), m_int, test = "LRT")$`Pr(>Chi)`[2]
m_strat <- glm(as.formula(paste("died_28d ~ heart_failure / positive_balance_d3 +", CONF)), binomial, icu)
int_tab <- tidy(m_strat, exponentiate = TRUE, conf.int = TRUE) |>
  filter(grepl(":positive_balance_d3Yes", term)) |>
  mutate(subgroup = if_else(grepl("heart_failureYes", term), "Heart failure", "No heart failure"),
         n = as.vector(table(model.frame(m_strat)$heart_failure)))
hf_yes <- int_tab |> filter(subgroup == "Heart failure"); hf_no <- int_tab |> filter(subgroup == "No heart failure")
hf_mort <- icu |> group_by(heart_failure, Group) |> summarise(n = n(), deaths = sum(died_28d == "Yes"),
                                                              pct = 100 * mean(died_28d == "Yes"), .groups = "drop")

KR$q1 <- list(
  mort_pos = npct(icu$died_28d[icu$Group == "Positive balance"] == "Yes"),
  mort_neg = npct(icu$died_28d[icu$Group == "Negative balance"] == "Yes"),
  rd = est_ci(100 * (pt$estimate[1] - pt$estimate[2]), 100 * pt$conf.int[1], 100 * pt$conf.int[2], f1),
  rr = f2(risk[2] / risk[1]), p_chi = pf(pt$p.value),
  crude = est_ci(o_cr$estimate, o_cr$conf.low, o_cr$conf.high), crude_p = pf(o_cr$p.value),
  crude_cc = est_ci(o_cc$estimate, o_cc$conf.low, o_cc$conf.high), n_cc = nobs(m_adj),
  adj = est_ci(o_ad$estimate, o_ad$conf.low, o_ad$conf.high), adj_p = pf(o_ad$p.value),
  mi = est_ci(o_mi$estimate, o_mi$`2.5 %`, o_mi$`97.5 %`), mi_p = pf(o_mi$p.value),
  surv28 = sprintf("%.1f%% (negative) vs %.1f%% (positive)", 100 * km28$surv[1], 100 * km28$surv[2]),
  logrank = pf(p_lr), logrank_chisq = f1(lr$chisq),
  hr_crude = est_ci(h_cr$estimate, h_cr$conf.low, h_cr$conf.high), hr_crude_p = pf(h_cr$p.value),
  hr_adj = est_ci(h_ad$estimate, h_ad$conf.low, h_ad$conf.high), hr_adj_p = pf(h_ad$p.value),
  zph = f2(zph),
  or_hf = est_ci(hf_yes$estimate, hf_yes$conf.low, hf_yes$conf.high), n_hf = hf_yes$n,
  or_nohf = est_ci(hf_no$estimate, hf_no$conf.low, hf_no$conf.high), n_nohf = hf_no$n,
  p_int = pf(p_int), p_int_lr = pf(p_int_lr))

# Tables
out_tab <- tibble(
  Outcome = c("Died by day 28, n/N (%)", "Survival at day 28 (Kaplan-Meier), %"),
  `Negative balance` = c(npct(icu$died_28d[icu$Group == "Negative balance"] == "Yes"), f1(100 * km28$surv[1])),
  `Positive balance` = c(npct(icu$died_28d[icu$Group == "Positive balance"] == "Yes"), f1(100 * km28$surv[2])),
  `Effect (95% CI)` = c(paste0("Risk difference ", KR$q1$rd, ", RR ", KR$q1$rr, ", chi-square p ", KR$q1$p_chi), paste0("Log-rank p ", pf(p_lr))))
nice <- c(positive_balance_d3Yes = "Positive fluid balance (vs negative)", age = "Age, per year",
          sofa = "SOFA score, per point", lactate_mmol_l = "Lactate, per mmol/L",
          vasopressorYes = "Vasopressor", mech_ventYes = "Mechanical ventilation",
          ckdYes = "Chronic kidney disease")
crude_each <- map_dfr(names(nice), function(tm) {
  v <- c(positive_balance_d3Yes = "positive_balance_d3", vasopressorYes = "vasopressor",
         mech_ventYes = "mech_vent", ckdYes = "ckd")[tm]
  if (is.na(v)) v <- tm
  fit <- glm(as.formula(paste("died_28d ~", v)), binomial, icu)
  or_row(fit, tm) |> mutate(n = nobs(fit))
})
adj_all <- tidy(m_adj, exponentiate = TRUE, conf.int = TRUE) |> filter(term != "(Intercept)")
log_tab <- tibble(Variable = nice[adj_all$term],
                  `Crude OR (95% CI)` = sprintf("%s (%s to %s)", f2(crude_each$estimate), f2(crude_each$conf.low), f2(crude_each$conf.high)),
                  `Crude p` = pf(crude_each$p.value),
                  `Adjusted OR (95% CI)` = sprintf("%s (%s to %s)", f2(adj_all$estimate), f2(adj_all$conf.low), f2(adj_all$conf.high)),
                  `Adjusted p` = pf(adj_all$p.value))
cox_tab <- tibble(Model = c("Crude", "Adjusted (pre-specified confounders)"), n = c(cox_cr$n, cox_ad$n),
                  Events = c(cox_cr$nevent, cox_ad$nevent),
                  `HR (95% CI)` = c(sprintf("%s (%s to %s)", f2(h_cr$estimate), f2(h_cr$conf.low), f2(h_cr$conf.high)),
                                    sprintf("%s (%s to %s)", f2(h_ad$estimate), f2(h_ad$conf.low), f2(h_ad$conf.high))),
                  p = c(pf(h_cr$p.value), pf(h_ad$p.value)))
int_out <- int_tab |> left_join(hf_mort |> filter(Group == "Positive balance") |>
                                  transmute(subgroup = if_else(heart_failure == "Yes", "Heart failure", "No heart failure"),
                                            mort_pos = sprintf("%d/%d (%.0f%%)", deaths, n, pct)), by = "subgroup") |>
  left_join(hf_mort |> filter(Group == "Negative balance") |>
              transmute(subgroup = if_else(heart_failure == "Yes", "Heart failure", "No heart failure"),
                        mort_neg = sprintf("%d/%d (%.0f%%)", deaths, n, pct)), by = "subgroup") |>
  transmute(Subgroup = subgroup, `Deaths, negative balance` = mort_neg, `Deaths, positive balance` = mort_pos,
            `Adjusted OR (95% CI)` = sprintf("%s (%s to %s)", f2(estimate), f2(conf.low), f2(conf.high)),
            `p for interaction` = pf(p_int))
sens_tab <- tibble(Analysis = c("Crude, all patients", "Crude, complete cases", "Adjusted, complete cases (main)",
                                "Adjusted, multiple imputation (m = 20)"),
                   n = c(nobs(m_crude), nobs(m_crude_cc), nobs(m_adj), nrow(icu_all)),
                   `OR (95% CI)` = c(sprintf("%s (%s to %s)", f2(o_cr$estimate), f2(o_cr$conf.low), f2(o_cr$conf.high)),
                                     sprintf("%s (%s to %s)", f2(o_cc$estimate), f2(o_cc$conf.low), f2(o_cc$conf.high)),
                                     sprintf("%s (%s to %s)", f2(o_ad$estimate), f2(o_ad$conf.low), f2(o_ad$conf.high)),
                                     sprintf("%s (%s to %s)", f2(o_mi$estimate), f2(o_mi$`2.5 %`), f2(o_mi$`97.5 %`))),
                   p = c(pf(o_cr$p.value), pf(o_cc$p.value), pf(o_ad$p.value), pf(o_mi$p.value)))

save_table(t1_bal_df, q, "table1_by_balance", t1_bal_ft)
for (nm in c("out_tab", "log_tab", "cox_tab", "int_out", "sens_tab")) {
  save_table(get(nm), q, c(out_tab = "table2_outcome", log_tab = "table3_logistic", cox_tab = "table4_cox",
                           int_out = "table5_interaction_hf", sens_tab = "table6_sensitivity")[[nm]])
}

# Figures
g_km <- ggsurvplot(km, data = icu, risk.table = TRUE, pval = FALSE, conf.int = TRUE,
                   palette = unname(grp_cols), legend.labs = names(grp_cols), legend.title = "",
                   xlab = "Days since ICU admission", ylab = "Survival probability",
                   break.time.by = 7, xlim = c(0, 28), ylim = c(0.5, 1), risk.table.height = 0.25,
                   ggtheme = theme_minimal(base_size = 13))
g_km$plot <- g_km$plot + annotate("text", x = 1, y = 0.55, hjust = 0, size = 4.5,
                                  label = paste0("Log-rank p ", pf(p_lr)))
f_km <- file.path("results_packs", q, "figures", "fig1_km_balance.png")
png(f_km, width = 7, height = 5.5, units = "in", res = 300); print(g_km); invisible(dev.off())

forest_df <- adj_all |> mutate(label = factor(nice[term], levels = rev(nice)), main = term == "positive_balance_d3Yes")
p_forest <- ggplot(forest_df, aes(estimate, label)) +
  geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = conf.low, xmax = conf.high), width = .2, orientation = "y", colour = pal[["blue"]]) +
  geom_point(aes(colour = main), size = 3, show.legend = FALSE) +
  scale_colour_manual(values = c(`FALSE` = pal[["blue"]], `TRUE` = pal[["teal"]])) +
  geom_text(aes(x = 7, label = sprintf("%s (%s-%s)", f2(estimate), f2(conf.low), f2(conf.high))), hjust = 1, size = 3.6) +
  scale_x_log10(limits = c(0.5, 7), breaks = c(0.5, 1, 2, 4)) +
  labs(x = "Adjusted odds ratio for 28-day death (log scale)", y = NULL)
f_forest <- save_fig(p_forest, q, "fig2_forest_adjusted")

cva <- tibble(model = c("Crude, all patients", "Crude, complete cases", "Adjusted, complete cases", "Adjusted, multiple imputation"),
              n = c(nobs(m_crude), nobs(m_crude_cc), nobs(m_adj), nrow(icu_all)),
              OR = c(o_cr$estimate, o_cc$estimate, o_ad$estimate, o_mi$estimate),
              lower = c(o_cr$conf.low, o_cc$conf.low, o_ad$conf.low, o_mi$`2.5 %`),
              upper = c(o_cr$conf.high, o_cc$conf.high, o_ad$conf.high, o_mi$`97.5 %`))
p_cva <- cva |> mutate(model = factor(model, rev(model))) |>
  ggplot(aes(OR, model)) + geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = lower, xmax = upper), width = .15, orientation = "y", colour = pal[["blue"]]) +
  geom_point(size = 3.5, colour = pal[["teal"]]) +
  geom_text(aes(label = sprintf("%s (%s-%s)", f2(OR), f2(lower), f2(upper))), vjust = -1, size = 3.6) +
  scale_x_log10(breaks = c(0.75, 1, 1.5, 2, 3, 4), limits = c(0.75, 4.2)) +
  labs(x = "OR for 28-day death, positive vs negative balance (log scale)", y = NULL)
f_cva <- save_fig(p_cva, q, "fig3_crude_vs_adjusted", 7, 3.8)

p_int_fig <- int_tab |> mutate(subgroup = factor(sprintf("%s (n = %d)", subgroup, n))) |>
  ggplot(aes(estimate, subgroup)) + geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = conf.low, xmax = conf.high), width = .15, orientation = "y", colour = pal[["blue"]]) +
  geom_point(size = 3.5, colour = pal[["teal"]]) +
  geom_text(aes(label = sprintf("%s (%s-%s)", f2(estimate), f2(conf.low), f2(conf.high))), vjust = -1, size = 3.6) +
  scale_x_log10(breaks = c(0.5, 1, 2, 4, 8, 16), limits = c(0.5, 16)) +
  labs(x = "Adjusted OR for 28-day death, positive vs negative (log scale)", y = NULL,
       caption = paste0("p for interaction = ", pf(p_int)))
f_int <- save_fig(p_int_fig, q, "fig4_interaction_hf", 7, 3.2)

pk <- new_pack() |>
  std_header(q, "In adults with sepsis in the ICU, is a positive cumulative fluid balance by day 3 associated with higher 28-day mortality?",
             "Design: multicentre prospective cohort study (observational).",
             "death from any cause within 28 days of ICU admission (died_28d); time to death for survival analysis (time_to_event_28d, censored at day 28).",
             "positive cumulative fluid balance at day 3 (fluid in minus fluid out over ICU days 1-3 > 0 ml/kg) vs negative or zero balance.",
             paste0(n_exp, " of ", n_all, " patients (2 without a day-3 balance). Adjusted models: ", nobs(m_adj), " complete cases.")) |>
  P(flow_text) |>
  H("3. Table 1: who was studied") |>
  TB(t1_bal_df, "Table 1. Baseline characteristics by fluid-balance group", "table1_by_balance", t1_bal_ft, t1_note) |>
  P(paste0("Read Table 1 first: the positive-balance group was **sicker** at baseline: median SOFA ",
           by_grp$sofa[2], " vs ", by_grp$sofa[1], ", vasopressor ", by_grp$vaso[2], " vs ", by_grp$vaso[1],
           ". This is confounding by indication: sicker patients receive more fluid AND die more.")) |>
  H("4. Main results") |>
  TB(out_tab, "Table 2. 28-day mortality by fluid-balance group (unadjusted)", "table2_outcome") |>
  TB(log_tab, paste0("Table 3. Logistic regression for 28-day death: crude and adjusted odds ratios (adjusted model n = ", nobs(m_adj), ")"), "table3_logistic") |>
  B(c(paste0("Crude OR (all ", nobs(m_crude), " patients): **", KR$q1$crude, "**, p ", KR$q1$crude_p, "."),
      paste0("Crude OR in the same ", nobs(m_adj), " complete cases: ", KR$q1$crude_cc, "."),
      paste0("Adjusted OR (age, SOFA, lactate, vasopressor, ventilation, CKD): **", KR$q1$adj, "**, p ", KR$q1$adj_p, "."),
      paste0("Kaplan-Meier survival at day 28: ", KR$q1$surv28, "; log-rank p ", KR$q1$logrank, "."),
      paste0("Cox hazard ratio: crude ", KR$q1$hr_crude, "; adjusted **", KR$q1$hr_adj, "**, p ", KR$q1$hr_adj_p,
             " (proportional-hazards test, global p = ", KR$q1$zph, ")."))) |>
  TB(cox_tab, "Table 4. Cox regression for time to death within 28 days", "table4_cox") |>
  FG(f_km, "Figure 1. Kaplan-Meier survival to day 28 by fluid-balance group, with numbers at risk", 7, 5.5) |>
  FG(f_forest, "Figure 2. Adjusted odds ratios for 28-day death (forest plot)", 7, 4.5) |>
  FG(f_cva, "Figure 3. The odds ratio for positive balance before and after adjustment", 7, 3.8) |>
  H("5. Other analyses") |>
  TB(int_out, "Table 5. Pre-specified effect modification by heart failure", "table5_interaction_hf") |>
  FG(f_int, "Figure 4. Odds ratio for positive balance in patients with and without heart failure", 7, 3.2) |>
  TB(sens_tab, "Table 6. Sensitivity analyses for the primary association", "table6_sensitivity") |>
  H("6. What this means (plain language)") |>
  B(c(paste0("Patients with a positive fluid balance died more often (", sprintf("%.0f%%", 100 * risk[2]), " vs ",
             sprintf("%.0f%%", 100 * risk[1]), "). But they were also sicker."),
      paste0("After taking severity into account, the association became much smaller (OR fell from ", f2(o_cr$estimate), " to ", f2(o_ad$estimate), "). Much of the crude difference was confounding by indication."),
      "A modest association remained: the 95% CI only just excludes 1, and the Cox model gives a similar HR whose CI just touches 1. The evidence is weak-to-moderate, not strong.",
      paste0("The association looked stronger in patients with heart failure (p for interaction ", pf(p_int), "). This was pre-specified but is based on only ", hf_yes$n, " patients with heart failure in the adjusted model (complete cases), so treat it as a hypothesis."))) |>
  H("7. What this does NOT mean") |>
  B(c("It does NOT show that fluid CAUSES death. This is an observational study: write 'associated with', not 'caused' or 'increased'.",
      "It does NOT tell clinicians to restrict fluid. Only a randomised trial (like Paper 1) can test a fluid strategy.",
      paste0("A p-value of ", pf(o_ad$p.value), " is not 'proof'; a CI from ", f2(o_ad$conf.low), " to ", f2(o_ad$conf.high), " is compatible with a tiny or a large effect."))) |>
  H("8. Limitations to discuss (hints)") |>
  B(c("Residual confounding: SOFA and lactate measure severity imperfectly; unmeasured severity may explain the remaining association.",
      "Reverse causation: patients who do badly (shock, oliguria) accumulate fluid because they are dying, not the other way round.",
      "Fluid balance is measured over days 1-3; patients who died before day 3 had less time to accumulate fluid (immortal-time issue).",
      paste0("Missing lactate (15%): the complete-case model lost ", n_exp - n_cc, " patients; multiple imputation gave a similar answer (Table 6)."),
      "Insensible losses are not recorded; the dichotomy positive/negative throws away information (see Q2 for the continuous version).")) |>
  strobe_block(c("Item 4-5: design and setting (section 2)", "Item 6: participants and eligibility",
                 "Item 7: variables (exposure, outcome, confounders and the effect modifier, heart failure)",
                 "Item 12a-e: statistical methods incl. confounding, interaction, missing data, sensitivity analyses",
                 "Item 13: participant numbers (flow sentence)", "Item 14: descriptive data (Table 1, missing data)",
                 "Item 15: outcome data (Table 2)", "Item 16: unadjusted and adjusted estimates with 95% CI (Tables 3-4)",
                 "Item 17: other analyses (subgroup/interaction and sensitivity, Tables 5-6)"))
packs <- list(Q1 = pk)

# ===========================================================================
# Q2  Cumulative fluid balance and acute kidney injury
# ===========================================================================
q <- "Q2"
icu <- icu |> mutate(fb10 = cum_fluid_balance_d3_ml_kg / 10,
                     fb_cat = cut(cum_fluid_balance_d3_ml_kg, c(-Inf, 0, 20, 40, Inf),
                                  labels = c("<= 0", ">0 to 20", ">20 to 40", "> 40")))
a_crude <- glm(aki_any ~ fb10, binomial, icu)
a_adj   <- glm(as.formula(paste("aki_any ~ fb10 +", CONF)), binomial, icu)
a_bin   <- glm(as.formula(paste("aki_any ~ positive_balance_d3 +", CONF)), binomial, icu)
a_bin_c <- glm(aki_any ~ positive_balance_d3, binomial, icu)
a_23    <- glm(as.formula(paste("I(aki_stage >= 2) ~ fb10 +", CONF)), binomial, icu)
oa_c <- or_row(a_crude, "fb10"); oa_a <- or_row(a_adj, "fb10"); ob <- or_row(a_bin, "positive_balance_d3Yes")
obc <- or_row(a_bin_c, "positive_balance_d3Yes"); o23 <- or_row(a_23, "fb10")
aki_cat <- icu |> group_by(fb_cat) |> summarise(n = n(), aki = sum(aki_any == "Yes"), pct = 100 * mean(aki_any == "Yes"),
                                                stage23 = 100 * mean(aki_stage >= 2), rrt = 100 * mean(rrt == "Yes"))
KR$q2 <- list(aki_pos = npct(icu$aki_any[icu$Group == "Positive balance"] == "Yes"),
              aki_neg = npct(icu$aki_any[icu$Group == "Negative balance"] == "Yes"),
              aki_all = npct(icu_all$aki_any == "Yes"), rrt_all = npct(icu_all$rrt == "Yes"),
              crude10 = est_ci(oa_c$estimate, oa_c$conf.low, oa_c$conf.high),
              adj10 = est_ci(oa_a$estimate, oa_a$conf.low, oa_a$conf.high), adj10_p = pf(oa_a$p.value),
              bin_crude = est_ci(obc$estimate, obc$conf.low, obc$conf.high),
              bin_adj = est_ci(ob$estimate, ob$conf.low, ob$conf.high),
              st23 = est_ci(o23$estimate, o23$conf.low, o23$conf.high), n_adj = nobs(a_adj),
              gradient = paste(sprintf("%s: %.0f%%", aki_cat$fb_cat, aki_cat$pct), collapse = "; "))
stage_tab <- icu |> count(Group, aki_stage) |> group_by(Group) |>
  mutate(cell = sprintf("%d (%.0f%%)", n, 100 * n / sum(n))) |> select(-n) |>
  pivot_wider(names_from = Group, values_from = cell) |>
  mutate(aki_stage = paste("KDIGO stage", aki_stage)) |> rename(`AKI stage` = aki_stage)
aki_cat_tab <- aki_cat |> transmute(`Cumulative balance day 3, ml/kg` = as.character(fb_cat), n,
                                    `Any AKI, n (%)` = sprintf("%d (%.0f%%)", aki, pct),
                                    `AKI stage 2-3, %` = f1(stage23), `RRT, %` = f1(rrt))
aki_models <- tibble(Model = c("Balance per 10 ml/kg, crude", "Balance per 10 ml/kg, adjusted",
                               "Positive vs negative balance, crude", "Positive vs negative balance, adjusted",
                               "Balance per 10 ml/kg, adjusted (outcome AKI stage 2-3)"),
                     n = c(nobs(a_crude), nobs(a_adj), nobs(a_bin_c), nobs(a_bin), nobs(a_23)),
                     `OR (95% CI)` = c(sprintf("%s (%s to %s)", f2(oa_c$estimate), f2(oa_c$conf.low), f2(oa_c$conf.high)),
                                       sprintf("%s (%s to %s)", f2(oa_a$estimate), f2(oa_a$conf.low), f2(oa_a$conf.high)),
                                       sprintf("%s (%s to %s)", f2(obc$estimate), f2(obc$conf.low), f2(obc$conf.high)),
                                       sprintf("%s (%s to %s)", f2(ob$estimate), f2(ob$conf.low), f2(ob$conf.high)),
                                       sprintf("%s (%s to %s)", f2(o23$estimate), f2(o23$conf.low), f2(o23$conf.high))),
                     p = pf(c(oa_c$p.value, oa_a$p.value, obc$p.value, ob$p.value, o23$p.value)))
save_table(t1_bal_df, q, "table1_by_balance", t1_bal_ft)
save_table(stage_tab, q, "table2_aki_stage_by_group"); save_table(aki_cat_tab, q, "table3_aki_by_balance_category")
save_table(aki_models, q, "table4_aki_models")
p_aki <- icu |> count(fb_cat, aki_stage) |> group_by(fb_cat) |> mutate(pct = 100 * n / sum(n)) |>
  mutate(stage = factor(aki_stage, 3:0, c("Stage 3", "Stage 2", "Stage 1", "No AKI"))) |>
  ggplot(aes(fb_cat, pct, fill = stage)) + geom_col(width = .7) +
  scale_fill_manual(values = c("Stage 3" = pal[["blue"]], "Stage 2" = pal[["sky"]], "Stage 1" = pal[["lteal"]], "No AKI" = "#D5DDE1"), name = NULL) +
  labs(x = "Cumulative fluid balance at day 3 (ml/kg)", y = "% of patients")
f_aki <- save_fig(p_aki, q, "fig1_aki_stage_by_balance")
p_scatter <- icu |> mutate(aki = if_else(aki_any == "Yes", 1, 0)) |>
  ggplot(aes(cum_fluid_balance_d3_ml_kg, aki)) +
  geom_jitter(height = .04, alpha = .25, colour = pal[["grey"]]) +
  geom_smooth(method = "glm", method.args = list(family = binomial), colour = pal[["teal"]], fill = pal[["lteal"]], formula = y ~ x) +
  scale_y_continuous(breaks = c(0, .25, .5, .75, 1), labels = c("0% (no AKI)", "25%", "50%", "75%", "100% (AKI)")) +
  labs(x = "Cumulative fluid balance at day 3 (ml/kg)", y = "Probability of AKI (crude)")
f_sc <- save_fig(p_scatter, q, "fig2_aki_probability_curve")
pk <- new_pack() |>
  std_header(q, "In adults with sepsis in the ICU, is a higher cumulative fluid balance by day 3 associated with acute kidney injury?",
             "Design: multicentre prospective cohort study (observational).",
             "acute kidney injury (KDIGO stage >= 1, maximum stage during ICU days 1-7; aki_any). Secondary: AKI stage 2-3; renal replacement therapy (descriptive).",
             "cumulative fluid balance at day 3 in ml/kg, analysed per 10 ml/kg (continuous); secondary: positive vs negative balance.",
             paste0(n_exp, " patients with a day-3 balance; adjusted models ", nobs(a_adj), " complete cases.")) |>
  P(flow_text) |>
  H("3. Table 1: who was studied") |>
  TB(t1_bal_df, "Table 1. Baseline characteristics by fluid-balance group", "table1_by_balance", t1_bal_ft, t1_note) |>
  H("4. Main results") |>
  B(c(paste0("AKI (any stage) occurred in ", KR$q2$aki_all, " of all patients; RRT in ", KR$q2$rrt_all, "."),
      paste0("AKI: positive balance ", KR$q2$aki_pos, " vs negative balance ", KR$q2$aki_neg, "."),
      paste0("AKI rose with each balance category: ", KR$q2$gradient, "."),
      paste0("Crude OR per 10 ml/kg more balance: ", KR$q2$crude10, "."),
      paste0("Adjusted OR per 10 ml/kg: **", KR$q2$adj10, "**, p ", KR$q2$adj10_p, "."),
      paste0("Positive vs negative balance: crude OR ", KR$q2$bin_crude, "; adjusted OR ", KR$q2$bin_adj, "."))) |>
  TB(stage_tab, "Table 2. Maximum KDIGO AKI stage by fluid-balance group", "table2_aki_stage_by_group") |>
  TB(aki_cat_tab, "Table 3. AKI by category of cumulative fluid balance at day 3", "table3_aki_by_balance_category") |>
  TB(aki_models, "Table 4. Logistic regression for AKI (adjusted for age, SOFA, lactate, vasopressor, ventilation, CKD)", "table4_aki_models") |>
  FG(f_aki, "Figure 1. Maximum AKI stage by category of cumulative fluid balance", 7, 4.5) |>
  FG(f_sc, "Figure 2. Crude probability of AKI across the range of fluid balance (logistic curve, 95% band)", 7, 4.5) |>
  H("5. What this means (plain language)") |>
  B(c("AKI was more common the more positive the fluid balance: a clear 'dose-response' pattern.",
      paste0("After adjustment, each extra 10 ml/kg (about 650 ml for a 65 kg adult) was associated with about ", round(100 * (oa_a$estimate - 1)), "% higher odds of AKI."),
      "Using the continuous balance keeps more information than positive/negative and shows the gradient.")) |>
  H("6. What this does NOT mean") |>
  B(c("It does NOT show that fluid damages the kidney. The arrow may point the other way: AKI reduces urine output, and low output makes the balance positive (reverse causation).",
      "We do not know whether AKI started before or after the fluid accumulated. The data record the maximum stage over days 1-7.",
      paste0("An OR of ", f2(oa_a$estimate), " per 10 ml/kg is not a risk: with AKI this common (about 49%), odds ratios overstate risk ratios."))) |>
  H("7. Limitations to discuss (hints)") |>
  B(c("Timing: exposure (days 1-3) and outcome (days 1-7) overlap.", "Residual confounding by severity and nephrotoxic drugs (not recorded).",
      "KDIGO staging may be based on creatinine, which fluid dilutes, so AKI may be under-diagnosed in patients with large positive balances.",
      "Complete-case analysis (lactate missing in 15%).")) |>
  strobe_block(c("Item 6-7: participants and variable definitions (KDIGO)", "Item 12: methods incl. continuous exposure scaling (per 10 ml/kg)",
                 "Item 14: descriptive data (Table 1)", "Item 15: outcome data (Tables 2-3)",
                 "Item 16: crude and adjusted ORs with 95% CI; category boundaries reported (Table 3-4)",
                 "Item 19: limitations (reverse causation and timing)", "Item 17: secondary outcome AKI stage 2-3"))
packs$Q2 <- pk

# ===========================================================================
# Q3  Cumulative fluid balance and ventilator-free days
# ===========================================================================
q <- "Q3"
v_lm_c <- lm(vent_free_days_28 ~ fb10, icu)
v_lm   <- lm(as.formula(paste("vent_free_days_28 ~ fb10 +", CONF)), icu)
v_bin  <- lm(as.formula(paste("vent_free_days_28 ~ positive_balance_d3 +", CONF)), icu)
mwv <- wilcox.test(vent_free_days_28 ~ positive_balance_d3, icu, conf.int = TRUE, exact = FALSE)
vt  <- tidy(v_lm, conf.int = TRUE) |> filter(term == "fb10"); vtc <- tidy(v_lm_c, conf.int = TRUE) |> filter(term == "fb10")
vb  <- tidy(v_bin, conf.int = TRUE) |> filter(term == "positive_balance_d3Yes")
vent <- icu |> filter(mech_vent == "Yes")
vfd_sum <- icu |> group_by(Group) |>
  summarise(n = n(), `VFD, median (IQR)` = med_iqr(vent_free_days_28, function(x) sprintf("%.0f", x)),
            `VFD, mean (SD)` = sprintf("%.1f (%.1f)", mean(vent_free_days_28), sd(vent_free_days_28)),
            `VFD = 0 (died or ventilated 28 d), n (%)` = sprintf("%d (%.0f%%)", sum(vent_free_days_28 == 0), 100 * mean(vent_free_days_28 == 0)),
            `VFD = 28 (never ventilated, alive), n (%)` = sprintf("%d (%.0f%%)", sum(vent_free_days_28 == 28), 100 * mean(vent_free_days_28 == 28)),
            `Ventilated patients: VFD median (IQR)` = med_iqr(vent_free_days_28[mech_vent == "Yes"], function(x) sprintf("%.0f", x)))
vfd_sum_t <- vfd_sum |> mutate(n = as.character(n)) |> pivot_longer(-Group, names_to = "Summary") |>
  pivot_wider(names_from = Group, values_from = value)
mwv_vent <- wilcox.test(vent_free_days_28 ~ positive_balance_d3, vent, exact = FALSE)
KR$q3 <- list(vfd_pos = med_iqr(icu$vent_free_days_28[icu$Group == "Positive balance"], function(x) sprintf("%.0f", x)),
              vfd_neg = med_iqr(icu$vent_free_days_28[icu$Group == "Negative balance"], function(x) sprintf("%.0f", x)),
              mw_p = pf(mwv$p.value), hl = est_ci(mwv$estimate, mwv$conf.int[1], mwv$conf.int[2], f1),
              lm_crude = est_ci(vtc$estimate, vtc$conf.low, vtc$conf.high), lm_adj = est_ci(vt$estimate, vt$conf.low, vt$conf.high),
              lm_adj_p = pf(vt$p.value), bin_adj = est_ci(vb$estimate, vb$conf.low, vb$conf.high), n_adj = nobs(v_lm),
              vent_p = pf(mwv_vent$p.value), n_vent = nrow(vent))
vfd_models <- tibble(Model = c("Balance per 10 ml/kg, crude (linear)", "Balance per 10 ml/kg, adjusted (linear)",
                               "Positive vs negative balance, adjusted (linear)", "Positive vs negative balance, Mann-Whitney (Hodges-Lehmann)"),
                     n = c(nobs(v_lm_c), nobs(v_lm), nobs(v_bin), n_exp),
                     `Difference in VFD, days (95% CI)` = c(sprintf("%s (%s to %s)", f2(vtc$estimate), f2(vtc$conf.low), f2(vtc$conf.high)),
                                                            sprintf("%s (%s to %s)", f2(vt$estimate), f2(vt$conf.low), f2(vt$conf.high)),
                                                            sprintf("%s (%s to %s)", f2(vb$estimate), f2(vb$conf.low), f2(vb$conf.high)),
                                                            sprintf("%s (%s to %s)", f1(-mwv$estimate), f1(-mwv$conf.int[2]), f1(-mwv$conf.int[1]))),
                     p = pf(c(vtc$p.value, vt$p.value, vb$p.value, mwv$p.value)))
save_table(t1_bal_df, q, "table1_by_balance", t1_bal_ft)
save_table(vfd_sum_t, q, "table2_vfd_by_group"); save_table(vfd_models, q, "table3_vfd_models")
p_vfd <- ggplot(icu, aes(vent_free_days_28, fill = Group)) +
  geom_histogram(binwidth = 1, boundary = -.5, colour = "white") + facet_wrap(~ Group, ncol = 1) +
  scale_fill_manual(values = grp_cols, guide = "none") +
  labs(x = "Ventilator-free days to day 28 (0 = died or ventilated throughout)", y = "Number of patients")
f_vfd <- save_fig(p_vfd, q, "fig1_vfd_histogram", 7, 5)
p_vfd2 <- icu |> group_by(fb_cat) |> summarise(med = median(vent_free_days_28), mean = mean(vent_free_days_28),
                                              died = 100 * mean(died_28d == "Yes")) |>
  pivot_longer(c(mean), names_to = "stat") |>
  ggplot(aes(fb_cat, value)) + geom_col(fill = pal[["teal"]], width = .6) +
  geom_text(aes(label = f1(value)), vjust = -.4, size = 4) +
  labs(x = "Cumulative fluid balance at day 3 (ml/kg)", y = "Mean ventilator-free days") +
  scale_y_continuous(limits = c(0, 28))
f_vfd2 <- save_fig(p_vfd2, q, "fig2_vfd_by_balance_category", 7, 4.2)
pk <- new_pack() |>
  std_header(q, "In adults with sepsis in the ICU, is a higher cumulative fluid balance by day 3 associated with fewer ventilator-free days to day 28?",
             "Design: multicentre prospective cohort study (observational).",
             "ventilator-free days (VFD) to day 28: days alive and free of mechanical ventilation; patients who died = 0; never ventilated and alive = 28 (vent_free_days_28).",
             "cumulative fluid balance at day 3 per 10 ml/kg (continuous); secondary: positive vs negative.",
             paste0(n_exp, " patients; adjusted models ", nobs(v_lm), " complete cases; ", nrow(vent), " were ventilated on admission.")) |>
  P(flow_text) |>
  H("3. Table 1: who was studied") |>
  TB(t1_bal_df, "Table 1. Baseline characteristics by fluid-balance group", "table1_by_balance", t1_bal_ft, t1_note) |>
  H("4. Main results") |>
  B(c(paste0("VFD median (IQR): positive balance ", KR$q3$vfd_pos, " vs negative ", KR$q3$vfd_neg, " days; Mann-Whitney p ", KR$q3$mw_p, "."),
      paste0("Linear regression, crude: ", KR$q3$lm_crude, " days per 10 ml/kg."),
      paste0("Linear regression, adjusted: **", KR$q3$lm_adj, " days per 10 ml/kg**, p ", KR$q3$lm_adj_p, "."),
      paste0("Positive vs negative balance, adjusted difference: ", KR$q3$bin_adj, " days."))) |>
  TB(vfd_sum_t, "Table 2. Ventilator-free days by fluid-balance group", "table2_vfd_by_group") |>
  TB(vfd_models, "Table 3. Association between fluid balance and ventilator-free days", "table3_vfd_models",
     note = "Negative = fewer ventilator-free days. Adjusted for age, SOFA, lactate, vasopressor, ventilation, CKD.") |>
  FG(f_vfd, "Figure 1. Distribution of ventilator-free days by group (note the two spikes at 0 and 28)", 7, 5) |>
  FG(f_vfd2, "Figure 2. Mean ventilator-free days by category of cumulative fluid balance", 7, 4.2) |>
  H("5. What this means (plain language)") |>
  B(c("Patients with more fluid on board had fewer days alive and off the ventilator.",
      paste0("After adjustment, each extra 10 ml/kg was associated with about ", f1(-vt$estimate), " fewer ventilator-free days (95% CI ", f1(-vt$conf.high), " to ", f1(-vt$conf.low), ")."),
      "VFD is not a normal-shaped number: many patients are at 0 (died) or 28 (never ventilated). The median and Mann-Whitney test describe it honestly; the linear model gives an easy-to-read average difference but its assumptions are strained.")) |>
  H("6. What this does NOT mean") |>
  B(c("It does NOT mean fluid keeps patients on the ventilator: VFD mixes death and ventilation time, and sicker patients get more fluid.",
      "A difference in mean VFD is not the same as 'each patient was ventilated one day longer'.")) |>
  H("7. Limitations to discuss (hints)") |>
  B(c("Composite outcome: a VFD of 0 can mean early death or 28 days on the ventilator. Say which drives the result.",
      "Skewed, bounded outcome: linear regression is approximate; consider the Mann-Whitney result or a proportional-odds model as sensitivity.",
      "Residual confounding by severity; respiratory infections both raise ventilation and may change fluid practice.",
      "Complete-case analysis (lactate missing).")) |>
  strobe_block(c("Item 7: define the composite outcome VFD precisely", "Item 12: methods (why non-parametric and linear models)",
                 "Item 14: descriptive data (Table 1)", "Item 15-16: outcome summaries and adjusted differences with 95% CI",
                 "Item 19: limitations of a composite, skewed outcome"))
packs$Q3 <- pk

# ===========================================================================
# Q4  Admission lactate and 28-day mortality; missing lactate
# ===========================================================================
q <- "Q4"
icu_all <- icu_all |>
  mutate(Status = factor(died_28d, c("No", "Yes"), c("Survived to day 28", "Died by day 28")),
         lac_cat = cut(lactate_mmol_l, c(-Inf, 2, 4, Inf), labels = c("< 2", "2 to 4", "> 4"), right = FALSE),
         lac_cat = fct_na_value_to_level(lac_cat, "Missing"),
         lactate_status = factor(if_else(is.na(lactate_mmol_l), "Lactate missing", "Lactate measured"),
                                 c("Lactate measured", "Lactate missing")))
t1_q4 <- make_t1(icu_all, "Status", c(t1_vars, "cum_fluid_balance_d3_ml_kg"))
t1_q4_df <- t1_df(t1_q4); t1_q4_ft <- as_flex_table(t1_q4)
cc_q4  <- glm(died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure, binomial, icu_all)
cc_q4s <- glm(died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure + sofa, binomial, icu_all)
cc_q4c <- glm(died_28d ~ lactate_mmol_l, binomial, icu_all)
mi_q4  <- pool(with(imp, glm(died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure, family = binomial)))
mi_q4s <- pool(with(imp, glm(died_28d ~ lactate_mmol_l + age + sex + diabetes + ckd + heart_failure + sofa, family = binomial)))
mi_q4c <- pool(with(imp, glm(died_28d ~ lactate_mmol_l, family = binomial)))
r4 <- list(cc_c = or_row(cc_q4c, "lactate_mmol_l"), cc = or_row(cc_q4, "lactate_mmol_l"), cc_s = or_row(cc_q4s, "lactate_mmol_l"),
           mi_c = pool_row(mi_q4c, "lactate_mmol_l"), mi = pool_row(mi_q4, "lactate_mmol_l"), mi_s = pool_row(mi_q4s, "lactate_mmol_l"))
fmt_cc <- function(r) sprintf("%s (%s to %s)", f2(r$estimate), f2(r$conf.low), f2(r$conf.high))
fmt_mi <- function(r) sprintf("%s (%s to %s)", f2(r$estimate), f2(r$`2.5 %`), f2(r$`97.5 %`))
# MI estimate of the median lactate (pooled across the 20 data sets)
mi_median <- median(sapply(1:20, function(i) median(complete(imp, i)$lactate_mmol_l)))
mort_lac <- icu_all |> group_by(lac_cat) |> summarise(n = n(), deaths = sum(died_28d == "Yes"), pct = 100 * mean(died_28d == "Yes"))
miss_cmp <- icu_all |> group_by(lactate_status) |>
  summarise(n = n(), `SOFA, median (IQR)` = med_iqr(sofa, function(x) sprintf("%.0f", x)),
            `MAP, median (IQR)` = med_iqr(map_mmhg, function(x) sprintf("%.0f", x)),
            `Vasopressor, n (%)` = sprintf("%d (%.0f%%)", sum(vasopressor == "Yes"), 100 * mean(vasopressor == "Yes")),
            `ICU D, n (%)` = sprintf("%d (%.0f%%)", sum(site == "ICU D"), 100 * mean(site == "ICU D")),
            `Died by day 28, n (%)` = sprintf("%d (%.0f%%)", sum(died_28d == "Yes"), 100 * mean(died_28d == "Yes"))) |>
  mutate(n = as.character(n)) |> pivot_longer(-lactate_status, names_to = "Characteristic") |>
  pivot_wider(names_from = lactate_status, values_from = value)
miss_model <- glm(is.na(lactate_mmol_l) ~ sofa + vasopressor + map_mmhg + site, binomial, icu_all)
ccmi_tab <- tibble(Model = rep(c("Unadjusted", "Adjusted: age, sex, diabetes, CKD, heart failure (main)", "Main + SOFA score"), each = 2),
                   Method = rep(c("Complete case", "Multiple imputation (m = 20)"), 3),
                   n = rep(c(nobs(cc_q4), nrow(icu_all)), 3),
                   `OR per 1 mmol/L (95% CI)` = c(fmt_cc(r4$cc_c), fmt_mi(r4$mi_c), fmt_cc(r4$cc), fmt_mi(r4$mi), fmt_cc(r4$cc_s), fmt_mi(r4$mi_s)),
                   p = pf(c(r4$cc_c$p.value, r4$mi_c$p.value, r4$cc$p.value, r4$mi$p.value, r4$cc_s$p.value, r4$mi_s$p.value)))
mort_lac_tab <- mort_lac |> transmute(`Admission lactate, mmol/L` = as.character(lac_cat), n,
                                      `Died by day 28, n (%)` = sprintf("%d (%.0f%%)", deaths, pct))
KR$q4 <- list(lac_died = med_iqr(icu_all$lactate_mmol_l[icu_all$died_28d == "Yes"]),
              lac_surv = med_iqr(icu_all$lactate_mmol_l[icu_all$died_28d == "No"]),
              mort_measured = npct(icu_all$died_28d[!is.na(icu_all$lactate_mmol_l)] == "Yes"),
              mort_missing = npct(icu_all$died_28d[is.na(icu_all$lactate_mmol_l)] == "Yes"),
              sofa_measured = med_iqr(icu_all$sofa[!is.na(icu_all$lactate_mmol_l)], function(x) sprintf("%.0f", x)),
              sofa_missing = med_iqr(icu_all$sofa[is.na(icu_all$lactate_mmol_l)], function(x) sprintf("%.0f", x)),
              median_cc = f1(median(icu_all$lactate_mmol_l, na.rm = TRUE)), median_mi = f1(mi_median),
              cc_c = fmt_cc(r4$cc_c), mi_c = fmt_mi(r4$mi_c), cc = fmt_cc(r4$cc), mi = fmt_mi(r4$mi),
              cc_s = fmt_cc(r4$cc_s), mi_s = fmt_mi(r4$mi_s), n_cc = nobs(cc_q4),
              mort_cat = paste(sprintf("%s: %.0f%%", mort_lac$lac_cat, mort_lac$pct), collapse = "; "))
save_table(t1_q4_df, q, "table1_by_survival", t1_q4_ft)
save_table(miss_cmp, q, "table2_missing_lactate_comparison"); save_table(mort_lac_tab, q, "table3_mortality_by_lactate")
save_table(ccmi_tab, q, "table4_cc_vs_mi")
miss_sofa <- icu_all |> mutate(sofa_band = cut(sofa, c(-Inf, 4, 7, 10, Inf), labels = c("0-4", "5-7", "8-10", "11+"))) |>
  group_by(sofa_band) |> summarise(n = n(), pct_missing = 100 * mean(is.na(lactate_mmol_l)))
p_ms <- ggplot(miss_sofa, aes(sofa_band, pct_missing)) + geom_col(fill = pal[["teal"]], width = .6) +
  geom_text(aes(label = sprintf("%.0f%%\n(n = %d)", pct_missing, n)), vjust = -.2, size = 4) +
  scale_y_continuous(limits = c(0, 45)) + labs(x = "SOFA score on admission", y = "Lactate missing (%)")
f_ms <- save_fig(p_ms, q, "fig1_missing_lactate_by_sofa", 7, 4.2)
p_ml <- ggplot(mort_lac, aes(lac_cat, pct, fill = lac_cat == "Missing")) + geom_col(width = .6) +
  geom_text(aes(label = sprintf("%.0f%%\n(%d/%d)", pct, deaths, n)), vjust = -.2, size = 4) +
  scale_fill_manual(values = c(`FALSE` = pal[["blue"]], `TRUE` = pal[["grey"]]), guide = "none") +
  scale_y_continuous(limits = c(0, 60)) + labs(x = "Admission lactate (mmol/L)", y = "Died by day 28 (%)")
f_ml <- save_fig(p_ml, q, "fig2_mortality_by_lactate", 7, 4.2)
ccmi_plot <- tibble(model = rep(c("Unadjusted", "Adjusted (main)", "Adjusted + SOFA"), each = 2),
                    method = rep(c("Complete case", "Multiple imputation"), 3),
                    OR = c(r4$cc_c$estimate, r4$mi_c$estimate, r4$cc$estimate, r4$mi$estimate, r4$cc_s$estimate, r4$mi_s$estimate),
                    lower = c(r4$cc_c$conf.low, r4$mi_c$`2.5 %`, r4$cc$conf.low, r4$mi$`2.5 %`, r4$cc_s$conf.low, r4$mi_s$`2.5 %`),
                    upper = c(r4$cc_c$conf.high, r4$mi_c$`97.5 %`, r4$cc$conf.high, r4$mi$`97.5 %`, r4$cc_s$conf.high, r4$mi_s$`97.5 %`),
                    n = rep(c(nobs(cc_q4), nrow(icu_all)), 3))
p_ccmi <- ccmi_plot |> mutate(model = factor(model, c("Unadjusted", "Adjusted (main)", "Adjusted + SOFA"))) |>
  ggplot(aes(OR, method, colour = method)) + geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = lower, xmax = upper), width = .2, orientation = "y", linewidth = .9) + geom_point(size = 3.5) +
  geom_text(aes(label = sprintf("%s (%s-%s), n = %d", f2(OR), f2(lower), f2(upper), n)), vjust = -1, size = 3.5, colour = "black") +
  facet_wrap(~ model, ncol = 1) + scale_colour_manual(values = c(pal[["grey"]], pal[["teal"]]), guide = "none") +
  scale_x_continuous(limits = c(0.9, 1.8)) + labs(x = "Odds ratio for 28-day death per 1 mmol/L lactate", y = NULL)
f_ccmi <- save_fig(p_ccmi, q, "fig3_cc_vs_mi", 7, 5.5)
pk <- new_pack() |>
  std_header(q, "In adults with sepsis in the ICU, is admission lactate associated with 28-day mortality, and does the answer change when missing lactate values are handled with multiple imputation?",
             "Design: multicentre prospective cohort study (observational); prognostic-factor question.",
             "death from any cause within 28 days (died_28d).",
             "admission lactate in mmol/L, per 1 mmol/L (continuous); also in categories < 2, 2 to 4, > 4 mmol/L.",
             paste0("all ", n_all, " patients; lactate missing in ", KR$lac_missing, "; complete-case models ", nobs(cc_q4), " patients; multiple imputation ", n_all, ".")) |>
  H("3. Table 1: who was studied") |>
  TB(t1_q4_df, "Table 1. Baseline characteristics of survivors and non-survivors", "table1_by_survival", t1_q4_ft, t1_note) |>
  H("4. Who is missing lactate?") |>
  TB(miss_cmp, "Table 2. Patients with and without an admission lactate", "table2_missing_lactate_comparison") |>
  P(paste0("Patients without a lactate were **less sick** (SOFA ", KR$q4$sofa_missing, " vs ", KR$q4$sofa_measured,
           ") and died less often (", KR$q4$mort_missing, " vs ", KR$q4$mort_measured,
           "). Lactate is therefore NOT missing completely at random; the missingness is explained by observed variables (SOFA, MAP, vasopressor, ICU), which makes 'missing at random' plausible.")) |>
  FG(f_ms, "Figure 1. Percentage of patients with missing lactate by SOFA score", 7, 4.2) |>
  H("5. Main results") |>
  B(c(paste0("Median lactate: non-survivors ", KR$q4$lac_died, " vs survivors ", KR$q4$lac_surv, " mmol/L."),
      paste0("Mortality by lactate category: ", KR$q4$mort_cat, "."),
      paste0("Unadjusted OR per 1 mmol/L: complete case ", KR$q4$cc_c, "; multiple imputation ", KR$q4$mi_c, "."),
      paste0("Adjusted (age, sex, comorbidities): complete case ", KR$q4$cc, " vs **multiple imputation ", KR$q4$mi, "** (main analysis)."),
      paste0("Adding SOFA: complete case ", KR$q4$cc_s, " vs multiple imputation ", KR$q4$mi_s, "."),
      paste0("Median lactate in the complete cases ", KR$q4$median_cc, " mmol/L vs ", KR$q4$median_mi, " mmol/L after imputation: the complete cases over-represent sicker patients."))) |>
  TB(mort_lac_tab, "Table 3. 28-day mortality by admission lactate category", "table3_mortality_by_lactate") |>
  TB(ccmi_tab, "Table 4. Lactate and 28-day death: complete case vs multiple imputation", "table4_cc_vs_mi") |>
  FG(f_ml, "Figure 2. 28-day mortality by admission lactate category (grey = lactate not measured)", 7, 4.2) |>
  FG(f_ccmi, "Figure 3. Odds ratio per 1 mmol/L lactate: complete case vs multiple imputation", 7, 5.5) |>
  H("6. What this means (plain language)") |>
  B(c("Higher admission lactate went with higher 28-day mortality: each extra 1 mmol/L raised the odds of death by about 40-45% (adjusted for age, sex and comorbidities).",
      "Much of this overlaps with overall severity: after adding SOFA, the OR fell to about 1.2. Lactate is partly a marker of how sick the patient is.",
      "Dropping the 93 patients without lactate (complete case) gave a slightly smaller OR than multiple imputation (which uses all 620 patients). The conclusion is the same; the size is modestly different, because the complete cases are a sicker, selected group.")) |>
  H("7. What this does NOT mean") |>
  B(c("It does NOT mean that lowering lactate saves lives. Lactate is a marker, not necessarily a cause.",
      "Multiple imputation does NOT invent data or 'fix' everything: it is valid only if missingness depends on things we measured (MAR). If lactate was missing for reasons related to the unseen value itself (MNAR), no method fully corrects it.")) |>
  H("8. Limitations to discuss (hints)") |>
  B(c("15% missing lactate, not at random: report n missing, who they were, and both analyses.",
      "Single admission value: lactate clearance over time was not recorded.",
      "Units problem in one ICU (mg/dL) found during cleaning: describe the data checks.",
      "OR per 1 mmol/L assumes a straight-line (log-odds) relationship; the categories in Table 3 let readers check it.")) |>
  strobe_block(c("Item 12c: how missing data were addressed (MI, m = 20, variables in the imputation model)",
                 "Item 14b: number of participants with missing data for each variable (Table 1, Table 2)",
                 "Item 16: unadjusted and adjusted estimates with 95% CI; category boundaries (Table 3)",
                 "Item 17: sensitivity analysis (complete case vs MI, Table 4)", "Item 19: limitations (missing data mechanism)"))
packs$Q4 <- pk

# ===========================================================================
# Q5  Fluid balance and ICU length of stay among survivors
# ===========================================================================
q <- "Q5"
surv <- icu |> filter(died_28d == "No")
t1_q5 <- make_t1(surv, "Group"); t1_q5_df <- t1_df(t1_q5); t1_q5_ft <- as_flex_table(t1_q5)
mw5 <- wilcox.test(icu_los_days ~ positive_balance_d3, surv, conf.int = TRUE, exact = FALSE)
l5  <- lm(as.formula(paste("log(icu_los_days) ~ positive_balance_d3 +", CONF)), surv)
l5c <- lm(log(icu_los_days) ~ positive_balance_d3, surv)
l5f <- lm(as.formula(paste("log(icu_los_days) ~ fb10 +", CONF)), surv)
g5 <- tidy(l5, conf.int = TRUE) |> filter(term == "positive_balance_d3Yes")
g5c <- tidy(l5c, conf.int = TRUE) |> filter(term == "positive_balance_d3Yes")
g5f <- tidy(l5f, conf.int = TRUE) |> filter(term == "fb10")
t5 <- t.test(icu_los_days ~ Group, surv)
los_sum <- surv |> group_by(Group) |>
  summarise(n = as.character(n()), `Median (IQR), days` = med_iqr(icu_los_days),
            `Mean (SD), days` = sprintf("%.1f (%.1f)", mean(icu_los_days), sd(icu_los_days)),
            `Range, days` = sprintf("%.1f to %.1f", min(icu_los_days), max(icu_los_days)),
            `Geometric mean, days` = f1(exp(mean(log(icu_los_days))))) |>
  pivot_longer(-Group, names_to = "Summary") |> pivot_wider(names_from = Group, values_from = value)
los_models <- tibble(Analysis = c("Mann-Whitney (Hodges-Lehmann difference, days)", "Log-linear, crude (ratio of geometric means)",
                                  "Log-linear, adjusted (ratio of geometric means)", "Log-linear, adjusted, per 10 ml/kg (ratio)"),
                     n = c(nrow(surv), nobs(l5c), nobs(l5), nobs(l5f)),
                     `Estimate (95% CI)` = c(sprintf("%s (%s to %s)", f1(-mw5$estimate), f1(-mw5$conf.int[2]), f1(-mw5$conf.int[1])),
                                             sprintf("%s (%s to %s)", f2(exp(g5c$estimate)), f2(exp(g5c$conf.low)), f2(exp(g5c$conf.high))),
                                             sprintf("%s (%s to %s)", f2(exp(g5$estimate)), f2(exp(g5$conf.low)), f2(exp(g5$conf.high))),
                                             sprintf("%s (%s to %s)", f2(exp(g5f$estimate)), f2(exp(g5f$conf.low)), f2(exp(g5f$conf.high)))),
                     p = pf(c(mw5$p.value, g5c$p.value, g5$p.value, g5f$p.value)))
KR$q5 <- list(n_surv = nrow(surv), n_pos = sum(surv$Group == "Positive balance"), n_neg = sum(surv$Group == "Negative balance"),
              los_pos = med_iqr(surv$icu_los_days[surv$Group == "Positive balance"]),
              los_neg = med_iqr(surv$icu_los_days[surv$Group == "Negative balance"]),
              mean_all = f1(mean(icu_all$icu_los_days)), median_all = f1(median(icu_all$icu_los_days)),
              mean_surv = f1(mean(surv$icu_los_days)), median_surv = f1(median(surv$icu_los_days)),
              mw_p = pf(mw5$p.value), hl = est_ci(-mw5$estimate, -mw5$conf.int[2], -mw5$conf.int[1], f1),
              ratio_crude = est_ci(exp(g5c$estimate), exp(g5c$conf.low), exp(g5c$conf.high)),
              ratio_adj = est_ci(exp(g5$estimate), exp(g5$conf.low), exp(g5$conf.high)), ratio_adj_p = pf(g5$p.value),
              ratio_10 = est_ci(exp(g5f$estimate), exp(g5f$conf.low), exp(g5f$conf.high)), n_adj = nobs(l5),
              ttest_diff = f1(t5$estimate[2] - t5$estimate[1]))
save_table(t1_q5_df, q, "table1_survivors_by_balance", t1_q5_ft)
save_table(los_sum, q, "table2_los_summary"); save_table(los_models, q, "table3_los_models")
p_los <- ggplot(surv, aes(icu_los_days)) + geom_histogram(binwidth = 1, boundary = 0, fill = pal[["teal"]], colour = "white") +
  geom_vline(xintercept = median(surv$icu_los_days), colour = pal[["blue"]], linewidth = 1) +
  geom_vline(xintercept = mean(surv$icu_los_days), colour = pal[["blue"]], linewidth = 1, linetype = 2) +
  annotate("text", x = median(surv$icu_los_days), y = Inf, vjust = 1.5, hjust = 1.1, label = paste("median", f1(median(surv$icu_los_days)))) +
  annotate("text", x = mean(surv$icu_los_days), y = Inf, vjust = 3.2, hjust = -.1, label = paste("mean", f1(mean(surv$icu_los_days)))) +
  labs(x = "ICU length of stay, survivors (days)", y = "Number of patients")
f_los <- save_fig(p_los, q, "fig1_los_histogram", 7, 4.2)
p_los2 <- ggplot(surv, aes(Group, icu_los_days, fill = Group)) + geom_boxplot(width = .5, outlier.alpha = .4) +
  scale_y_log10(breaks = c(1, 2, 3, 5, 10, 20, 40)) + scale_fill_manual(values = grp_cols, guide = "none") +
  labs(x = NULL, y = "ICU length of stay, days (log scale)")
f_los2 <- save_fig(p_los2, q, "fig2_los_by_group_log", 6, 4.5)
pk <- new_pack() |>
  std_header(q, "Among adults with sepsis who survived to day 28, is a positive cumulative fluid balance by day 3 associated with a longer ICU stay?",
             "Design: multicentre prospective cohort study (observational); analysis restricted to 28-day survivors.",
             "ICU length of stay in days (icu_los_days), right-skewed.",
             "positive vs negative cumulative fluid balance at day 3; secondary: per 10 ml/kg.",
             paste0(nrow(surv), " survivors with a day-3 balance (", KR$q5$n_pos, " positive, ", KR$q5$n_neg, " negative); adjusted model ", nobs(l5), " complete cases.")) |>
  H("3. Table 1: who was studied") |>
  TB(t1_q5_df, "Table 1. Baseline characteristics of 28-day survivors by fluid-balance group", "table1_survivors_by_balance", t1_q5_ft, t1_note) |>
  H("4. Main results") |>
  B(c(paste0("ICU stay is right-skewed: in survivors mean ", KR$q5$mean_surv, " vs median ", KR$q5$median_surv, " days."),
      paste0("Median (IQR) ICU stay: positive balance ", KR$q5$los_pos, " vs negative ", KR$q5$los_neg, " days; Mann-Whitney p ", KR$q5$mw_p, "."),
      paste0("Hodges-Lehmann difference: ", KR$q5$hl, " days."),
      paste0("Log-linear regression: crude ratio of geometric means ", KR$q5$ratio_crude, "; adjusted **", KR$q5$ratio_adj, "**, p ", KR$q5$ratio_adj_p, " (i.e. about ", round(100 * (exp(g5$estimate) - 1)), "% longer stay)."),
      paste0("Per 10 ml/kg more balance: ratio ", KR$q5$ratio_10, "."))) |>
  TB(los_sum, "Table 2. ICU length of stay in survivors by fluid-balance group", "table2_los_summary") |>
  TB(los_models, "Table 3. Association between fluid balance and ICU length of stay (survivors)", "table3_los_models",
     note = "Ratio of geometric means: 1.24 = 24% longer typical stay. Adjusted for age, SOFA, lactate, vasopressor, ventilation, CKD.") |>
  FG(f_los, "Figure 1. ICU length of stay in survivors: a long right tail pulls the mean above the median", 7, 4.2) |>
  FG(f_los2, "Figure 2. ICU length of stay by fluid-balance group (log scale)", 6, 4.5) |>
  H("5. What this means (plain language)") |>
  B(c("Among survivors, those with a positive balance stayed longer in the ICU, by about 2-3 days in the median.",
      paste0("After adjustment, the typical (geometric mean) stay was about ", round(100 * (exp(g5$estimate) - 1)), "% longer."),
      "For a skewed outcome, report the median (IQR), use a rank test or analyse the log of the stay, and present a ratio.")) |>
  H("6. What this does NOT mean") |>
  B(c("It does NOT show that fluid prolongs ICU stay; patients who stay longer have more time and reasons to receive fluid (reverse causation).",
      "It does NOT describe all patients: deaths were excluded, and death shortens the stay.")) |>
  H("7. Limitations to discuss (hints)") |>
  B(c("Selection: restricting to survivors conditions on an outcome that is itself related to fluid (survivor bias). An alternative is 'ICU-free days', which counts death as 0.",
      "ICU discharge depends on bed pressure and local practice, not only on the patient.",
      "Residual confounding by severity; complete-case adjusted model.")) |>
  strobe_block(c("Item 6: participants (why survivors only)", "Item 12: methods for a skewed outcome (log transformation / non-parametric)",
                 "Item 14: descriptive data (Table 1)", "Item 15-16: medians (IQR) and ratios with 95% CI",
                 "Item 19: limitations (survivor selection)"))
packs$Q5 <- pk

# ===========================================================================
# WRITE THE PACKS
# ===========================================================================
titles <- c(Q1 = "Results pack Q1: Positive fluid balance and 28-day mortality",
            Q2 = "Results pack Q2: Cumulative fluid balance and acute kidney injury",
            Q3 = "Results pack Q3: Cumulative fluid balance and ventilator-free days",
            Q4 = "Results pack Q4: Admission lactate, 28-day mortality and missing data",
            Q5 = "Results pack Q5: Fluid balance and ICU length of stay in survivors")
for (q in names(packs)) {
  pk <- c(list(list(type = "h", text = titles[[q]], level = 1)), packs[[q]])
  render_md(pk, file.path("results_packs", q, paste0("results_pack_", q, ".md")), q)
  # Word version: figure paths relative to Course/Data
  render_docx(packs[[q]], file.path("results_packs", paste0("Results_Pack_", q, ".docx")), titles[[q]])
}

# ===========================================================================
# SLIDE DATA (read by python/make_slide_figures.py)
# ===========================================================================
sd <- "output/slide_data"
write_csv(cva, file.path(sd, "crude_vs_adjusted.csv"))
write_csv(forest_df |> transmute(term, OR = estimate, lower = conf.low, upper = conf.high), file.path(sd, "forest_adjusted.csv"))
km_df <- tibble(time = km$time, surv = km$surv, lower = km$lower, upper = km$upper,
                group = rep(c("neg", "pos"), km$strata))
write_csv(km_df, file.path(sd, "km_steps.csv"))
rk <- summary(km, times = c(0, 7, 14, 21, 28), extend = TRUE)
write_csv(tibble(time = rk$time, n_risk = rk$n.risk, group = rep(c("neg", "pos"), each = 5)), file.path(sd, "km_risk.csv"))
write_csv(tibble(logrank_p = p_lr, hr_adj = h_ad$estimate, hr_lo = h_ad$conf.low, hr_hi = h_ad$conf.high,
                 surv28_neg = km28$surv[1], surv28_pos = km28$surv[2]), file.path(sd, "km_meta.csv"))
write_csv(int_tab |> transmute(subgroup, n, OR = estimate, lower = conf.low, upper = conf.high, p_int = p_int), file.path(sd, "interaction.csv"))
write_csv(miss_sofa, file.path(sd, "missing_by_sofa.csv"))
write_csv(ccmi_plot, file.path(sd, "cc_vs_mi.csv"))
write_csv(aki_cat, file.path(sd, "aki_by_balance.csv"))

# ===========================================================================
# key_results.md
# ===========================================================================
r <- KR; s <- r$t1
kr <- c(
"# FLUID-ICU key results (SIMULATED DATA: NOT REAL PATIENTS)", "",
"Every number that the slides, demos and handouts may quote. Generated automatically by `R/06_results_packs.R`",
"from `fluid_icu_clean.rds`; the same models are run live in scripts 02-05 (source script given for each block).",
"Odds and hazard ratios use profile-likelihood / Wald 95% CIs as printed by R; rounding may differ by 0.01 between outputs.", "",
"## Sample (02_describe.R)",
paste0("- Enrolled: **", r$n, "** adults with sepsis in 4 ICUs (", paste(names(r$sites), r$sites, sep = " n = ", collapse = "; "), "), Jan 2023 to Dec 2024."),
paste0("- Raw file: 623 rows (3 duplicates) -> 620 after cleaning (01_clean.R; see cleaning_log.md)."),
paste0("- ", r$flow),
paste0("- Age mean ", r$age, " years; male ", r$male, "; SOFA median (IQR) ", r$sofa, "."),
paste0("- 28-day mortality: **", r$mort, "**."),
paste0("- Positive balance by day 3: **", r$pos, "**; cumulative balance median (IQR) ", r$cfb, " ml/kg."),
paste0("- Lactate missing: **", r$lac_missing, "** (other variables <= 1%)."), "",
"## Table 1 highlights (02_describe.R): negative vs positive balance",
paste0("- SOFA median (IQR): ", s$sofa[1], " vs ", s$sofa[2]),
paste0("- Vasopressor: ", s$vaso[1], " vs ", s$vaso[2]),
paste0("- Mechanical ventilation: ", s$mv[1], " vs ", s$mv[2]),
paste0("- Lactate median (IQR): ", s$lac[1], " vs ", s$lac[2], " mmol/L"),
paste0("- Heart failure: ", s$hf[1], " vs ", s$hf[2], " (clinicians give less fluid in heart failure)"),
paste0("- Mean age: ", s$age[1], " vs ", s$age[2], " years"), "",
"## Q1: positive balance and 28-day mortality (03_compare.R, 04_models.R, 05_missing.R)",
paste0("- Mortality: positive ", r$q1$mort_pos, " vs negative ", r$q1$mort_neg, "; risk difference ", r$q1$rd, " percentage points; RR ", r$q1$rr, "; chi-square p < 0.001."),
paste0("- **Crude OR ", r$q1$crude, "**, p ", r$q1$crude_p, " (n = 618)."),
paste0("- Crude OR in the ", r$q1$n_cc, " complete cases: ", r$q1$crude_cc, "."),
paste0("- **Adjusted OR ", r$q1$adj, "**, p ", r$q1$adj_p, " (n = ", r$q1$n_cc, "; age, SOFA, lactate, vasopressor, ventilation, CKD)."),
paste0("- Multiple imputation (m = 20, n = 620): adjusted OR ", r$q1$mi, ", p ", r$q1$mi_p, "."),
paste0("- Kaplan-Meier survival at day 28: ", r$q1$surv28, "; **log-rank p ", r$q1$logrank, "** (chi-square ", r$q1$logrank_chisq, ")."),
paste0("- Cox HR crude ", r$q1$hr_crude, "; **adjusted HR ", r$q1$hr_adj, "**, p ", r$q1$hr_adj_p, "; PH global test p = ", r$q1$zph, "."),
paste0("- Interaction (positive balance x heart failure): **p = ", r$q1$p_int, "** (Wald; LR test p = ", r$q1$p_int_lr, ")."),
paste0("  - Heart failure (n = ", r$q1$n_hf, "): adjusted OR ", r$q1$or_hf, "."),
paste0("  - No heart failure (n = ", r$q1$n_nohf, "): adjusted OR ", r$q1$or_nohf, "."), "",
"## Q2: fluid balance and AKI (results pack Q2; 03_compare.R for the 2x2)",
paste0("- AKI (KDIGO >= 1): ", r$q2$aki_all, " overall; RRT ", r$q2$rrt_all, "."),
paste0("- AKI positive ", r$q2$aki_pos, " vs negative ", r$q2$aki_neg, "."),
paste0("- Gradient by balance (ml/kg): ", r$q2$gradient, "."),
paste0("- OR per 10 ml/kg: crude ", r$q2$crude10, "; **adjusted ", r$q2$adj10, "**, p ", r$q2$adj10_p, " (n = ", r$q2$n_adj, ")."),
paste0("- Positive vs negative: crude OR ", r$q2$bin_crude, "; adjusted OR ", r$q2$bin_adj, "."),
paste0("- AKI stage 2-3, adjusted OR per 10 ml/kg: ", r$q2$st23, "."), "",
"## Q3: fluid balance and ventilator-free days (results pack Q3; 03_compare.R)",
paste0("- VFD median (IQR): positive ", r$q3$vfd_pos, " vs negative ", r$q3$vfd_neg, " days; Mann-Whitney p ", r$q3$mw_p, "."),
paste0("- Linear regression per 10 ml/kg: crude ", r$q3$lm_crude, " days; **adjusted ", r$q3$lm_adj, " days**, p ", r$q3$lm_adj_p, " (n = ", r$q3$n_adj, ")."),
paste0("- Positive vs negative, adjusted difference: ", r$q3$bin_adj, " days."), "",
"## Q4: lactate, mortality and missing data (05_missing.R)",
paste0("- Lactate missing ", r$lac_missing, "; SOFA median ", r$q4$sofa_missing, " (missing) vs ", r$q4$sofa_measured, " (measured); mortality ", r$q4$mort_missing, " vs ", r$q4$mort_measured, ", so not MCAR (MAR is plausible)."),
paste0("- Median lactate: non-survivors ", r$q4$lac_died, " vs survivors ", r$q4$lac_surv, " mmol/L."),
paste0("- Mortality by lactate category: ", r$q4$mort_cat, "."),
paste0("- OR per 1 mmol/L, unadjusted: CC ", r$q4$cc_c, " vs MI ", r$q4$mi_c, "."),
paste0("- **Adjusted (age, sex, diabetes, CKD, heart failure): CC ", r$q4$cc, " (n = ", r$q4$n_cc, ") vs MI ", r$q4$mi, " (n = 620).**"),
paste0("- + SOFA: CC ", r$q4$cc_s, " vs MI ", r$q4$mi_s, "."),
paste0("- Median lactate: complete cases ", r$q4$median_cc, " vs after imputation ", r$q4$median_mi, " mmol/L."), "",
"## Q5: fluid balance and ICU stay in survivors (results pack Q5; 03_compare.R)",
paste0("- ICU stay, all patients: mean ", r$q5$mean_all, " vs median ", r$q5$median_all, " days (right-skewed). Survivors: mean ", r$q5$mean_surv, " vs median ", r$q5$median_surv, "."),
paste0("- Survivors n = ", r$q5$n_surv, " (", r$q5$n_pos, " positive, ", r$q5$n_neg, " negative)."),
paste0("- Median (IQR): positive ", r$q5$los_pos, " vs negative ", r$q5$los_neg, " days; Mann-Whitney p ", r$q5$mw_p, "; Hodges-Lehmann difference ", r$q5$hl, " days."),
paste0("- Ratio of geometric means: crude ", r$q5$ratio_crude, "; **adjusted ", r$q5$ratio_adj, "**, p ", r$q5$ratio_adj_p, " (n = ", r$q5$n_adj, "); per 10 ml/kg ", r$q5$ratio_10, "."),
paste0("- t-test difference in means (the 'wrong' test, for contrast): ", r$q5$ttest_diff, " days."), "",
"## Teaching-feature check",
paste0("- Confounding by indication visible: crude OR ", f2(o_cr$estimate), " > adjusted OR ", f2(o_ad$estimate), "; adjusted CI excludes 1: ", o_ad$conf.low > 1, "."),
paste0("- Cox HR in the same direction: crude ", f2(h_cr$estimate), ", adjusted ", f2(h_ad$estimate), " (CI lower limit ", f2(h_ad$conf.low), ")."),
paste0("- Interaction p in 0.03-0.10: ", p_int >= 0.03 & p_int <= 0.10, " (p = ", pf(p_int), ")."),
paste0("- CC vs MI differ modestly (Q4 adjusted): ", f2(r4$cc$estimate), " vs ", f2(r4$mi$estimate), "."),
paste0("- ICU stay right-skewed: mean ", r$q5$mean_all, " > median ", r$q5$median_all, ".")
)
writeLines(kr, "key_results.md", useBytes = TRUE)

# ===========================================================================
# VIETNAMESE VERSIONS (for Vietnamese participants)
#   results_packs/QN/results_pack_QN_VN.md, results_packs/Results_Pack_QN_VN.docx,
#   results_packs/QN/tables/*_VN.csv|docx, results_packs/QN/figures/*_VN.png, key_results_VN.md
# Every number below comes from the same R objects as the English packs, so EN and VN agree.
# Numbers keep the decimal POINT (approved VN convention, Book/textbook/TRANSLATION_SPEC_VI.md).
# Terms follow Course/References/glossary_EN_VN.md.
# ===========================================================================
v <- function(x) {                       # number strings: "95% CI a to b" -> "khoảng tin cậy 95% a đến b"
  x <- gsub("95% CI", "khoảng tin cậy 95%", x, fixed = TRUE)
  gsub(" to ", " đến ", x, fixed = TRUE)
}
VN_TR <- c(
  # Table 1
  "Characteristic" = "Đặc điểm", "Age, years" = "Tuổi, năm", "Sex" = "Giới", "Female" = "Nữ", "Male" = "Nam",
  "Weight, kg" = "Cân nặng, kg", "Diabetes" = "Đái tháo đường", "Chronic kidney disease" = "Bệnh thận mạn",
  "Heart failure" = "Suy tim", "Hypertension" = "Tăng huyết áp", "Source of infection" = "Nguồn nhiễm khuẩn",
  "Respiratory" = "Hô hấp", "Urinary" = "Tiết niệu", "Abdominal" = "Ổ bụng", "Skin/soft tissue" = "Da/mô mềm",
  "Other" = "Khác", "SOFA score" = "Điểm SOFA", "APACHE II score" = "Điểm APACHE II",
  "Lactate, mmol/L" = "Lactat, mmol/L", "Mean arterial pressure, mmHg" = "Huyết áp động mạch trung bình, mmHg",
  "Vasopressor on admission" = "Thuốc vận mạch lúc nhập ICU", "Mechanical ventilation" = "Thở máy",
  "Cumulative fluid balance day 3, ml/kg" = "Cân bằng dịch tích lũy ngày 3, ml/kg", "Missing" = "Thiếu",
  # groups
  "Negative balance" = "Cân bằng dịch âm", "Positive balance" = "Cân bằng dịch dương",
  # Q1
  "Outcome" = "Kết cục", "Effect (95% CI)" = "Tác động (khoảng tin cậy 95%)",
  "Died by day 28, n/N (%)" = "Tử vong trong 28 ngày, n/N (%)",
  "Survival at day 28 (Kaplan-Meier), %" = "Sống còn tại ngày 28 (Kaplan-Meier), %",
  "Variable" = "Biến số", "Crude OR (95% CI)" = "OR thô (khoảng tin cậy 95%)", "Crude p" = "p thô",
  "Adjusted OR (95% CI)" = "OR hiệu chỉnh (khoảng tin cậy 95%)", "Adjusted p" = "p hiệu chỉnh",
  "Positive fluid balance (vs negative)" = "Cân bằng dịch dương (so với âm)", "Age, per year" = "Tuổi, mỗi năm",
  "SOFA score, per point" = "Điểm SOFA, mỗi điểm", "Lactate, per mmol/L" = "Lactat, mỗi mmol/L",
  "Vasopressor" = "Thuốc vận mạch",
  "Model" = "Mô hình", "Events" = "Số biến cố", "HR (95% CI)" = "HR (khoảng tin cậy 95%)", "Crude" = "Thô",
  "Adjusted (pre-specified confounders)" = "Hiệu chỉnh (các yếu tố gây nhiễu xác định trước)",
  "Subgroup" = "Phân nhóm", "Deaths, negative balance" = "Tử vong, cân bằng dịch âm",
  "Deaths, positive balance" = "Tử vong, cân bằng dịch dương", "p for interaction" = "p tương tác",
  "No heart failure" = "Không suy tim",
  "Analysis" = "Phân tích", "OR (95% CI)" = "OR (khoảng tin cậy 95%)", "Crude, all patients" = "Thô, tất cả người bệnh",
  "Crude, complete cases" = "Thô, các trường hợp đầy đủ",
  "Adjusted, complete cases (main)" = "Hiệu chỉnh, các trường hợp đầy đủ (chính)",
  "Adjusted, multiple imputation (m = 20)" = "Hiệu chỉnh, quy gán đa bội (m = 20)",
  "Adjusted, complete cases" = "Hiệu chỉnh, các trường hợp đầy đủ",
  "Adjusted, multiple imputation" = "Hiệu chỉnh, quy gán đa bội",
  # Q2
  "AKI stage" = "Giai đoạn AKI", "Cumulative balance day 3, ml/kg" = "Cân bằng dịch tích lũy ngày 3, ml/kg",
  "Any AKI, n (%)" = "AKI bất kỳ, n (%)", "AKI stage 2-3, %" = "AKI giai đoạn 2-3, %", "RRT, %" = "RRT, %",
  "Balance per 10 ml/kg, crude" = "Cân bằng dịch mỗi 10 ml/kg, thô",
  "Balance per 10 ml/kg, adjusted" = "Cân bằng dịch mỗi 10 ml/kg, hiệu chỉnh",
  "Positive vs negative balance, crude" = "Cân bằng dương so với âm, thô",
  "Positive vs negative balance, adjusted" = "Cân bằng dương so với âm, hiệu chỉnh",
  "Balance per 10 ml/kg, adjusted (outcome AKI stage 2-3)" = "Cân bằng dịch mỗi 10 ml/kg, hiệu chỉnh (kết cục AKI giai đoạn 2-3)",
  # Q3
  "Summary" = "Chỉ số", "VFD, median (IQR)" = "VFD, trung vị (IQR)", "VFD, mean (SD)" = "VFD, trung bình (SD)",
  "VFD = 0 (died or ventilated 28 d), n (%)" = "VFD = 0 (tử vong hoặc thở máy 28 ngày), n (%)",
  "VFD = 28 (never ventilated, alive), n (%)" = "VFD = 28 (không thở máy, còn sống), n (%)",
  "Ventilated patients: VFD median (IQR)" = "Người bệnh thở máy: VFD trung vị (IQR)",
  "Difference in VFD, days (95% CI)" = "Chênh lệch VFD, ngày (khoảng tin cậy 95%)",
  "Balance per 10 ml/kg, crude (linear)" = "Cân bằng dịch mỗi 10 ml/kg, thô (tuyến tính)",
  "Balance per 10 ml/kg, adjusted (linear)" = "Cân bằng dịch mỗi 10 ml/kg, hiệu chỉnh (tuyến tính)",
  "Positive vs negative balance, adjusted (linear)" = "Cân bằng dương so với âm, hiệu chỉnh (tuyến tính)",
  "Positive vs negative balance, Mann-Whitney (Hodges-Lehmann)" = "Cân bằng dương so với âm, Mann-Whitney (Hodges-Lehmann)",
  # Q4
  "Lactate measured" = "Có đo lactat", "Lactate missing" = "Thiếu lactat",
  "SOFA, median (IQR)" = "SOFA, trung vị (IQR)", "MAP, median (IQR)" = "MAP, trung vị (IQR)",
  "Vasopressor, n (%)" = "Thuốc vận mạch, n (%)", "Died by day 28, n (%)" = "Tử vong trong 28 ngày, n (%)",
  "Admission lactate, mmol/L" = "Lactat lúc nhập ICU, mmol/L", "Method" = "Phương pháp",
  "OR per 1 mmol/L (95% CI)" = "OR mỗi 1 mmol/L (khoảng tin cậy 95%)", "Unadjusted" = "Chưa hiệu chỉnh",
  "Adjusted: age, sex, diabetes, CKD, heart failure (main)" = "Hiệu chỉnh: tuổi, giới, đái tháo đường, bệnh thận mạn, suy tim (chính)",
  "Main + SOFA score" = "Mô hình chính + điểm SOFA", "Complete case" = "Trường hợp đầy đủ",
  "Multiple imputation (m = 20)" = "Quy gán đa bội (m = 20)",
  # Q5
  "Median (IQR), days" = "Trung vị (IQR), ngày", "Mean (SD), days" = "Trung bình (SD), ngày",
  "Range, days" = "Khoảng giá trị, ngày", "Geometric mean, days" = "Trung bình nhân, ngày",
  "Estimate (95% CI)" = "Ước lượng (khoảng tin cậy 95%)",
  "Mann-Whitney (Hodges-Lehmann difference, days)" = "Mann-Whitney (chênh lệch Hodges-Lehmann, ngày)",
  "Log-linear, crude (ratio of geometric means)" = "Tuyến tính trên thang log, thô (tỷ số trung bình nhân)",
  "Log-linear, adjusted (ratio of geometric means)" = "Tuyến tính trên thang log, hiệu chỉnh (tỷ số trung bình nhân)",
  "Log-linear, adjusted, per 10 ml/kg (ratio)" = "Tuyến tính trên thang log, hiệu chỉnh, mỗi 10 ml/kg (tỷ số)")
VN_PH <- c("Overall" = "Toàn bộ", "Negative balance" = "Cân bằng dịch âm", "Positive balance" = "Cân bằng dịch dương",
           "Survived to day 28" = "Sống đến ngày 28", "Died by day 28" = "Tử vong trong 28 ngày",
           "Risk difference" = "Hiệu số nguy cơ", "KDIGO stage" = "KDIGO giai đoạn",
           "chi-square p" = "p Chi bình phương")
tr_vn <- function(x) {
  x <- as.character(x)
  hit <- !is.na(x) & x %in% names(VN_TR)
  out <- x
  out[hit] <- VN_TR[x[hit]]
  for (i in seq_along(VN_PH)) out[!hit] <- gsub(names(VN_PH)[i], VN_PH[[i]], out[!hit], fixed = TRUE)
  v(out)
}
tr_df <- function(df) {                   # translate headers and text cells; numbers untouched
  df <- df |> mutate(across(where(is.character), function(x) {
    pre <- sub("^(\\s*).*$", "\\1", x)    # keep the Table 1 indentation
    paste0(pre, tr_vn(trimws(x)))
  }))
  names(df) <- tr_vn(names(df))
  df
}
t1_ft_vn <- function(df) {                # VN Table 1 as a flextable (bold variables, indented levels)
  lvl <- grepl("^\\s", df[[1]])
  df[[1]] <- trimws(df[[1]])
  flextable(df) |> theme_vanilla() |> bold(i = which(!lvl), j = 1) |>
    padding(i = which(lvl), j = 1, padding.left = 14)
}
save_table_vn <- function(df, q, name, ft = NULL) {
  write_excel_csv(df, file.path("results_packs", q, "tables", paste0(name, "_VN.csv")), na = "")   # BOM for Excel
  if (is.null(ft)) ft <- df |> flextable() |> theme_vanilla()
  ft <- ft |> fontsize(size = 9, part = "all") |> flextable::font(fontname = "Arial", part = "all") |>
    autofit() |> set_table_properties(layout = "autofit", width = 1)
  ft_file <- if (startsWith(name, "table1")) add_footer_lines(ft, t1_note_vn) else ft
  save_as_docx(ft_file, path = file.path("results_packs", q, "tables", paste0(name, "_VN.docx")))
  invisible(ft)
}
TBV <- function(pk, df, caption, q, name, t1 = FALSE, note = NULL) {   # translate, save, add to pack
  dv <- tr_df(df)
  ft <- save_table_vn(dv, q, name, if (t1) t1_ft_vn(dv) else NULL)
  TB(pk, dv, caption, paste0(name, "_VN"), if (t1) ft else NULL, note)
}
fig_vn <- function(q, name) file.path("results_packs", q, "figures", paste0(name, "_VN.png"))
save_fig_vn <- function(p, q, name, w = 7, h = 4.5) {
  ggsave(fig_vn(q, name), p, width = w, height = h, dpi = 300, bg = "white")
  fig_vn(q, name)
}
grp_vn <- c("Negative balance" = "Cân bằng dịch âm", "Positive balance" = "Cân bằng dịch dương")
grp_cols_vn <- setNames(unname(grp_cols), unname(grp_vn))
vn_grp <- function(d) d |> mutate(Group = factor(grp_vn[as.character(Group)], unname(grp_vn)))
vn_fb <- function(d) d |> mutate(fb_cat = factor(v(as.character(fb_cat)), v(levels(icu$fb_cat))))
x_fb_vn <- "Cân bằng dịch tích lũy ngày 3 (ml/kg)"
yn_vn <- function(x) if (isTRUE(x)) "có" else "không"

flow_vn <- paste0("Lưu đồ người tham gia: ", n_all, " người bệnh được tuyển -> ", n_all - n_exp,
                  " người không có cân bằng dịch ngày 3 (thiếu cân nặng hoặc lượng dịch ra sau khi làm sạch) -> ",
                  n_exp, " người trong phân tích phơi nhiễm -> ", n_exp - n_cc,
                  " người không có lactat (hoặc tuổi) -> ", n_cc, " người trong mô hình hiệu chỉnh trên các trường hợp đầy đủ.")
t1_note_vn <- paste("Trung bình (SD); n (%); trung vị (Q1, Q3). Thiếu = số người bệnh không có giá trị đó.",
                    "Bảng 1 chỉ mô tả người bệnh lúc vào ICU. Các kết cục, như tử vong 28 ngày, nằm ở phần kết quả chính.")
design_vn <- "Thiết kế: nghiên cứu thuần tập tiến cứu đa trung tâm (quan sát)."
std_header_vn <- function(pk, question, design, outcome, exposure, sample) {
  pk |>
    P(paste0("> **DỮ LIỆU MÔ PHỎNG: KHÔNG PHẢI NGƯỜI BỆNH THẬT.** FLUID-ICU được tạo bằng máy tính cho khóa học này. ",
             "Hãy viết bản thảo như một bài tập huấn luyện và ghi rõ rằng dữ liệu là mô phỏng.")) |>
    H("1. Câu hỏi") |> P(paste0("**", question, "**")) |>
    H("2. Thiết kế và dữ liệu") |>
    B(c(design,
        "Bối cảnh: 4 ICU (ICU A-D), người lớn bị sepsis được tuyển liên tiếp, thời gian tuyển từ tháng 1/2023 đến tháng 12/2024.",
        paste0("Phơi nhiễm: ", exposure), paste0("Kết cục: ", outcome),
        paste0("Mẫu phân tích: ", sample),
        "Các yếu tố gây nhiễu xác định trước (SAP): tuổi, điểm SOFA, lactat, thuốc vận mạch, thở máy, bệnh thận mạn.",
        "Phần mềm: R 4.6 (các gói gtsummary, survival, mice). Script: Course/Data/R/."))
}
strobe_vn <- function(pk, items) pk |> H("Các mục STROBE mà gói này giúp bạn viết") |> B(items)
packs_vn <- list()

# ---- Q1 (VN) ---------------------------------------------------------------
q <- "Q1"
km_vn_dat <- vn_grp(icu)
km_vn <- survfit(Surv(time_to_event_28d, died_28d == "Yes") ~ Group, data = km_vn_dat)
g_km_vn <- ggsurvplot(km_vn, data = km_vn_dat, risk.table = TRUE, pval = FALSE, conf.int = TRUE,
                      palette = unname(grp_cols_vn), legend.labs = names(grp_cols_vn), legend.title = "",
                      xlab = "Số ngày kể từ khi nhập ICU", ylab = "Xác suất sống còn",
                      risk.table.title = "Số người bệnh còn nguy cơ",
                      break.time.by = 7, xlim = c(0, 28), ylim = c(0.5, 1), risk.table.height = 0.25,
                      ggtheme = theme_minimal(base_size = 13))
g_km_vn$plot <- g_km_vn$plot + annotate("text", x = 1, y = 0.55, hjust = 0, size = 4.5,
                                        label = paste0("Log-rank p ", pf(p_lr)))
f_km_vn <- fig_vn(q, "fig1_km_balance")
ragg::agg_png(f_km_vn, width = 7, height = 5.5, units = "in", res = 300); print(g_km_vn); invisible(dev.off())
f_forest_vn <- save_fig_vn(p_forest + (forest_df |> mutate(label = factor(VN_TR[nice[term]], levels = rev(unname(VN_TR[nice]))))) +
                             labs(x = "OR hiệu chỉnh cho tử vong 28 ngày (thang log)"), q, "fig2_forest_adjusted")
f_cva_vn <- save_fig_vn(p_cva + (cva |> mutate(model = factor(VN_TR[model], rev(unname(VN_TR[model]))))) +
                          labs(x = "OR cho tử vong 28 ngày, dương so với âm (thang log)"), q, "fig3_crude_vs_adjusted", 7, 3.8)
f_int_vn <- save_fig_vn(p_int_fig + (int_tab |> mutate(subgroup = factor(sprintf("%s (n = %d)", VN_TR[subgroup], n)))) +
                          labs(x = "OR hiệu chỉnh cho tử vong 28 ngày, dương so với âm (thang log)",
                               caption = paste0("p tương tác = ", pf(p_int))), q, "fig4_interaction_hf", 7, 3.2)
pk <- new_pack() |>
  std_header_vn("Ở người lớn bị sepsis điều trị tại ICU, cân bằng dịch tích lũy dương vào ngày 3 có liên quan với tử vong 28 ngày cao hơn không?",
                design_vn,
                "tử vong do mọi nguyên nhân trong vòng 28 ngày kể từ khi nhập ICU (died_28d); thời gian đến tử vong cho phân tích sống còn (time_to_event_28d, thông tin khuyết (censored) tại ngày 28).",
                "cân bằng dịch tích lũy dương vào ngày 3 (dịch vào trừ dịch ra trong các ngày ICU 1-3 > 0 ml/kg) so với cân bằng âm hoặc bằng 0.",
                paste0(n_exp, " trong số ", n_all, " người bệnh (2 người không có cân bằng dịch ngày 3). Các mô hình hiệu chỉnh: ", nobs(m_adj), " trường hợp đầy đủ.")) |>
  P(flow_vn) |>
  H("3. Bảng 1: đối tượng nghiên cứu") |>
  TBV(t1_bal_df, "Bảng 1. Đặc điểm ban đầu theo nhóm cân bằng dịch", q, "table1_by_balance", t1 = TRUE, note = t1_note_vn) |>
  P(paste0("Hãy đọc Bảng 1 trước: nhóm cân bằng dịch dương **nặng hơn** lúc ban đầu: SOFA trung vị ",
           v(by_grp$sofa[2]), " so với ", v(by_grp$sofa[1]), ", dùng thuốc vận mạch ", by_grp$vaso[2], " so với ", by_grp$vaso[1],
           ". Đây là nhiễu do chỉ định: người bệnh nặng hơn được truyền nhiều dịch hơn VÀ tử vong nhiều hơn.")) |>
  H("4. Kết quả chính") |>
  TBV(out_tab, "Bảng 2. Tử vong 28 ngày theo nhóm cân bằng dịch (chưa hiệu chỉnh)", q, "table2_outcome") |>
  TBV(log_tab, paste0("Bảng 3. Hồi quy logistic cho tử vong 28 ngày: tỷ số chênh thô và hiệu chỉnh (mô hình hiệu chỉnh n = ", nobs(m_adj), ")"), q, "table3_logistic") |>
  B(c(paste0("OR thô (tất cả ", nobs(m_crude), " người bệnh): **", v(KR$q1$crude), "**, p ", KR$q1$crude_p, "."),
      paste0("OR thô trên cùng ", nobs(m_adj), " trường hợp đầy đủ: ", v(KR$q1$crude_cc), "."),
      paste0("OR hiệu chỉnh (tuổi, SOFA, lactat, thuốc vận mạch, thở máy, bệnh thận mạn): **", v(KR$q1$adj), "**, p ", KR$q1$adj_p, "."),
      paste0("Sống còn Kaplan-Meier tại ngày 28: ", sprintf("%.1f%% (âm) so với %.1f%% (dương)", 100 * km28$surv[1], 100 * km28$surv[2]),
             "; log-rank p ", KR$q1$logrank, "."),
      paste0("Tỷ số nguy cơ tức thời (HR) theo mô hình Cox: thô ", v(KR$q1$hr_crude), "; hiệu chỉnh **", v(KR$q1$hr_adj), "**, p ", KR$q1$hr_adj_p,
             " (kiểm định giả định nguy cơ tỷ lệ, p toàn cục = ", KR$q1$zph, ")."))) |>
  TBV(cox_tab, "Bảng 4. Hồi quy Cox cho thời gian đến tử vong trong 28 ngày", q, "table4_cox") |>
  FG(f_km_vn, "Hình 1. Đường cong sống còn Kaplan-Meier đến ngày 28 theo nhóm cân bằng dịch, kèm số người bệnh còn nguy cơ", 7, 5.5) |>
  FG(f_forest_vn, "Hình 2. Tỷ số chênh hiệu chỉnh cho tử vong 28 ngày (biểu đồ rừng)", 7, 4.5) |>
  FG(f_cva_vn, "Hình 3. Tỷ số chênh của cân bằng dịch dương trước và sau hiệu chỉnh", 7, 3.8) |>
  H("5. Các phân tích khác") |>
  TBV(int_out, "Bảng 5. Thay đổi tác động theo suy tim (xác định trước)", q, "table5_interaction_hf") |>
  FG(f_int_vn, "Hình 4. Tỷ số chênh của cân bằng dịch dương ở người bệnh có và không có suy tim", 7, 3.2) |>
  TBV(sens_tab, "Bảng 6. Các phân tích độ nhạy cho mối liên quan chính", q, "table6_sensitivity") |>
  H("6. Ý nghĩa (bằng lời đơn giản)") |>
  B(c(paste0("Người bệnh có cân bằng dịch dương tử vong nhiều hơn (", sprintf("%.0f%%", 100 * risk[2]), " so với ",
             sprintf("%.0f%%", 100 * risk[1]), "). Nhưng họ cũng nặng hơn."),
      paste0("Sau khi tính đến mức độ nặng, mối liên quan nhỏ đi nhiều (OR giảm từ ", f2(o_cr$estimate), " xuống ", f2(o_ad$estimate), "). Phần lớn chênh lệch thô là do nhiễu do chỉ định."),
      "Vẫn còn một mối liên quan vừa phải: khoảng tin cậy 95% chỉ vừa đủ loại trừ 1, và mô hình Cox cho HR tương tự với khoảng tin cậy vừa chạm 1. Bằng chứng ở mức yếu đến trung bình, không mạnh.",
      paste0("Mối liên quan có vẻ mạnh hơn ở người bệnh suy tim (p tương tác ", pf(p_int), "). Phân tích này được xác định trước nhưng chỉ dựa trên ", hf_yes$n, " người bệnh suy tim trong mô hình hiệu chỉnh (trường hợp đầy đủ), vì vậy hãy xem đây là một giả thuyết."))) |>
  H("7. Kết quả này KHÔNG có nghĩa là gì") |>
  B(c("Kết quả KHÔNG cho thấy dịch GÂY RA tử vong. Đây là nghiên cứu quan sát: hãy viết 'có liên quan với', không viết 'gây ra' hay 'làm tăng'.",
      "Kết quả KHÔNG khuyên bác sĩ hạn chế dịch. Chỉ một thử nghiệm ngẫu nhiên (như Bài báo 1) mới kiểm chứng được một chiến lược truyền dịch.",
      paste0("Giá trị p ", pf(o_ad$p.value), " không phải là 'bằng chứng chắc chắn'; khoảng tin cậy từ ", f2(o_ad$conf.low), " đến ", f2(o_ad$conf.high), " phù hợp với cả một tác động rất nhỏ lẫn một tác động lớn."))) |>
  H("8. Các hạn chế cần bàn luận (gợi ý)") |>
  B(c("Nhiễu tồn dư: SOFA và lactat chỉ đo mức độ nặng một cách chưa hoàn hảo; mức độ nặng không đo được có thể giải thích mối liên quan còn lại.",
      "Quan hệ nhân quả ngược: người bệnh diễn tiến xấu (sốc, thiểu niệu) tích lũy dịch vì họ đang dần tử vong, chứ không phải ngược lại.",
      "Cân bằng dịch được đo trong các ngày 1-3; người bệnh tử vong trước ngày 3 có ít thời gian tích lũy dịch hơn (vấn đề thời gian bất tử, immortal time).",
      paste0("Thiếu lactat (15%): mô hình trường hợp đầy đủ mất ", n_exp - n_cc, " người bệnh; quy gán đa bội cho kết quả tương tự (Bảng 6)."),
      "Lượng dịch mất không nhận biết được không được ghi nhận; chia đôi thành dương/âm làm mất thông tin (xem Q2 cho phiên bản liên tục).")) |>
  strobe_vn(c("Mục 4-5: thiết kế và bối cảnh (phần 2)", "Mục 6: người tham gia và tiêu chuẩn chọn",
              "Mục 7: các biến số (phơi nhiễm, kết cục, yếu tố gây nhiễu và yếu tố thay đổi tác động là suy tim)",
              "Mục 12a-e: phương pháp thống kê, gồm nhiễu, tương tác, dữ liệu thiếu, phân tích độ nhạy",
              "Mục 13: số người tham gia (câu mô tả lưu đồ)", "Mục 14: dữ liệu mô tả (Bảng 1, dữ liệu thiếu)",
              "Mục 15: dữ liệu kết cục (Bảng 2)", "Mục 16: ước lượng chưa hiệu chỉnh và đã hiệu chỉnh kèm khoảng tin cậy 95% (Bảng 3-4)",
              "Mục 17: các phân tích khác (phân nhóm/tương tác và độ nhạy, Bảng 5-6)"))
packs_vn$Q1 <- pk

# ---- Q2 (VN) ---------------------------------------------------------------
q <- "Q2"
stage_vn <- c("Stage 3" = "Giai đoạn 3", "Stage 2" = "Giai đoạn 2", "Stage 1" = "Giai đoạn 1", "No AKI" = "Không AKI")
f_aki_vn <- save_fig_vn(p_aki + (vn_fb(p_aki$data) |> mutate(stage = factor(stage_vn[as.character(stage)], unname(stage_vn)))) +
                          scale_fill_manual(values = setNames(c(pal[["blue"]], pal[["sky"]], pal[["lteal"]], "#D5DDE1"), unname(stage_vn)), name = NULL) +
                          labs(x = x_fb_vn, y = "% người bệnh"), q, "fig1_aki_stage_by_balance")
f_sc_vn <- save_fig_vn(p_scatter + scale_y_continuous(breaks = c(0, .25, .5, .75, 1),
                                                      labels = c("0% (không AKI)", "25%", "50%", "75%", "100% (AKI)")) +
                         labs(x = x_fb_vn, y = "Xác suất AKI (thô)"), q, "fig2_aki_probability_curve")
pk <- new_pack() |>
  std_header_vn("Ở người lớn bị sepsis điều trị tại ICU, cân bằng dịch tích lũy cao hơn vào ngày 3 có liên quan với tổn thương thận cấp không?",
                design_vn,
                "tổn thương thận cấp (AKI; KDIGO giai đoạn >= 1, giai đoạn cao nhất trong các ngày ICU 1-7; aki_any). Kết cục phụ: AKI giai đoạn 2-3; điều trị thay thế thận (RRT, chỉ mô tả).",
                "cân bằng dịch tích lũy ngày 3 tính bằng ml/kg, phân tích theo mỗi 10 ml/kg (biến liên tục); phân tích phụ: cân bằng dương so với âm.",
                paste0(n_exp, " người bệnh có cân bằng dịch ngày 3; các mô hình hiệu chỉnh ", nobs(a_adj), " trường hợp đầy đủ.")) |>
  P(flow_vn) |>
  H("3. Bảng 1: đối tượng nghiên cứu") |>
  TBV(t1_bal_df, "Bảng 1. Đặc điểm ban đầu theo nhóm cân bằng dịch", q, "table1_by_balance", t1 = TRUE, note = t1_note_vn) |>
  H("4. Kết quả chính") |>
  B(c(paste0("AKI (mọi giai đoạn) xảy ra ở ", KR$q2$aki_all, " tổng số người bệnh; RRT ở ", KR$q2$rrt_all, "."),
      paste0("AKI: cân bằng dương ", KR$q2$aki_pos, " so với cân bằng âm ", KR$q2$aki_neg, "."),
      paste0("AKI tăng dần theo từng nhóm cân bằng dịch: ", v(KR$q2$gradient), "."),
      paste0("OR thô cho mỗi 10 ml/kg cân bằng dịch tăng thêm: ", v(KR$q2$crude10), "."),
      paste0("OR hiệu chỉnh cho mỗi 10 ml/kg: **", v(KR$q2$adj10), "**, p ", KR$q2$adj10_p, "."),
      paste0("Cân bằng dương so với âm: OR thô ", v(KR$q2$bin_crude), "; OR hiệu chỉnh ", v(KR$q2$bin_adj), "."))) |>
  TBV(stage_tab, "Bảng 2. Giai đoạn AKI cao nhất theo KDIGO, theo nhóm cân bằng dịch", q, "table2_aki_stage_by_group") |>
  TBV(aki_cat_tab, "Bảng 3. AKI theo nhóm cân bằng dịch tích lũy ngày 3", q, "table3_aki_by_balance_category") |>
  TBV(aki_models, "Bảng 4. Hồi quy logistic cho AKI (hiệu chỉnh theo tuổi, SOFA, lactat, thuốc vận mạch, thở máy, bệnh thận mạn)", q, "table4_aki_models") |>
  FG(f_aki_vn, "Hình 1. Giai đoạn AKI cao nhất theo nhóm cân bằng dịch tích lũy", 7, 4.5) |>
  FG(f_sc_vn, "Hình 2. Xác suất AKI thô theo toàn bộ khoảng giá trị cân bằng dịch (đường cong logistic, dải 95%)", 7, 4.5) |>
  H("5. Ý nghĩa (bằng lời đơn giản)") |>
  B(c("AKI càng thường gặp khi cân bằng dịch càng dương: một quy luật 'liều-đáp ứng' rõ ràng.",
      paste0("Sau hiệu chỉnh, mỗi 10 ml/kg tăng thêm (khoảng 650 ml ở người lớn nặng 65 kg) liên quan với số chênh AKI cao hơn khoảng ", round(100 * (oa_a$estimate - 1)), "%."),
      "Dùng cân bằng dịch dạng liên tục giữ lại nhiều thông tin hơn cách chia dương/âm và cho thấy rõ xu hướng tăng dần.")) |>
  H("6. Kết quả này KHÔNG có nghĩa là gì") |>
  B(c("Kết quả KHÔNG cho thấy dịch làm tổn thương thận. Mối liên quan có thể theo chiều ngược lại: AKI làm giảm lượng nước tiểu, và lượng dịch ra thấp làm cân bằng dịch dương (quan hệ nhân quả ngược).",
      "Không biết AKI bắt đầu trước hay sau khi dịch tích lũy. Dữ liệu chỉ ghi giai đoạn cao nhất trong các ngày 1-7.",
      paste0("OR ", f2(oa_a$estimate), " cho mỗi 10 ml/kg không phải là nguy cơ: khi AKI phổ biến như ở đây (khoảng 49%), tỷ số chênh phóng đại tỷ số nguy cơ."))) |>
  H("7. Các hạn chế cần bàn luận (gợi ý)") |>
  B(c("Thời điểm: phơi nhiễm (ngày 1-3) và kết cục (ngày 1-7) chồng lên nhau.", "Nhiễu tồn dư do mức độ nặng và do thuốc độc cho thận (không được ghi nhận).",
      "Phân giai đoạn KDIGO có thể dựa trên creatinin, vốn bị pha loãng khi truyền dịch, nên AKI có thể bị chẩn đoán thiếu ở người bệnh có cân bằng dịch dương nhiều.",
      "Phân tích trường hợp đầy đủ (thiếu lactat ở 15%).")) |>
  strobe_vn(c("Mục 6-7: người tham gia và định nghĩa biến số (KDIGO)", "Mục 12: phương pháp, gồm cách đưa phơi nhiễm liên tục vào mô hình (mỗi 10 ml/kg)",
              "Mục 14: dữ liệu mô tả (Bảng 1)", "Mục 15: dữ liệu kết cục (Bảng 2-3)",
              "Mục 16: OR thô và hiệu chỉnh kèm khoảng tin cậy 95%; báo cáo ngưỡng của các nhóm (Bảng 3-4)",
              "Mục 19: hạn chế (quan hệ nhân quả ngược và thời điểm)", "Mục 17: kết cục phụ AKI giai đoạn 2-3"))
packs_vn$Q2 <- pk

# ---- Q3 (VN) ---------------------------------------------------------------
q <- "Q3"
f_vfd_vn <- save_fig_vn(p_vfd + vn_grp(icu) + scale_fill_manual(values = grp_cols_vn, guide = "none") +
                          labs(x = "Số ngày không thở máy đến ngày 28 (0 = tử vong hoặc thở máy suốt thời gian)", y = "Số người bệnh"),
                        q, "fig1_vfd_histogram", 7, 5)
f_vfd2_vn <- save_fig_vn(p_vfd2 + vn_fb(p_vfd2$data) + labs(x = x_fb_vn, y = "Số ngày không thở máy trung bình"),
                         q, "fig2_vfd_by_balance_category", 7, 4.2)
pk <- new_pack() |>
  std_header_vn("Ở người lớn bị sepsis điều trị tại ICU, cân bằng dịch tích lũy cao hơn vào ngày 3 có liên quan với ít số ngày không thở máy đến ngày 28 hơn không?",
                design_vn,
                "số ngày không thở máy (VFD) đến ngày 28: số ngày còn sống và không thở máy; người bệnh tử vong = 0; không thở máy và còn sống = 28 (vent_free_days_28).",
                "cân bằng dịch tích lũy ngày 3 theo mỗi 10 ml/kg (liên tục); phân tích phụ: dương so với âm.",
                paste0(n_exp, " người bệnh; các mô hình hiệu chỉnh ", nobs(v_lm), " trường hợp đầy đủ; ", nrow(vent), " người thở máy lúc nhập ICU.")) |>
  P(flow_vn) |>
  H("3. Bảng 1: đối tượng nghiên cứu") |>
  TBV(t1_bal_df, "Bảng 1. Đặc điểm ban đầu theo nhóm cân bằng dịch", q, "table1_by_balance", t1 = TRUE, note = t1_note_vn) |>
  H("4. Kết quả chính") |>
  B(c(paste0("VFD trung vị (IQR): cân bằng dương ", v(KR$q3$vfd_pos), " so với âm ", v(KR$q3$vfd_neg), " ngày; Mann-Whitney p ", KR$q3$mw_p, "."),
      paste0("Hồi quy tuyến tính, thô: ", v(KR$q3$lm_crude), " ngày cho mỗi 10 ml/kg."),
      paste0("Hồi quy tuyến tính, hiệu chỉnh: **", v(KR$q3$lm_adj), " ngày cho mỗi 10 ml/kg**, p ", KR$q3$lm_adj_p, "."),
      paste0("Cân bằng dương so với âm, chênh lệch đã hiệu chỉnh: ", v(KR$q3$bin_adj), " ngày."))) |>
  TBV(vfd_sum_t, "Bảng 2. Số ngày không thở máy theo nhóm cân bằng dịch", q, "table2_vfd_by_group") |>
  TBV(vfd_models, "Bảng 3. Liên quan giữa cân bằng dịch và số ngày không thở máy", q, "table3_vfd_models",
      note = "Giá trị âm = ít ngày không thở máy hơn. Hiệu chỉnh theo tuổi, SOFA, lactat, thuốc vận mạch, thở máy, bệnh thận mạn.") |>
  FG(f_vfd_vn, "Hình 1. Phân bố số ngày không thở máy theo nhóm (chú ý hai đỉnh tại 0 và 28)", 7, 5) |>
  FG(f_vfd2_vn, "Hình 2. Số ngày không thở máy trung bình theo nhóm cân bằng dịch tích lũy", 7, 4.2) |>
  H("5. Ý nghĩa (bằng lời đơn giản)") |>
  B(c("Người bệnh tích lũy nhiều dịch hơn có ít ngày còn sống và không thở máy hơn.",
      paste0("Sau hiệu chỉnh, mỗi 10 ml/kg tăng thêm liên quan với ít hơn khoảng ", f1(-vt$estimate), " ngày không thở máy (khoảng tin cậy 95% ", f1(-vt$conf.high), " đến ", f1(-vt$conf.low), ")."),
      "VFD không có phân phối hình chuông: nhiều người bệnh ở mức 0 (tử vong) hoặc 28 (không thở máy). Trung vị và kiểm định Mann-Whitney mô tả biến này một cách trung thực; mô hình tuyến tính cho một chênh lệch trung bình dễ đọc nhưng các giả định của mô hình bị vi phạm phần nào.")) |>
  H("6. Kết quả này KHÔNG có nghĩa là gì") |>
  B(c("Kết quả KHÔNG có nghĩa là dịch giữ người bệnh trên máy thở: VFD gộp cả tử vong và thời gian thở máy, và người bệnh nặng hơn được truyền nhiều dịch hơn.",
      "Chênh lệch VFD trung bình không giống với 'mỗi người bệnh thở máy lâu hơn một ngày'.")) |>
  H("7. Các hạn chế cần bàn luận (gợi ý)") |>
  B(c("Kết cục gộp: VFD bằng 0 có thể là tử vong sớm hoặc thở máy suốt 28 ngày. Hãy nói rõ thành phần nào quyết định kết quả.",
      "Kết cục phân phối lệch và bị chặn hai đầu: hồi quy tuyến tính chỉ gần đúng; hãy cân nhắc kết quả Mann-Whitney hoặc mô hình tỷ lệ chênh (proportional-odds) làm phân tích độ nhạy.",
      "Nhiễu tồn dư do mức độ nặng; nhiễm khuẩn hô hấp vừa làm tăng nhu cầu thở máy vừa có thể làm thay đổi cách truyền dịch.",
      "Phân tích trường hợp đầy đủ (thiếu lactat).")) |>
  strobe_vn(c("Mục 7: định nghĩa chính xác kết cục gộp VFD", "Mục 12: phương pháp (vì sao dùng mô hình phi tham số và tuyến tính)",
              "Mục 14: dữ liệu mô tả (Bảng 1)", "Mục 15-16: tóm tắt kết cục và chênh lệch đã hiệu chỉnh kèm khoảng tin cậy 95%",
              "Mục 19: hạn chế của một kết cục gộp, phân phối lệch"))
packs_vn$Q3 <- pk

# ---- Q4 (VN) ---------------------------------------------------------------
q <- "Q4"
f_ms_vn <- save_fig_vn(p_ms + labs(x = "Điểm SOFA lúc nhập ICU", y = "Thiếu lactat (%)"), q, "fig1_missing_lactate_by_sofa", 7, 4.2)
mort_lac_vn <- mort_lac |> mutate(miss = lac_cat == "Missing",
                                  lac_cat = factor(tr_vn(as.character(lac_cat)), tr_vn(levels(mort_lac$lac_cat))))
p_ml_vn <- ggplot(mort_lac_vn, aes(lac_cat, pct, fill = miss)) + geom_col(width = .6) +
  geom_text(aes(label = sprintf("%.0f%%\n(%d/%d)", pct, deaths, n)), vjust = -.2, size = 4) +
  scale_fill_manual(values = c(`FALSE` = pal[["blue"]], `TRUE` = pal[["grey"]]), guide = "none") +
  scale_y_continuous(limits = c(0, 60)) + labs(x = "Lactat lúc nhập ICU (mmol/L)", y = "Tử vong trong 28 ngày (%)")
f_ml_vn <- save_fig_vn(p_ml_vn, q, "fig2_mortality_by_lactate", 7, 4.2)
model_vn <- c("Unadjusted" = "Chưa hiệu chỉnh", "Adjusted (main)" = "Hiệu chỉnh (chính)", "Adjusted + SOFA" = "Hiệu chỉnh + SOFA")
method_vn <- c("Complete case" = "Trường hợp đầy đủ", "Multiple imputation" = "Quy gán đa bội")
p_ccmi_vn <- ccmi_plot |> mutate(model = factor(model_vn[model], unname(model_vn)),
                                 method = factor(method_vn[method], unname(method_vn))) |>
  ggplot(aes(OR, method, colour = method)) + geom_vline(xintercept = 1, linetype = 2) +
  geom_errorbar(aes(xmin = lower, xmax = upper), width = .2, orientation = "y", linewidth = .9) + geom_point(size = 3.5) +
  geom_text(aes(label = sprintf("%s (%s-%s), n = %d", f2(OR), f2(lower), f2(upper), n)), vjust = -1, size = 3.5, colour = "black") +
  facet_wrap(~ model, ncol = 1) + scale_colour_manual(values = c(pal[["grey"]], pal[["teal"]]), guide = "none") +
  scale_x_continuous(limits = c(0.9, 1.8)) + labs(x = "Tỷ số chênh cho tử vong 28 ngày, mỗi 1 mmol/L lactat", y = NULL)
f_ccmi_vn <- save_fig_vn(p_ccmi_vn, q, "fig3_cc_vs_mi", 7, 5.5)
mort_cat_vn <- v(gsub("Missing", "Thiếu", KR$q4$mort_cat, fixed = TRUE))
pk <- new_pack() |>
  std_header_vn("Ở người lớn bị sepsis điều trị tại ICU, lactat lúc nhập ICU có liên quan với tử vong 28 ngày không, và câu trả lời có thay đổi không khi các giá trị lactat bị thiếu được xử lý bằng quy gán đa bội?",
                "Thiết kế: nghiên cứu thuần tập tiến cứu đa trung tâm (quan sát); câu hỏi về yếu tố tiên lượng.",
                "tử vong do mọi nguyên nhân trong vòng 28 ngày (died_28d).",
                "lactat lúc nhập ICU tính bằng mmol/L, theo mỗi 1 mmol/L (liên tục); và theo các nhóm < 2, 2 đến 4, > 4 mmol/L.",
                paste0("tất cả ", n_all, " người bệnh; thiếu lactat ở ", KR$lac_missing, "; các mô hình trường hợp đầy đủ ", nobs(cc_q4), " người bệnh; quy gán đa bội ", n_all, ".")) |>
  H("3. Bảng 1: đối tượng nghiên cứu") |>
  TBV(t1_q4_df, "Bảng 1. Đặc điểm ban đầu của nhóm sống và nhóm tử vong", q, "table1_by_survival", t1 = TRUE, note = t1_note_vn) |>
  H("4. Ai bị thiếu lactat?") |>
  TBV(miss_cmp, "Bảng 2. Người bệnh có và không có lactat lúc nhập ICU", q, "table2_missing_lactate_comparison") |>
  P(paste0("Người bệnh không có lactat **ít nặng hơn** (SOFA ", v(KR$q4$sofa_missing), " so với ", v(KR$q4$sofa_measured),
           ") và tử vong ít hơn (", KR$q4$mort_missing, " so với ", KR$q4$mort_measured,
           "). Vì vậy lactat KHÔNG thiếu hoàn toàn ngẫu nhiên; việc thiếu được giải thích bởi các biến đã quan sát (SOFA, MAP, thuốc vận mạch, ICU), nên giả định 'thiếu ngẫu nhiên' (MAR) là hợp lý.")) |>
  FG(f_ms_vn, "Hình 1. Tỷ lệ người bệnh thiếu lactat theo điểm SOFA", 7, 4.2) |>
  H("5. Kết quả chính") |>
  B(c(paste0("Lactat trung vị: nhóm tử vong ", v(KR$q4$lac_died), " so với nhóm sống ", v(KR$q4$lac_surv), " mmol/L."),
      paste0("Tử vong theo nhóm lactat: ", mort_cat_vn, "."),
      paste0("OR chưa hiệu chỉnh cho mỗi 1 mmol/L: trường hợp đầy đủ ", v(KR$q4$cc_c), "; quy gán đa bội ", v(KR$q4$mi_c), "."),
      paste0("Hiệu chỉnh (tuổi, giới, bệnh kèm): trường hợp đầy đủ ", v(KR$q4$cc), " so với **quy gán đa bội ", v(KR$q4$mi), "** (phân tích chính)."),
      paste0("Thêm SOFA: trường hợp đầy đủ ", v(KR$q4$cc_s), " so với quy gán đa bội ", v(KR$q4$mi_s), "."),
      paste0("Lactat trung vị ở các trường hợp đầy đủ là ", KR$q4$median_cc, " mmol/L so với ", KR$q4$median_mi, " mmol/L sau quy gán: các trường hợp đầy đủ có nhiều người bệnh nặng hơn so với toàn bộ mẫu."))) |>
  TBV(mort_lac_tab, "Bảng 3. Tử vong 28 ngày theo nhóm lactat lúc nhập ICU", q, "table3_mortality_by_lactate") |>
  TBV(ccmi_tab, "Bảng 4. Lactat và tử vong 28 ngày: trường hợp đầy đủ so với quy gán đa bội", q, "table4_cc_vs_mi") |>
  FG(f_ml_vn, "Hình 2. Tử vong 28 ngày theo nhóm lactat lúc nhập ICU (màu xám = không đo lactat)", 7, 4.2) |>
  FG(f_ccmi_vn, "Hình 3. Tỷ số chênh cho mỗi 1 mmol/L lactat: trường hợp đầy đủ so với quy gán đa bội", 7, 5.5) |>
  H("6. Ý nghĩa (bằng lời đơn giản)") |>
  B(c("Lactat lúc nhập ICU cao hơn đi kèm tử vong 28 ngày cao hơn: mỗi 1 mmol/L tăng thêm làm số chênh tử vong tăng khoảng 40-45% (hiệu chỉnh theo tuổi, giới và bệnh kèm).",
      "Phần lớn mối liên quan này trùng với mức độ nặng chung: sau khi thêm SOFA, OR giảm còn khoảng 1.2. Lactat một phần là dấu hiệu cho biết người bệnh nặng đến mức nào.",
      "Loại bỏ 93 người bệnh không có lactat (trường hợp đầy đủ) cho OR nhỏ hơn một chút so với quy gán đa bội (dùng cả 620 người bệnh). Kết luận vẫn như nhau; độ lớn khác nhau ở mức vừa phải, vì các trường hợp đầy đủ là một nhóm nặng hơn, đã bị chọn lọc.")) |>
  H("7. Kết quả này KHÔNG có nghĩa là gì") |>
  B(c("Kết quả KHÔNG có nghĩa là hạ lactat sẽ cứu sống người bệnh. Lactat là một dấu hiệu, không nhất thiết là nguyên nhân.",
      "Quy gán đa bội KHÔNG bịa ra dữ liệu và KHÔNG 'sửa' được mọi thứ: phương pháp này chỉ hợp lệ khi việc thiếu phụ thuộc vào những yếu tố đã đo (MAR). Nếu lactat bị thiếu vì những lý do liên quan đến chính giá trị không quan sát được (MNAR), không phương pháp nào sửa được hoàn toàn.")) |>
  H("8. Các hạn chế cần bàn luận (gợi ý)") |>
  B(c("Thiếu 15% lactat, không ngẫu nhiên: hãy báo cáo số bị thiếu, đó là những ai, và kết quả của cả hai phân tích.",
      "Chỉ có một giá trị lúc nhập ICU: độ thanh thải lactat theo thời gian không được ghi nhận.",
      "Vấn đề đơn vị ở một ICU (mg/dL) được phát hiện khi làm sạch dữ liệu: hãy mô tả các bước kiểm tra dữ liệu.",
      "OR cho mỗi 1 mmol/L giả định quan hệ đường thẳng (trên thang log-odds); các nhóm trong Bảng 3 giúp người đọc kiểm tra giả định này.")) |>
  strobe_vn(c("Mục 12c: cách xử lý dữ liệu thiếu (quy gán đa bội, m = 20, các biến trong mô hình quy gán)",
              "Mục 14b: số người tham gia bị thiếu dữ liệu ở từng biến (Bảng 1, Bảng 2)",
              "Mục 16: ước lượng chưa hiệu chỉnh và đã hiệu chỉnh kèm khoảng tin cậy 95%; ngưỡng của các nhóm (Bảng 3)",
              "Mục 17: phân tích độ nhạy (trường hợp đầy đủ so với quy gán đa bội, Bảng 4)", "Mục 19: hạn chế (cơ chế dữ liệu thiếu)"))
packs_vn$Q4 <- pk

# ---- Q5 (VN) ---------------------------------------------------------------
q <- "Q5"
p_los_vn <- ggplot(surv, aes(icu_los_days)) + geom_histogram(binwidth = 1, boundary = 0, fill = pal[["teal"]], colour = "white") +
  geom_vline(xintercept = median(surv$icu_los_days), colour = pal[["blue"]], linewidth = 1) +
  geom_vline(xintercept = mean(surv$icu_los_days), colour = pal[["blue"]], linewidth = 1, linetype = 2) +
  annotate("text", x = median(surv$icu_los_days), y = Inf, vjust = 1.5, hjust = 1.1, label = paste("trung vị", f1(median(surv$icu_los_days)))) +
  annotate("text", x = mean(surv$icu_los_days), y = Inf, vjust = 3.2, hjust = -.1, label = paste("trung bình", f1(mean(surv$icu_los_days)))) +
  labs(x = "Thời gian nằm ICU ở người sống (ngày)", y = "Số người bệnh")
f_los_vn <- save_fig_vn(p_los_vn, q, "fig1_los_histogram", 7, 4.2)
f_los2_vn <- save_fig_vn(p_los2 + vn_grp(surv) + scale_fill_manual(values = grp_cols_vn, guide = "none") +
                           labs(x = NULL, y = "Thời gian nằm ICU, ngày (thang log)"), q, "fig2_los_by_group_log", 6, 4.5)
pk <- new_pack() |>
  std_header_vn("Ở người lớn bị sepsis còn sống đến ngày 28, cân bằng dịch tích lũy dương vào ngày 3 có liên quan với thời gian nằm ICU dài hơn không?",
                "Thiết kế: nghiên cứu thuần tập tiến cứu đa trung tâm (quan sát); phân tích giới hạn ở người bệnh còn sống đến ngày 28.",
                "thời gian nằm ICU tính bằng ngày (icu_los_days), phân phối lệch phải.",
                "cân bằng dịch tích lũy dương so với âm vào ngày 3; phân tích phụ: theo mỗi 10 ml/kg.",
                paste0(nrow(surv), " người sống có cân bằng dịch ngày 3 (", KR$q5$n_pos, " dương, ", KR$q5$n_neg, " âm); mô hình hiệu chỉnh ", nobs(l5), " trường hợp đầy đủ.")) |>
  H("3. Bảng 1: đối tượng nghiên cứu") |>
  TBV(t1_q5_df, "Bảng 1. Đặc điểm ban đầu của người bệnh còn sống đến ngày 28 theo nhóm cân bằng dịch", q, "table1_survivors_by_balance", t1 = TRUE, note = t1_note_vn) |>
  H("4. Kết quả chính") |>
  B(c(paste0("Thời gian nằm ICU lệch phải: ở người sống, trung bình ", KR$q5$mean_surv, " so với trung vị ", KR$q5$median_surv, " ngày."),
      paste0("Thời gian nằm ICU trung vị (IQR): cân bằng dương ", v(KR$q5$los_pos), " so với âm ", v(KR$q5$los_neg), " ngày; Mann-Whitney p ", KR$q5$mw_p, "."),
      paste0("Chênh lệch Hodges-Lehmann: ", v(KR$q5$hl), " ngày."),
      paste0("Hồi quy tuyến tính trên thang log: tỷ số trung bình nhân thô ", v(KR$q5$ratio_crude), "; hiệu chỉnh **", v(KR$q5$ratio_adj), "**, p ", KR$q5$ratio_adj_p,
             " (tức là thời gian nằm dài hơn khoảng ", round(100 * (exp(g5$estimate) - 1)), "%)."),
      paste0("Mỗi 10 ml/kg cân bằng dịch tăng thêm: tỷ số ", v(KR$q5$ratio_10), "."))) |>
  TBV(los_sum, "Bảng 2. Thời gian nằm ICU ở người sống theo nhóm cân bằng dịch", q, "table2_los_summary") |>
  TBV(los_models, "Bảng 3. Liên quan giữa cân bằng dịch và thời gian nằm ICU (người sống)", q, "table3_los_models",
      note = "Tỷ số trung bình nhân: 1.24 = thời gian nằm điển hình dài hơn 24%. Hiệu chỉnh theo tuổi, SOFA, lactat, thuốc vận mạch, thở máy, bệnh thận mạn.") |>
  FG(f_los_vn, "Hình 1. Thời gian nằm ICU ở người sống: đuôi dài bên phải kéo trung bình lên cao hơn trung vị", 7, 4.2) |>
  FG(f_los2_vn, "Hình 2. Thời gian nằm ICU theo nhóm cân bằng dịch (thang log)", 6, 4.5) |>
  H("5. Ý nghĩa (bằng lời đơn giản)") |>
  B(c("Trong số người sống, người có cân bằng dịch dương nằm ICU lâu hơn, khoảng 2-3 ngày tính theo trung vị.",
      paste0("Sau hiệu chỉnh, thời gian nằm điển hình (trung bình nhân) dài hơn khoảng ", round(100 * (exp(g5$estimate) - 1)), "%."),
      "Với một kết cục phân phối lệch, hãy báo cáo trung vị (IQR), dùng kiểm định dựa trên thứ hạng hoặc phân tích logarit của thời gian nằm, và trình bày kết quả dưới dạng tỷ số.")) |>
  H("6. Kết quả này KHÔNG có nghĩa là gì") |>
  B(c("Kết quả KHÔNG cho thấy dịch kéo dài thời gian nằm ICU; người bệnh nằm lâu hơn có nhiều thời gian và lý do hơn để được truyền dịch (quan hệ nhân quả ngược).",
      "Kết quả KHÔNG mô tả toàn bộ người bệnh: người tử vong đã bị loại ra, và tử vong làm thời gian nằm ngắn lại.")) |>
  H("7. Các hạn chế cần bàn luận (gợi ý)") |>
  B(c("Sai lệch chọn lựa: giới hạn ở người sống là đặt điều kiện trên một kết cục mà bản thân nó có liên quan với dịch (sai lệch người sống sót). Một cách khác là dùng 'số ngày không nằm ICU' (ICU-free days), trong đó tử vong được tính là 0.",
      "Việc chuyển khỏi ICU còn phụ thuộc vào áp lực giường bệnh và thực hành tại chỗ, không chỉ vào người bệnh.",
      "Nhiễu tồn dư do mức độ nặng; mô hình hiệu chỉnh dùng các trường hợp đầy đủ.")) |>
  strobe_vn(c("Mục 6: người tham gia (vì sao chỉ người sống)", "Mục 12: phương pháp cho kết cục phân phối lệch (biến đổi logarit / phi tham số)",
              "Mục 14: dữ liệu mô tả (Bảng 1)", "Mục 15-16: trung vị (IQR) và tỷ số kèm khoảng tin cậy 95%",
              "Mục 19: hạn chế (chọn lựa người sống)"))
packs_vn$Q5 <- pk

titles_vn <- c(Q1 = "Gói kết quả Q1: Cân bằng dịch dương và tử vong 28 ngày",
               Q2 = "Gói kết quả Q2: Cân bằng dịch tích lũy và tổn thương thận cấp",
               Q3 = "Gói kết quả Q3: Cân bằng dịch tích lũy và số ngày không thở máy",
               Q4 = "Gói kết quả Q4: Lactat lúc nhập ICU, tử vong 28 ngày và dữ liệu thiếu",
               Q5 = "Gói kết quả Q5: Cân bằng dịch và thời gian nằm ICU ở người sống")
for (q in names(packs_vn)) {
  pk <- c(list(list(type = "h", text = titles_vn[[q]], level = 1)), packs_vn[[q]])
  render_md(pk, file.path("results_packs", q, paste0("results_pack_", q, "_VN.md")), q, files_txt = c("Tệp", "và"))
  render_docx(packs_vn[[q]], file.path("results_packs", paste0("Results_Pack_", q, "_VN.docx")), titles_vn[[q]],
              note = "FLUID-ICU là bộ dữ liệu MÔ PHỎNG được tạo ra để giảng dạy. Không có người bệnh thật. Neudata | Nền tảng Nghiên cứu Lâm sàng")
}

# ---- key_results_VN.md -----------------------------------------------------
kr_vn <- c(
"# Kết quả chính của FLUID-ICU (DỮ LIỆU MÔ PHỎNG: KHÔNG PHẢI NGƯỜI BỆNH THẬT)", "",
"Mọi con số mà slide, phần trình diễn và tài liệu phát tay có thể trích dẫn. Được tạo tự động bởi `R/06_results_packs.R`",
"từ `fluid_icu_clean.rds`; các mô hình giống hệt được chạy trực tiếp trong các script 02-05 (script nguồn ghi ở từng mục).",
"Tỷ số chênh và tỷ số nguy cơ tức thời dùng khoảng tin cậy 95% theo profile-likelihood / Wald như R in ra; do làm tròn, các kết quả có thể chênh nhau 0.01.",
"CC = phân tích trường hợp đầy đủ (complete case); MI = quy gán đa bội (multiple imputation).", "",
"## Mẫu nghiên cứu (02_describe.R)",
paste0("- Tuyển vào: **", r$n, "** người lớn bị sepsis tại 4 ICU (", paste(names(r$sites), r$sites, sep = " n = ", collapse = "; "), "), từ tháng 1/2023 đến tháng 12/2024."),
"- Tệp thô: 623 dòng (3 bản ghi trùng) -> 620 sau khi làm sạch (01_clean.R; xem cleaning_log_VN.md).",
paste0("- ", flow_vn),
paste0("- Tuổi trung bình ", r$age, " năm; nam ", r$male, "; SOFA trung vị (IQR) ", v(r$sofa), "."),
paste0("- Tử vong 28 ngày: **", r$mort, "**."),
paste0("- Cân bằng dịch dương vào ngày 3: **", r$pos, "**; cân bằng dịch tích lũy trung vị (IQR) ", v(r$cfb), " ml/kg."),
paste0("- Thiếu lactat: **", r$lac_missing, "** (các biến khác <= 1%)."), "",
"## Điểm chính của Bảng 1 (02_describe.R): cân bằng âm so với cân bằng dương",
paste0("- SOFA trung vị (IQR): ", v(s$sofa[1]), " so với ", v(s$sofa[2])),
paste0("- Thuốc vận mạch: ", s$vaso[1], " so với ", s$vaso[2]),
paste0("- Thở máy: ", s$mv[1], " so với ", s$mv[2]),
paste0("- Lactat trung vị (IQR): ", v(s$lac[1]), " so với ", v(s$lac[2]), " mmol/L"),
paste0("- Suy tim: ", s$hf[1], " so với ", s$hf[2], " (bác sĩ truyền ít dịch hơn cho người bệnh suy tim)"),
paste0("- Tuổi trung bình: ", s$age[1], " so với ", s$age[2], " năm"), "",
"## Q1: cân bằng dịch dương và tử vong 28 ngày (03_compare.R, 04_models.R, 05_missing.R)",
paste0("- Tử vong: dương ", r$q1$mort_pos, " so với âm ", r$q1$mort_neg, "; hiệu số nguy cơ ", v(r$q1$rd), " điểm phần trăm; RR ", r$q1$rr, "; kiểm định Chi bình phương p < 0.001."),
paste0("- **OR thô ", v(r$q1$crude), "**, p ", r$q1$crude_p, " (n = 618)."),
paste0("- OR thô trên ", r$q1$n_cc, " trường hợp đầy đủ: ", v(r$q1$crude_cc), "."),
paste0("- **OR hiệu chỉnh ", v(r$q1$adj), "**, p ", r$q1$adj_p, " (n = ", r$q1$n_cc, "; tuổi, SOFA, lactat, thuốc vận mạch, thở máy, bệnh thận mạn)."),
paste0("- Quy gán đa bội (m = 20, n = 620): OR hiệu chỉnh ", v(r$q1$mi), ", p ", r$q1$mi_p, "."),
paste0("- Sống còn Kaplan-Meier tại ngày 28: ", sprintf("%.1f%% (âm) so với %.1f%% (dương)", 100 * km28$surv[1], 100 * km28$surv[2]),
       "; **log-rank p ", r$q1$logrank, "** (Chi bình phương ", r$q1$logrank_chisq, ")."),
paste0("- HR Cox thô ", v(r$q1$hr_crude), "; **HR hiệu chỉnh ", v(r$q1$hr_adj), "**, p ", r$q1$hr_adj_p, "; kiểm định nguy cơ tỷ lệ toàn cục p = ", r$q1$zph, "."),
paste0("- Tương tác (cân bằng dương x suy tim): **p = ", r$q1$p_int, "** (Wald; kiểm định tỷ số khả dĩ p = ", r$q1$p_int_lr, ")."),
paste0("  - Suy tim (n = ", r$q1$n_hf, "): OR hiệu chỉnh ", v(r$q1$or_hf), "."),
paste0("  - Không suy tim (n = ", r$q1$n_nohf, "): OR hiệu chỉnh ", v(r$q1$or_nohf), "."), "",
"## Q2: cân bằng dịch và AKI (gói kết quả Q2; 03_compare.R cho bảng 2x2)",
paste0("- AKI (KDIGO >= 1): ", r$q2$aki_all, " trên toàn bộ; RRT ", r$q2$rrt_all, "."),
paste0("- AKI: dương ", r$q2$aki_pos, " so với âm ", r$q2$aki_neg, "."),
paste0("- Xu hướng theo cân bằng dịch (ml/kg): ", v(r$q2$gradient), "."),
paste0("- OR mỗi 10 ml/kg: thô ", v(r$q2$crude10), "; **hiệu chỉnh ", v(r$q2$adj10), "**, p ", r$q2$adj10_p, " (n = ", r$q2$n_adj, ")."),
paste0("- Dương so với âm: OR thô ", v(r$q2$bin_crude), "; OR hiệu chỉnh ", v(r$q2$bin_adj), "."),
paste0("- AKI giai đoạn 2-3, OR hiệu chỉnh mỗi 10 ml/kg: ", v(r$q2$st23), "."), "",
"## Q3: cân bằng dịch và số ngày không thở máy (gói kết quả Q3; 03_compare.R)",
paste0("- VFD trung vị (IQR): dương ", v(r$q3$vfd_pos), " so với âm ", v(r$q3$vfd_neg), " ngày; Mann-Whitney p ", r$q3$mw_p, "."),
paste0("- Hồi quy tuyến tính mỗi 10 ml/kg: thô ", v(r$q3$lm_crude), " ngày; **hiệu chỉnh ", v(r$q3$lm_adj), " ngày**, p ", r$q3$lm_adj_p, " (n = ", r$q3$n_adj, ")."),
paste0("- Dương so với âm, chênh lệch đã hiệu chỉnh: ", v(r$q3$bin_adj), " ngày."), "",
"## Q4: lactat, tử vong và dữ liệu thiếu (05_missing.R)",
paste0("- Thiếu lactat ", r$lac_missing, "; SOFA trung vị ", v(r$q4$sofa_missing), " (thiếu) so với ", v(r$q4$sofa_measured), " (có đo); tử vong ", r$q4$mort_missing, " so với ", r$q4$mort_measured, ", nên không phải MCAR (MAR là hợp lý)."),
paste0("- Lactat trung vị: nhóm tử vong ", v(r$q4$lac_died), " so với nhóm sống ", v(r$q4$lac_surv), " mmol/L."),
paste0("- Tử vong theo nhóm lactat: ", mort_cat_vn, "."),
paste0("- OR mỗi 1 mmol/L, chưa hiệu chỉnh: CC ", v(r$q4$cc_c), " so với MI ", v(r$q4$mi_c), "."),
paste0("- **Hiệu chỉnh (tuổi, giới, đái tháo đường, bệnh thận mạn, suy tim): CC ", v(r$q4$cc), " (n = ", r$q4$n_cc, ") so với MI ", v(r$q4$mi), " (n = 620).**"),
paste0("- + SOFA: CC ", v(r$q4$cc_s), " so với MI ", v(r$q4$mi_s), "."),
paste0("- Lactat trung vị: trường hợp đầy đủ ", r$q4$median_cc, " so với sau quy gán ", r$q4$median_mi, " mmol/L."), "",
"## Q5: cân bằng dịch và thời gian nằm ICU ở người sống (gói kết quả Q5; 03_compare.R)",
paste0("- Thời gian nằm ICU, tất cả người bệnh: trung bình ", r$q5$mean_all, " so với trung vị ", r$q5$median_all, " ngày (lệch phải). Người sống: trung bình ", r$q5$mean_surv, " so với trung vị ", r$q5$median_surv, "."),
paste0("- Người sống n = ", r$q5$n_surv, " (", r$q5$n_pos, " dương, ", r$q5$n_neg, " âm)."),
paste0("- Trung vị (IQR): dương ", v(r$q5$los_pos), " so với âm ", v(r$q5$los_neg), " ngày; Mann-Whitney p ", r$q5$mw_p, "; chênh lệch Hodges-Lehmann ", v(r$q5$hl), " ngày."),
paste0("- Tỷ số trung bình nhân: thô ", v(r$q5$ratio_crude), "; **hiệu chỉnh ", v(r$q5$ratio_adj), "**, p ", r$q5$ratio_adj_p, " (n = ", r$q5$n_adj, "); mỗi 10 ml/kg ", v(r$q5$ratio_10), "."),
paste0("- Chênh lệch trung bình theo kiểm định t (kiểm định 'sai', để đối chiếu): ", r$q5$ttest_diff, " ngày."), "",
"## Kiểm tra các đặc điểm phục vụ giảng dạy",
paste0("- Thấy rõ nhiễu do chỉ định: OR thô ", f2(o_cr$estimate), " > OR hiệu chỉnh ", f2(o_ad$estimate), "; khoảng tin cậy hiệu chỉnh loại trừ 1: ", yn_vn(o_ad$conf.low > 1), "."),
paste0("- HR Cox cùng chiều: thô ", f2(h_cr$estimate), ", hiệu chỉnh ", f2(h_ad$estimate), " (giới hạn dưới của khoảng tin cậy ", f2(h_ad$conf.low), ")."),
paste0("- p tương tác trong khoảng 0.03-0.10: ", yn_vn(p_int >= 0.03 & p_int <= 0.10), " (p = ", pf(p_int), ")."),
paste0("- CC và MI khác nhau ở mức vừa phải (Q4, hiệu chỉnh): ", f2(r4$cc$estimate), " so với ", f2(r4$mi$estimate), "."),
paste0("- Thời gian nằm ICU lệch phải: trung bình ", r$q5$mean_all, " > trung vị ", r$q5$median_all, ".")
)
writeLines(enc2utf8(kr_vn), "key_results_VN.md", useBytes = TRUE)
cat("\n06_results_packs.R finished: 5 packs (EN + VN), key_results.md, key_results_VN.md and slide data written.\n")
